import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Studio } from "@/components/studio/studio";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const [ready, setReady] = useState(false);
  useEffect(() => setReady(true), []);
  if (!ready) {
    return (
      <main className="min-h-screen bg-paper px-5 py-10 text-ink">
        <p className="font-serif text-4xl">Lò Vi Sóng</p>
        <p className="mt-2 max-w-sm text-muted">Phòng luyện IELTS bốn kỹ năng. Đề gốc, chấm có lý do, lộ trình theo band của bạn.</p>
      </main>
    );
  }
  return <Studio />;
}
