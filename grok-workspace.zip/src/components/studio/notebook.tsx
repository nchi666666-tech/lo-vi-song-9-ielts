import { AttemptChart } from "@/components/studio/charts";
import { Button } from "@/components/ui/button";
import { LISTENING_40, READING_AC_40, READING_GT_40 } from "@/lib/ielts/bands";
import { infoOf } from "@/lib/ielts/catalog";
import type { Spec } from "@/lib/ielts/plan";
import { useStudio } from "@/lib/ielts/store";
import type { BandRow } from "@/lib/ielts/bands";

function Table({ title, rows }: { title: string; rows: BandRow[] }) {
  return (
    <div className="overflow-x-auto rounded-2xl border border-line">
      <p className="bg-moss px-3 py-2 text-sm font-semibold text-forest">{title}</p>
      <table className="w-full text-left text-sm">
        <tbody>
          {rows
            .filter((r) => r.band >= 4)
            .map((r) => (
              <tr key={r.band} className="border-t border-line">
                <td className="px-3 py-2 font-serif">{r.band.toFixed(1)}</td>
                <td className="px-3 py-2">từ {r.min} câu / 40</td>
              </tr>
            ))}
        </tbody>
      </table>
    </div>
  );
}

export function Notebook({ onStart }: { onStart: (spec: Spec) => void }) {
  const attempts = useStudio((s) => s.attempts);
  const mistakes = useStudio((s) => s.mistakes);
  const resolve = useStudio((s) => s.resolveMistake);
  const moduleName = useStudio((s) => s.profile.module);
  const open = mistakes.filter((m) => !m.resolved);
  const points = attempts
    .filter((a) => a.band != null)
    .slice(0, 12)
    .reverse()
    .map((a, i) => ({ label: String(i + 1), band: a.band as number }));

  return (
    <div className="mx-auto flex w-full max-w-3xl flex-col gap-4">
      <header>
        <h1 className="font-serif text-4xl">Sổ tay</h1>
        <p className="text-sm text-muted">Lưu trên máy bạn. Không có diễn đàn giả, không có điểm ngẫu nhiên.</p>
      </header>
      <section className="rounded-3xl border border-line bg-card p-4">
        <h2 className="font-semibold">Các lần có band ước lượng</h2>
        {points.length < 2 ? <p className="mt-2 text-sm text-muted">Làm thêm một bài có điểm để thấy đường.</p> : <AttemptChart points={points} />}
        <ul className="mt-3 flex flex-col gap-2">
          {attempts.slice(0, 8).map((a) => (
            <li key={a.id} className="flex items-baseline justify-between gap-3 border-t border-line pt-2 text-sm">
              <span>
                {infoOf(a.type, a.skill)?.label ?? a.type} · {a.title}
              </span>
              <span className="font-serif">{a.band == null ? a.bandLabel : a.band.toFixed(1)}</span>
            </li>
          ))}
        </ul>
      </section>
      <section className="rounded-3xl border border-line bg-card p-4">
        <div className="flex items-center justify-between gap-3">
          <h2 className="font-semibold">Câu chưa gỡ ({open.length})</h2>
          <Button
            variant="line"
            onClick={() => onStart({ kind: "review", skill: "reading", type: "review", strict: false })}
            disabled={!open.length}
          >
            Ôn
          </Button>
        </div>
        <ul className="mt-3 flex flex-col gap-3">
          {open.slice(0, 12).map((m) => (
            <li key={m.id} className="border-t border-line pt-3 text-sm">
              <p className="font-semibold">{m.prompt}</p>
              <p>Bạn viết: {m.yours || "—"}</p>
              <p>Đáp án: {m.answer}</p>
              <p className="text-muted">{m.why}</p>
              <Button className="mt-2" variant="ghost" onClick={() => resolve(m.id)}>
                Đã hiểu
              </Button>
            </li>
          ))}
        </ul>
      </section>
      <section className="flex flex-col gap-3">
        <h2 className="font-serif text-2xl">Ngưỡng quy đổi tham chiếu</h2>
        <p className="text-sm text-muted">Dùng cho bài đủ 40 câu. Từng đề chính thức có thể lệch nửa band. General Reading cần nhiều câu đúng hơn Academic cho cùng một band.</p>
        <Table title="Listening, Academic và General" rows={LISTENING_40} />
        <Table title={moduleName === "general" ? "Reading General, đang chọn" : "Reading Academic"} rows={moduleName === "general" ? READING_GT_40 : READING_AC_40} />
      </section>
      <section className="rounded-3xl bg-moss p-4 text-sm text-forest">
        <p className="font-semibold">Writing và Speaking không có bảng 40 câu.</p>
        <p className="mt-2">
          Task 2 chấm Task Response, Coherence, Lexical Resource, Grammar. Task 1 dùng Task Achievement thay cho Task Response. Speaking thêm Pronunciation, tiêu chí này app không tự bịa: bạn nghe lại rồi tự đối chiếu. Bản đầy đủ do IELTS công bố trên ielts.org, cập nhật Writing tháng 5/2023.
        </p>
      </section>
    </div>
  );
}
