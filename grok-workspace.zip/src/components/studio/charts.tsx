import {
  Bar,
  CartesianGrid,
  Cell,
  ComposedChart,
  Legend,
  Line,
  Pie,
  PieChart,
  BarChart,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import type { ChartModel } from "@/lib/ielts/types";

const FILLS = ["var(--color-forest)", "var(--color-clay)", "var(--color-ink)", "var(--color-muted)", "var(--color-forest-deep)"];

export function TaskChart({ chart }: { chart: ChartModel }) {
  if (chart.kind === "table") {
    return (
      <div className="overflow-x-auto rounded-2xl border border-line">
        <table className="w-full border-collapse text-left text-sm">
          <caption className="bg-moss px-3 py-2 text-left font-semibold text-forest">{chart.title}</caption>
          <thead>
            <tr>
              {chart.headers.map((h) => (
                <th key={h} className="border-b border-line px-3 py-2 font-semibold">
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {chart.rows.map((row) => (
              <tr key={row.join("-")}>
                {row.map((cell, i) => (
                  <td key={`${cell}-${i}`} className="border-b border-line px-3 py-2">
                    {cell}
                    {i > 0 ? ` ${chart.unit}` : ""}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  }

  if (chart.kind === "pie") {
    return (
      <div className="rounded-2xl border border-line bg-card p-3">
        <p className="px-2 font-semibold">{chart.title}</p>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie data={chart.slices} dataKey="y" nameKey="name" outerRadius={88} label>
                {chart.slices.map((slice, i) => (
                  <Cell key={slice.name} fill={FILLS[i % FILLS.length]} />
                ))}
              </Pie>
              <Tooltip />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>
    );
  }

  if (chart.kind === "mixed") {
    const rows = chart.bars.points.map((p, i) => ({
      x: p.x,
      bar: p.y,
      line: chart.line.points[i]?.y ?? 0,
    }));
    return (
      <div className="rounded-2xl border border-line bg-card p-3">
        <p className="px-2 font-semibold">{chart.title}</p>
        <p className="px-2 text-sm text-muted">
          Cột: {chart.barUnit}. Đường: {chart.lineUnit}.
        </p>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={rows}>
              <CartesianGrid stroke="var(--color-line)" vertical={false} />
              <XAxis dataKey="x" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="bar" name={chart.bars.name} fill="var(--color-forest)" radius={4} />
              <Line dataKey="line" name={chart.line.name} stroke="var(--color-clay)" strokeWidth={2} dot />
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      </div>
    );
  }

  const rows = chart.series[0]?.points.map((p, i) => {
    const row: Record<string, string | number> = { x: p.x };
    for (const series of chart.series) row[series.name] = series.points[i]?.y ?? 0;
    return row;
  });
  const Chart = chart.kind === "line" ? LineChart : BarChart;
  return (
    <div className="rounded-2xl border border-line bg-card p-3">
      <p className="px-2 font-semibold">{chart.title}</p>
      <p className="px-2 text-sm text-muted">Đơn vị: {chart.unit}</p>
      <div className="h-64">
        <ResponsiveContainer width="100%" height="100%">
          <Chart data={rows}>
            <CartesianGrid stroke="var(--color-line)" vertical={false} />
            <XAxis dataKey="x" />
            <YAxis />
            <Tooltip />
            <Legend />
            {chart.series.map((series, i) =>
              chart.kind === "line" ? (
                <Line key={series.name} type="monotone" dataKey={series.name} stroke={FILLS[i % FILLS.length]} strokeWidth={2} dot />
              ) : (
                <Bar key={series.name} dataKey={series.name} fill={FILLS[i % FILLS.length]} radius={4} />
              ),
            )}
          </Chart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

export function AttemptChart({ points }: { points: { label: string; band: number }[] }) {
  if (points.length < 2) return null;
  return (
    <div className="h-48">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={points}>
          <CartesianGrid stroke="var(--color-line)" vertical={false} />
          <XAxis dataKey="label" hide />
          <YAxis domain={[0, 9]} ticks={[4, 5, 6, 7, 8]} width={28} />
          <Tooltip />
          <Line type="monotone" dataKey="band" name="Band ước lượng" stroke="var(--color-forest)" strokeWidth={2} dot />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}
