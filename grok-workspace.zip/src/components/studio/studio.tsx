import { useEffect, useState, type ReactNode } from "react";
import { BookOpen, CalendarDays, House, NotebookPen } from "lucide-react";
import { ExamSession } from "@/components/studio/exam";
import { Home } from "@/components/studio/home";
import { Notebook } from "@/components/studio/notebook";
import { PlanView } from "@/components/studio/plan-view";
import { Practice } from "@/components/studio/practice";
import { ResultView } from "@/components/studio/result";
import { buildLive, type Live } from "@/lib/ielts/session";
import type { Spec } from "@/lib/ielts/plan";
import { useStudio, type Mistake } from "@/lib/ielts/store";
import type { GradePayload } from "@/lib/ielts/types";

export function Studio() {
  const tab = useStudio((s) => s.tab);
  const setTab = useStudio((s) => s.setTab);
  const profile = useStudio((s) => s.profile);
  const mistakes = useStudio((s) => s.mistakes);
  const bump = useStudio((s) => s.bumpSeed);
  const seed = useStudio((s) => s.seed);
  const record = useStudio((s) => s.record);
  const resolve = useStudio((s) => s.resolveMistake);
  const ensure = useStudio((s) => s.ensure);
  const markTick = useStudio((s) => s.markTick);
  const [live, setLive] = useState<Live | null>(null);
  const [grade, setGrade] = useState<GradePayload | null>(null);
  const [tickKey, setTickKey] = useState<string | null>(null);

  useEffect(() => {
    ensure();
  }, [ensure]);

  function openSpec(spec: Spec, key?: string) {
    const next = bump();
    setGrade(null);
    setTickKey(key ?? null);
    setLive(buildLive(spec, next, profile.module, mistakes));
  }

  function again() {
    if (!live) return;
    const next = bump();
    setGrade(null);
    setLive(buildLive(live.spec, next, profile.module, useStudio.getState().mistakes));
  }

  function finish(nextGrade: GradePayload) {
    if (!live) return;
    const wrongs: Mistake[] = (nextGrade.items ?? [])
      .filter((item) => !item.ok)
      .map((item) => ({
        id: `${live.key}:${item.id}`,
        at: Date.now(),
        skill: live.spec.skill,
        type: live.spec.type,
        prompt: item.prompt,
        yours: item.yours,
        answer: item.answer,
        why: item.explain,
        resolved: false,
      }));
    if (live.spec.kind === "review") {
      for (const item of nextGrade.items ?? []) if (item.ok) resolve(item.id);
    }
    if (live.spec.kind !== "vocab") {
      record(
        {
          id: `${live.key}:${Date.now()}`,
          at: Date.now(),
          skill: live.spec.skill,
          module: profile.module,
          type: live.spec.type,
          title: live.title,
          band: nextGrade.band,
          bandLabel: nextGrade.bandLabel,
          correct: nextGrade.correct,
          total: nextGrade.total,
          notes: nextGrade.notes,
          items: nextGrade.items,
          criteria: nextGrade.criteria,
        },
        live.spec.kind === "review" ? [] : wrongs,
      );
    }
    if (tickKey) markTick(tickKey);
    setGrade(nextGrade);
  }

  const showNav = !live || grade != null;

  return (
    <div className="min-h-screen bg-paper text-ink">
      <div className="mx-auto flex w-full max-w-3xl items-center justify-between px-4 pt-4">
        <div className="flex items-center gap-3">
          <span className="grid size-11 place-items-center rounded-full bg-forest font-serif text-paper">Lò</span>
          <div>
            <p className="font-serif text-xl leading-none">Vi Sóng</p>
            <p className="text-xs text-muted">Phòng luyện 4 kỹ năng</p>
          </div>
        </div>
        <p className="text-xs text-muted">{profile.module === "academic" ? "Academic" : "General"}</p>
      </div>
      <main className="px-4 py-5 pb-28">
        {grade && live ? (
          <ResultView live={live} grade={grade} onClose={() => { setLive(null); setGrade(null); setTab("home"); }} onAgain={again} />
        ) : live ? (
          <ExamSession key={live.key} live={live} onExit={() => setLive(null)} onDone={finish} />
        ) : tab === "home" ? (
          <Home onStart={openSpec} />
        ) : tab === "practice" ? (
          <Practice onStart={openSpec} />
        ) : tab === "plan" ? (
          <PlanView onStart={openSpec} />
        ) : (
          <Notebook onStart={openSpec} />
        )}
        <p className="mx-auto mt-8 max-w-3xl text-xs text-muted">
          Đề trong app là đề luyện viết riêng. Band là ước lượng để sửa bài, không phải kết quả thi. Đăng ký thi thật tại hội đồng bạn chọn.
        </p>
      </main>
      {showNav ? (
        <nav className="no-print safe-bottom fixed inset-x-0 bottom-0 border-t border-line bg-card">
          <ul className="mx-auto grid max-w-3xl grid-cols-4">
            <NavButton label="Hôm nay" active={tab === "home" && !grade} onClick={() => { setGrade(null); setLive(null); setTab("home"); }}>
              <House className="size-5" />
            </NavButton>
            <NavButton label="Dạng bài" active={tab === "practice" && !grade} onClick={() => { setGrade(null); setLive(null); setTab("practice"); }}>
              <BookOpen className="size-5" />
            </NavButton>
            <NavButton label="Lộ trình" active={tab === "plan" && !grade} onClick={() => { setGrade(null); setLive(null); setTab("plan"); }}>
              <CalendarDays className="size-5" />
            </NavButton>
            <NavButton label="Sổ tay" active={tab === "notebook" && !grade} onClick={() => { setGrade(null); setLive(null); setTab("notebook"); }}>
              <NotebookPen className="size-5" />
            </NavButton>
          </ul>
        </nav>
      ) : null}
      <span className="sr-only">seed {seed}</span>
    </div>
  );
}

function NavButton({ label, active, onClick, children }: { label: string; active: boolean; onClick: () => void; children: ReactNode }) {
  return (
    <li>
      <button className={`flex min-h-14 w-full flex-col items-center justify-center gap-1 text-xs ${active ? "text-forest" : "text-muted"}`} onClick={onClick}>
        {children}
        {label}
      </button>
    </li>
  );
}
