import { useState } from "react";
import { Button } from "@/components/ui/button";
import { BOOK_PATH, stageIndex } from "@/lib/ielts/catalog";
import { buildPlan, dayIndex, type Spec } from "@/lib/ielts/plan";
import { useStudio } from "@/lib/ielts/store";

export function PlanView({ onStart }: { onStart: (spec: Spec, tickKey?: string) => void }) {
  const profile = useStudio((s) => s.profile);
  const ticks = useStudio((s) => s.ticks);
  const toggle = useStudio((s) => s.toggleTick);
  const restart = useStudio((s) => s.restartPlan);
  const plan = buildPlan(profile);
  const today = dayIndex(profile.planStart, profile.horizon);
  const [week, setWeek] = useState(Math.floor(today / 7) + 1);
  const days = plan.filter((d) => d.week === week);
  const weeks = Math.ceil(profile.horizon / 7);
  const done = Object.values(ticks).filter(Boolean).length;
  const total = plan.reduce((n, d) => n + d.blocks.length, 0);
  const stage = BOOK_PATH[stageIndex(Math.min(...Object.values(profile.current)))];

  return (
    <div className="mx-auto flex w-full max-w-3xl flex-col gap-4">
      <header className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-serif text-4xl">Lộ trình {profile.horizon} ngày</h1>
          <p className="text-sm text-muted">
            Đã tick {done}/{total}. Kế hoạch tự xếp theo band hiện tại, mục tiêu và module. Không chép thời khoá biểu của một giáo trình có bản quyền.
          </p>
        </div>
        <Button variant="line" className="no-print" onClick={() => window.print()}>
          In tuần này
        </Button>
      </header>
      <section className="rounded-3xl border border-line bg-card p-4">
        <h2 className="font-semibold">Sách nên dùng ở mức {stage.stage}</h2>
        <p className="text-sm text-muted">{stage.title}. Mua hoặc mượn bản chính hãng. App không dẫn tới bản scan.</p>
        <ul className="mt-2 list-disc space-y-1 pl-5 text-sm">
          {stage.books.map((book) => (
            <li key={book}>{book}</li>
          ))}
        </ul>
        <p className="mt-3 text-sm">
          Bảng mô tả band đầy đủ nằm trên{" "}
          <a className="underline" href="https://ielts.org" target="_blank" rel="noreferrer">
            ielts.org
          </a>
          .
        </p>
      </section>
      <div className="no-print flex gap-2 overflow-x-auto pb-1">
        {Array.from({ length: weeks }, (_, i) => (
          <Button key={i} variant={week === i + 1 ? "primary" : "line"} onClick={() => setWeek(i + 1)}>
            Tuần {i + 1}
          </Button>
        ))}
      </div>
      {days.map((day) => (
        <section key={day.index} className={`rounded-3xl border p-4 ${day.index === today ? "border-forest bg-moss" : "border-line bg-card"}`}>
          <h2 className="font-serif text-2xl">{day.label}</h2>
          <ul className="mt-2 flex flex-col gap-3">
            {day.blocks.map((block, i) => {
              const key = `${day.index}:${i}`;
              return (
                <li key={key} className="flex flex-col gap-2 border-t border-line pt-3 sm:flex-row sm:items-center sm:justify-between">
                  <div>
                    <p className="font-semibold">
                      {block.title} · {block.minutes} phút
                    </p>
                    <p className="text-sm text-muted">{block.detail}</p>
                  </div>
                  <div className="flex gap-2">
                    <Button variant="line" onClick={() => toggle(key)}>
                      {ticks[key] ? "Bỏ tick" : "Xong"}
                    </Button>
                    <Button onClick={() => onStart(block.spec, key)}>Mở</Button>
                  </div>
                </li>
              );
            })}
          </ul>
        </section>
      ))}
      <Button variant="ghost" className="no-print" onClick={restart}>
        Tính lại từ hôm nay
      </Button>
    </div>
  );
}
