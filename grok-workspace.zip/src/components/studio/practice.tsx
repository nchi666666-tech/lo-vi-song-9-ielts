import { useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { SKILLS, TYPES } from "@/lib/ielts/catalog";
import { kindFor, type Spec } from "@/lib/ielts/plan";
import { useStudio } from "@/lib/ielts/store";
import type { Skill } from "@/lib/ielts/types";

export function Practice({ onStart }: { onStart: (spec: Spec) => void }) {
  const moduleName = useStudio((s) => s.profile.module);
  const [skill, setSkill] = useState<Skill>("listening");
  const [query, setQuery] = useState("");
  const [strict, setStrict] = useState(false);
  const list = useMemo(
    () =>
      TYPES.filter((t) => t.skill === skill && (t.modules.includes(moduleName) || t.id === "vocab" || t.id === "dictation")).filter((t) => {
        const hay = `${t.label} ${t.en}`.toLowerCase();
        return hay.includes(query.trim().toLowerCase());
      }),
    [skill, moduleName, query],
  );

  return (
    <div className="mx-auto flex w-full max-w-3xl flex-col gap-4">
      <header>
        <h1 className="font-serif text-4xl">Đủ dạng</h1>
        <p className="mt-1 text-sm text-muted">
          Module đang chọn: {moduleName === "academic" ? "Academic" : "General"}. Đổi trong hồ sơ ở trang Hôm nay. Mỗi dạng có cách làm và bẫy riêng.
        </p>
      </header>
      <div className="flex flex-wrap gap-2">
        {SKILLS.map((item) => (
          <Button key={item.id} variant={skill === item.id ? "primary" : "line"} onClick={() => setSkill(item.id)}>
            {item.label}
          </Button>
        ))}
      </div>
      <input
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        placeholder="Tìm dạng, ví dụ headings"
        className="w-full rounded-2xl border border-line bg-card px-3 py-3 outline-none focus:border-forest"
        aria-label="Tìm dạng bài"
      />
      <label className="flex min-h-11 items-center gap-3 text-sm">
        <input type="checkbox" checked={strict} onChange={(e) => setStrict(e.target.checked)} />
        Phòng thi: một lượt nghe, không mở transcript, không tạm giờ
      </label>
      <ul className="flex flex-col gap-3">
        {list.map((item) => (
          <li key={`${item.skill}-${item.id}`} className="rounded-3xl border border-line bg-card p-4">
            <div className="flex flex-wrap items-baseline justify-between gap-2">
              <h2 className="font-semibold">{item.label}</h2>
              <span className="text-sm text-muted">{item.minutes}</span>
            </div>
            <p className="text-sm text-muted">{item.en}</p>
            <ol className="mt-2 list-decimal space-y-1 pl-5 text-sm">
              {item.steps.map((step) => (
                <li key={step}>{step}</li>
              ))}
            </ol>
            <p className="mt-2 text-sm text-clay">Bẫy: {item.traps.join(" ")}</p>
            <Button
              className="mt-3"
              onClick={() =>
                onStart({
                  kind: kindFor(item.skill, item.id),
                  skill: item.skill,
                  type: item.id,
                  strict,
                })
              }
            >
              Làm một đề
            </Button>
          </li>
        ))}
      </ul>
    </div>
  );
}
