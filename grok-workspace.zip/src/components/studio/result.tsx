import { useState } from "react";
import { Check, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import type { Live } from "@/lib/ielts/session";
import type { GradePayload } from "@/lib/ielts/types";

export function ResultView({
  live,
  grade,
  onClose,
  onAgain,
}: {
  live: Live;
  grade: GradePayload;
  onClose: () => void;
  onAgain: () => void;
}) {
  const [copied, setCopied] = useState("");
  async function share() {
    const lines = [
      `Lò Vi Sóng · ${live.title}`,
      grade.bandLabel,
      grade.correct != null ? `${grade.correct}/${grade.total} câu` : "",
      grade.criteria?.map((c) => `${c.label}: ${c.band.toFixed(1)}`).join("\n") ?? "",
      "Ước lượng luyện tập, không phải điểm thi Cambridge, IDP hay British Council.",
    ].filter(Boolean);
    const text = lines.join("\n");
    try {
      if (navigator.share) {
        await navigator.share({ text });
        setCopied("Đã mở chia sẻ.");
        return;
      }
    } catch {
      /* user cancelled or share failed */
    }
    try {
      await navigator.clipboard.writeText(text);
      setCopied("Đã chép. Dán vào nhóm.");
    } catch {
      setCopied(text);
    }
  }

  return (
    <div className="mx-auto flex w-full max-w-3xl flex-col gap-4">
      <p className="text-sm font-semibold text-forest">Kết quả luyện</p>
      <h1 className="font-serif text-4xl leading-none">{grade.band == null ? grade.bandLabel : grade.band.toFixed(1)}</h1>
      <p className="text-muted">{grade.bandLabel}</p>
      <p className="rounded-2xl bg-moss px-3 py-3 text-sm text-forest">{grade.caution}</p>
      {grade.criteria ? (
        <ul className="flex flex-col gap-2">
          {grade.criteria.map((c) => (
            <li key={c.key} className="rounded-2xl border border-line bg-card p-3">
              <div className="flex items-baseline justify-between gap-3">
                <span className="font-semibold">{c.label}</span>
                <span className="font-serif text-2xl">{c.band.toFixed(1)}</span>
              </div>
              <p className="mt-1 text-sm text-muted">{c.note}</p>
            </li>
          ))}
        </ul>
      ) : null}
      {grade.notes.length ? (
        <ul className="list-disc space-y-1 pl-5 text-sm">
          {grade.notes.map((n) => (
            <li key={n}>{n}</li>
          ))}
        </ul>
      ) : null}
      {grade.outline ? (
        <section className="rounded-2xl border border-line bg-card p-4">
          <h2 className="font-semibold">Dàn ý sau khi nộp</h2>
          <ul className="mt-2 list-disc space-y-1 pl-5 text-sm">
            {grade.outline.map((line) => (
              <li key={line}>{line}</li>
            ))}
          </ul>
        </section>
      ) : null}
      {grade.items ? (
        <ul className="flex flex-col gap-2">
          {grade.items.map((item) => (
            <li key={item.id} className={`rounded-2xl border p-3 ${item.ok ? "border-line bg-card" : "border-clay bg-clay-soft"}`}>
              <div className="flex items-start gap-2">
                {item.ok ? <Check className="mt-0.5 size-4 text-forest" /> : <X className="mt-0.5 size-4 text-clay" />}
                <div>
                  <p className="font-semibold">{item.prompt}</p>
                  <p className="text-sm">Bạn: {item.yours || "—"}</p>
                  {!item.ok ? <p className="text-sm">Đáp án: {item.answer}</p> : null}
                  <p className="mt-1 text-sm text-muted">{item.explain}</p>
                </div>
              </div>
            </li>
          ))}
        </ul>
      ) : null}
      <div className="flex flex-wrap gap-2">
        <Button onClick={onAgain}>Đề khác cùng dạng</Button>
        <Button variant="line" onClick={share}>
          Chép để đăng nhóm
        </Button>
        <Button variant="ghost" onClick={onClose}>
          Về trang chủ
        </Button>
      </div>
      {copied ? <p className="text-sm text-forest">{copied}</p> : null}
    </div>
  );
}
