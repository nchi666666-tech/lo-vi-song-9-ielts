function Room({ x, y, w, h, label }: { x: number; y: number; w: number; h: number; label: string }) {
  return (
    <g>
      <rect x={x} y={y} width={w} height={h} rx="8" fill="var(--color-moss)" stroke="var(--color-forest)" strokeWidth="2" />
      <text x={x + w / 2} y={y + h / 2 + 8} textAnchor="middle" fill="var(--color-ink)" fontSize="22" fontFamily="Georgia, serif">
        {label}
      </text>
    </g>
  );
}

export function CentrePlan() {
  return (
    <figure className="rounded-2xl border border-line bg-card p-3">
      <svg viewBox="0 0 360 250" className="h-auto w-full" role="img" aria-label="Sơ đồ trung tâm, các phòng chỉ ghi chữ cái">
        <Room x={8} y={8} w={108} h={68} label="B" />
        <Room x={126} y={8} w={108} h={68} label="E" />
        <Room x={244} y={8} w={108} h={68} label="G" />
        <Room x={8} y={86} w={108} h={68} label="A" />
        <Room x={126} y={86} w={108} h={68} label="C" />
        <Room x={244} y={86} w={108} h={68} label="D" />
        <Room x={8} y={164} w={108} h={68} label="H" />
        <rect x="126" y="164" width="108" height="68" rx="8" fill="var(--color-paper)" stroke="var(--color-clay)" strokeWidth="2" />
        <text x="180" y="204" textAnchor="middle" fill="var(--color-clay)" fontSize="16">
          Vào
        </text>
        <Room x={244} y={164} w={108} h={68} label="F" />
      </svg>
      <figcaption className="px-1 pt-2 text-sm text-muted">Bắc ở phía trên. Lối vào ở mé dưới, giữa sơ đồ.</figcaption>
    </figure>
  );
}

export function PierPlan() {
  const shops = [
    { x: 8, label: "A" },
    { x: 78, label: "B" },
    { x: 148, label: "C" },
    { x: 218, label: "D" },
    { x: 288, label: "E" },
  ];
  return (
    <figure className="rounded-2xl border border-line bg-card p-3">
      <svg viewBox="0 0 360 180" className="h-auto w-full" role="img" aria-label="Cầu cảng nhìn từ trên, năm quầy A đến E, lối vào bên trái">
        <text x="8" y="22" fill="var(--color-clay)" fontSize="14">
          Lối vào, phía tây
        </text>
        {shops.map((shop) => (
          <g key={shop.label}>
            <rect x={shop.x} y="48" width="64" height="64" rx="8" fill="var(--color-moss)" stroke="var(--color-forest)" strokeWidth="2" />
            <text x={shop.x + 32} y="88" textAnchor="middle" fill="var(--color-ink)" fontSize="22" fontFamily="Georgia, serif">
              {shop.label}
            </text>
          </g>
        ))}
        <text x="180" y="150" textAnchor="middle" fill="var(--color-muted)" fontSize="14">
          Mặt nước ở phía dưới hàng quầy
        </text>
      </svg>
      <figcaption className="px-1 pt-2 text-sm text-muted">Đứng ở lối vào bên trái và nhìn về phía E.</figcaption>
    </figure>
  );
}

export function FilterPlan() {
  const tanks = [
    { y: 12, label: "A" },
    { y: 78, label: "B" },
    { y: 144, label: "C" },
    { y: 210, label: "D" },
  ];
  return (
    <figure className="rounded-2xl border border-line bg-card p-3">
      <svg viewBox="0 0 220 300" className="mx-auto h-auto w-full max-w-56" role="img" aria-label="Bốn bể lọc xếp dọc, nhãn A đến D">
        {tanks.map((tank) => (
          <g key={tank.label}>
            <rect x="40" y={tank.y} width="140" height="52" rx="8" fill="var(--color-moss)" stroke="var(--color-forest)" strokeWidth="2" />
            <text x="110" y={tank.y + 34} textAnchor="middle" fill="var(--color-ink)" fontSize="22" fontFamily="Georgia, serif">
              {tank.label}
            </text>
          </g>
        ))}
        <path d="M110 64 V78 M110 130 V144 M110 196 V210 M110 262 V286" stroke="var(--color-forest)" strokeWidth="2" />
        <text x="110" y="298" textAnchor="middle" fill="var(--color-muted)" fontSize="12">
          ống ra
        </text>
      </svg>
      <figcaption className="px-1 pt-2 text-sm text-muted">Nước bẩn đi từ A xuống D.</figcaption>
    </figure>
  );
}
