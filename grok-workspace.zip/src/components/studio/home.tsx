import { Button } from "@/components/ui/button";
import { infoOf, SKILLS } from "@/lib/ielts/catalog";
import { buildPlan, dayIndex, kindFor } from "@/lib/ielts/plan";
import type { Spec } from "@/lib/ielts/plan";
import { useStudio } from "@/lib/ielts/store";
import type { Skill } from "@/lib/ielts/types";

function greeting(hour: number) {
  if (hour < 11) return "Chào buổi sáng";
  if (hour < 18) return "Chào buổi chiều";
  return "Chào buổi tối";
}

function streakFrom(dates: number[]) {
  const days = new Set(dates.map((at) => new Date(at).toDateString()));
  const cursor = new Date();
  if (!days.has(cursor.toDateString())) cursor.setDate(cursor.getDate() - 1);
  let n = 0;
  while (days.has(cursor.toDateString())) {
    n += 1;
    cursor.setDate(cursor.getDate() - 1);
  }
  return n;
}

export function Home({ onStart }: { onStart: (spec: Spec, tickKey?: string) => void }) {
  const profile = useStudio((s) => s.profile);
  const attempts = useStudio((s) => s.attempts);
  const mistakes = useStudio((s) => s.mistakes);
  const ticks = useStudio((s) => s.ticks);
  const patch = useStudio((s) => s.patchProfile);
  const setCurrent = useStudio((s) => s.setCurrent);
  const plan = buildPlan(profile);
  const index = dayIndex(profile.planStart, profile.horizon);
  const today = plan[index];
  const hour = new Date().getHours();
  const streak = streakFrom(attempts.map((a) => a.at));
  const open = mistakes.filter((m) => !m.resolved);
  const counts = new Map<string, { skill: Skill; type: string; n: number }>();
  for (const mistake of open) {
    const key = `${mistake.skill}:${mistake.type}`;
    const row = counts.get(key) ?? { skill: mistake.skill, type: mistake.type, n: 0 };
    row.n += 1;
    counts.set(key, row);
  }
  const weak = [...counts.values()].sort((a, b) => b.n - a.n)[0];
  const daysLeft = profile.examDate
    ? Math.ceil((new Date(profile.examDate).getTime() - Date.now()) / 86400000)
    : null;

  return (
    <div className="mx-auto flex w-full max-w-3xl flex-col gap-5">
      <header>
        <p className="text-sm text-muted">
          {greeting(hour)}
          {profile.nickname ? `, ${profile.nickname}` : ""}
        </p>
        <h1 className="font-serif text-4xl leading-tight">Hôm nay luyện đúng chỗ đang yếu.</h1>
        <p className="mt-2 text-sm text-muted">
          {streak > 0 ? `${streak} ngày có bài. ` : "Chưa có chuỗi ngày. "}
          {daysLeft != null && daysLeft >= 0 ? `Còn ${daysLeft} ngày tới lịch thi. ` : ""}
          {open.length} câu chưa gỡ trong sổ.
        </p>
      </header>

      <section className="rounded-3xl border border-line bg-card p-4">
        <div className="flex items-baseline justify-between gap-3">
          <h2 className="font-serif text-2xl">{today?.label}</h2>
          <span className="text-sm text-muted">{profile.minutes} phút</span>
        </div>
        <ul className="mt-3 flex flex-col gap-3">
          {today?.blocks.map((block, i) => {
            const key = `${today.index}:${i}`;
            return (
              <li key={key} className="flex flex-col gap-2 border-t border-line pt-3 first:border-t-0 first:pt-0 sm:flex-row sm:items-center sm:justify-between">
                <div>
                  <p className="font-semibold">{block.title}</p>
                  <p className="text-sm text-muted">{block.detail}</p>
                </div>
                <div className="flex gap-2">
                  <Button variant={ticks[key] ? "moss" : "primary"} onClick={() => onStart(block.spec, key)}>
                    {ticks[key] ? "Làm lại" : "Làm"}
                  </Button>
                </div>
              </li>
            );
          })}
        </ul>
      </section>

      {weak ? (
        <section className="rounded-3xl bg-clay-soft p-4 text-clay">
          <p className="font-semibold">Dạng sai nhiều nhất: {infoOf(weak.type, weak.skill)?.label ?? weak.type}</p>
          <p className="mt-1 text-sm">{weak.n} câu chưa gỡ.</p>
          <Button
            className="mt-3"
            variant="clay"
            onClick={() =>
              onStart({
                kind: kindFor(weak.skill, weak.type),
                skill: weak.skill,
                type: weak.type,
                strict: false,
              })
            }
          >
            Luyện dạng này
          </Button>
        </section>
      ) : null}

      <details className="rounded-3xl border border-line bg-card p-4">
        <summary className="cursor-pointer font-semibold">Hồ sơ để lộ trình đổi theo bạn</summary>
        <div className="mt-4 flex flex-col gap-4">
          <label className="text-sm">
            Tên hiển thị
            <input
              className="mt-1 w-full rounded-xl border border-line bg-paper px-3 py-3"
              value={profile.nickname}
              onChange={(e) => patch({ nickname: e.target.value.slice(0, 40) })}
            />
          </label>
          <div className="flex flex-wrap gap-2">
            <Button variant={profile.module === "academic" ? "primary" : "line"} onClick={() => patch({ module: "academic" })}>
              Academic
            </Button>
            <Button variant={profile.module === "general" ? "primary" : "line"} onClick={() => patch({ module: "general" })}>
              General
            </Button>
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            {SKILLS.map((skill) => (
              <BandStep
                key={skill.id}
                label={skill.label}
                value={profile.current[skill.id]}
                onChange={(band) => setCurrent(skill.id, band)}
              />
            ))}
          </div>
          <BandStep label="Band mục tiêu" value={profile.target} onChange={(target) => patch({ target })} />
          <label className="text-sm">
            Phút mỗi ngày
            <select
              className="mt-1 w-full rounded-xl border border-line bg-paper px-3 py-3"
              value={profile.minutes}
              onChange={(e) => patch({ minutes: Number(e.target.value) })}
            >
              <option value={60}>60 phút</option>
              <option value={90}>90 phút</option>
              <option value={150}>150 phút</option>
            </select>
          </label>
          <div className="flex gap-2">
            <Button variant={profile.horizon === 30 ? "primary" : "line"} onClick={() => patch({ horizon: 30 })}>
              30 ngày
            </Button>
            <Button variant={profile.horizon === 90 ? "primary" : "line"} onClick={() => patch({ horizon: 90 })}>
              90 ngày
            </Button>
          </div>
          <label className="text-sm">
            Ngày thi, nếu đã có
            <input
              type="date"
              className="mt-1 w-full rounded-xl border border-line bg-paper px-3 py-3"
              value={profile.examDate}
              onChange={(e) => patch({ examDate: e.target.value })}
            />
          </label>
          <label className="text-sm">
            Giọng máy đọc
            <select
              className="mt-1 w-full rounded-xl border border-line bg-paper px-3 py-3"
              value={profile.accent}
              onChange={(e) => patch({ accent: e.target.value as typeof profile.accent })}
            >
              <option value="en-GB">Anh-Anh, nếu máy có</option>
              <option value="en-US">Anh-Mỹ, nếu máy có</option>
              <option value="en-AU">Anh-Úc, nếu máy có</option>
            </select>
          </label>
        </div>
      </details>
    </div>
  );
}

function BandStep({ label, value, onChange }: { label: string; value: number; onChange: (n: number) => void }) {
  return (
    <div className="flex items-center justify-between gap-3 rounded-2xl border border-line px-3 py-2">
      <span className="text-sm">{label}</span>
      <div className="flex items-center gap-2">
        <Button variant="line" size="icon" aria-label={`Giảm ${label}`} onClick={() => onChange(Math.max(0, Math.round((value - 0.5) * 2) / 2))}>
          −
        </Button>
        <span className="w-8 text-center font-serif">{value.toFixed(1)}</span>
        <Button variant="line" size="icon" aria-label={`Tăng ${label}`} onClick={() => onChange(Math.min(9, Math.round((value + 0.5) * 2) / 2))}>
          +
        </Button>
      </div>
    </div>
  );
}
