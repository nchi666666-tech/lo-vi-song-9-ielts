import { useEffect, useMemo, useRef, useState } from "react";
import { ArrowLeft, Pause, Play, Square } from "lucide-react";
import { Button } from "@/components/ui/button";
import { TaskChart } from "@/components/studio/charts";
import { CentrePlan, FilterPlan, PierPlan } from "@/components/studio/figures";
import { estimateRatio, formatBand, LISTENING_40, READING_AC_40, READING_GT_40, roundHalf } from "@/lib/ielts/bands";
import { answerOk, choiceOk, normalizeAnswer, wordList } from "@/lib/ielts/grade";
import type { Live } from "@/lib/ielts/session";
import { pronunciationNote, scoreTranscript } from "@/lib/ielts/speaking-score";
import type { GradePayload, Option, Question } from "@/lib/ielts/types";
import { THEMES } from "@/lib/ielts/vocab";
import { scoreWriting, writingOutline } from "@/lib/ielts/writing-score";
import { useStudio } from "@/lib/ielts/store";

function clock(total: number) {
  const s = Math.max(0, total);
  const m = Math.floor(s / 60);
  const r = s % 60;
  return `${String(m).padStart(2, "0")}:${String(r).padStart(2, "0")}`;
}

function scriptSentences(script: string) {
  return script
    .split(/(?<=[.?!])\s+/)
    .map((s) => s.trim())
    .filter((s) => s.split(/\s+/).length >= 6);
}

function speak(text: string, lang: string, rate: number, onend?: () => void) {
  if (typeof window === "undefined" || !window.speechSynthesis) return;
  window.speechSynthesis.cancel();
  const utter = new SpeechSynthesisUtterance(text);
  utter.lang = lang;
  utter.rate = rate;
  const voice =
    window.speechSynthesis.getVoices().find((v) => v.lang === lang) ||
    window.speechSynthesis.getVoices().find((v) => v.lang.startsWith(lang.slice(0, 2)));
  if (voice) utter.voice = voice;
  if (onend) utter.onend = onend;
  window.speechSynthesis.speak(utter);
}

export function ExamSession({ live, onExit, onDone }: { live: Live; onExit: () => void; onDone: (grade: GradePayload) => void }) {
  const accent = useStudio((s) => s.profile.accent);
  const known = useStudio((s) => s.knownVocab);
  const toggleVocab = useStudio((s) => s.toggleVocab);
  const [phase, setPhase] = useState<"cover" | "run">("cover");
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [multi, setMulti] = useState<Record<string, string[]>>({});
  const [essay, setEssay] = useState("");
  const [transcript, setTranscript] = useState("");
  const [pron, setPron] = useState<number | null>(null);
  const [left, setLeft] = useState(live.minutes * 60);
  const [running, setRunning] = useState(false);
  const [played, setPlayed] = useState(false);
  const [showScript, setShowScript] = useState(false);
  const [audioError, setAudioError] = useState("");
  const [blobUrl, setBlobUrl] = useState("");
  const [recording, setRecording] = useState(false);
  const [speakLeft, setSpeakLeft] = useState<number | null>(null);
  const [partStep, setPartStep] = useState(0);
  const [dictIndex, setDictIndex] = useState(0);
  const [dictDraft, setDictDraft] = useState("");
  const [dictMarks, setDictMarks] = useState<Record<number, string>>({});
  const endRef = useRef(false);
  const recRef = useRef<MediaRecorder | null>(null);
  const recogRef = useRef<{ stop: () => void } | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const started = useRef(0);

  const sentences = useMemo(() => (live.paper?.script ? scriptSentences(live.paper.script) : []), [live.paper]);
  const words = wordList(essay).length;

  useEffect(() => {
    const load = () => window.speechSynthesis?.getVoices();
    load();
    window.speechSynthesis?.addEventListener("voiceschanged", load);
    return () => {
      window.speechSynthesis?.cancel();
      window.speechSynthesis?.removeEventListener("voiceschanged", load);
      streamRef.current?.getTracks().forEach((t) => t.stop());
    };
  }, []);

  useEffect(() => {
    if (!running) return;
    const id = window.setInterval(() => {
      setLeft((s) => {
        if (s <= 1) {
          window.clearInterval(id);
          return 0;
        }
        return s - 1;
      });
    }, 1000);
    return () => window.clearInterval(id);
  }, [running]);

  useEffect(() => {
    if (phase !== "run" || left !== 0 || live.spec.kind === "vocab") return;
    finish();
    // Called on the render where the clock hits zero, so answers are current.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [left, phase]);

  useEffect(() => {
    if (speakLeft == null) return;
    if (speakLeft <= 0) return;
    const id = window.setTimeout(() => setSpeakLeft((s) => (s == null ? s : s - 1)), 1000);
    return () => window.clearTimeout(id);
  }, [speakLeft]);

  function begin() {
    endRef.current = false;
    setPhase("run");
    setRunning(true);
    setLeft(live.minutes * 60);
    started.current = Date.now();
  }

  function setAnswer(id: string, value: string) {
    setAnswers((a) => ({ ...a, [id]: value }));
  }

  function toggleMulti(id: string, option: string) {
    setMulti((m) => {
      const cur = m[id] ?? [];
      const next = cur.includes(option) ? cur.filter((x) => x !== option) : [...cur, option];
      return { ...m, [id]: next };
    });
  }

  function playScript() {
    if (!live.paper?.script) return;
    if (live.spec.strict && played) return;
    setPlayed(true);
    speak(live.paper.script, accent, live.spec.strict ? 1 : 0.92);
  }

  function playSentence() {
    const line = sentences[dictIndex];
    if (line) speak(line, accent, 0.86);
  }

  async function toggleRecord() {
    if (recording) {
      recRef.current?.stop();
      try {
        recogRef.current?.stop();
      } catch {
        /* already stopped */
      }
      setRecording(false);
      return;
    }
    setAudioError("");
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;
      const rec = new MediaRecorder(stream);
      const chunks: Blob[] = [];
      rec.ondataavailable = (e) => {
        if (e.data.size) chunks.push(e.data);
      };
      rec.onstop = () => {
        const blob = new Blob(chunks, { type: rec.mimeType || "audio/webm" });
        setBlobUrl((old) => {
          if (old) URL.revokeObjectURL(old);
          return URL.createObjectURL(blob);
        });
        stream.getTracks().forEach((t) => t.stop());
      };
      rec.start();
      recRef.current = rec;
      setRecording(true);
      const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
      if (SR) {
        const recog = new SR();
        recog.lang = accent;
        recog.continuous = true;
        recog.interimResults = true;
        recog.onresult = (event) => {
          let text = "";
          for (let i = 0; i < event.results.length; i++) text += `${event.results[i][0].transcript} `;
          setTranscript(text.trim());
        };
        recog.onerror = () => setAudioError("Máy không chép được giọng. Bạn vẫn nghe lại và dán transcript.");
        recog.start();
        recogRef.current = recog;
      }
    } catch {
      setAudioError("Trình duyệt không mở micro. Hãy dán transcript hoặc tự chấm sau khi nói.");
    }
  }

  function finish() {
    if (endRef.current) return;
    endRef.current = true;
    setRunning(false);
    window.speechSynthesis?.cancel();
    onDone(grade());
  }

  function grade(): GradePayload {
    if (live.writing) {
      const scored = scoreWriting(live.writing, essay);
      return {
        band: scored.band,
        bandLabel: `Ước lượng ${formatBand(scored.band)} cho riêng task này`,
        caution: "Không phải điểm Writing cả bài (Task 2 nặng gấp đôi Task 1) và không phải giám khảo.",
        criteria: scored.criteria,
        notes: scored.notes,
        outline: writingOutline(live.writing),
      };
    }
    if (live.speaking) {
      const seconds = Math.max(30, Math.round((Date.now() - started.current) / 1000));
      const textScore = scoreTranscript(transcript, seconds);
      const pronScore = pronunciationNote(pron);
      const criteria = [...textScore.criteria, ...(pronScore ? [pronScore] : [])];
      const band =
        criteria.length === 0
          ? null
          : roundHalf(criteria.reduce((sum, c) => sum + c.band, 0) / criteria.length);
      return {
        band,
        bandLabel: band == null ? "Chưa đủ dữ liệu để chấm" : `Ước lượng ${formatBand(band)}`,
        caution: pronScore
          ? "Ba tiêu chí đầu đọc từ transcript. Pronunciation là bạn tự đối chiếu, không phải máy nghe."
          : "Chưa chấm phát âm. Nghe lại bản thu và chọn mức trước khi nộp nếu muốn đủ 4 tiêu chí.",
        criteria,
        notes: textScore.notes,
      };
    }
    if (live.spec.kind === "dictation") {
      const marks = { ...dictMarks };
      if (dictDraft.trim()) marks[dictIndex] = dictDraft;
      const total = sentences.length;
      let correct = 0;
      const items = sentences.map((sentence, i) => {
        const yours = marks[i] ?? "";
        const ok = normalizeAnswer(yours) === normalizeAnswer(sentence);
        if (ok) correct += 1;
        return { id: String(i), prompt: `Câu ${i + 1}`, yours, answer: sentence, ok, explain: ok ? "Khớp." : "So lại từng từ, kể cả mạo từ." };
      });
      return {
        band: null,
        bandLabel: `Chính tả ${correct}/${total}`,
        caution: "Bài chép không quy đổi ra band. Nó chỉ cho biết tai bạn bắt được bao nhiêu từ.",
        correct,
        total,
        notes: [`Giọng máy đọc, không phải giám khảo.`],
        items,
      };
    }
    if (live.review) {
      const items = live.review.map((m) => {
        const yours = answers[m.id] ?? "";
        const marked = choiceOk(yours, [m.answer]);
        const gap = answerOk(yours, [m.answer]);
        const ok = marked.ok || gap.ok;
        return { id: m.id, prompt: m.prompt, yours, answer: m.answer, ok, explain: m.why };
      });
      const correct = items.filter((i) => i.ok).length;
      return {
        band: null,
        bandLabel: `Ôn lỗi ${correct}/${items.length || 0}`,
        caution: "Đây là câu bạn đã sai, không phải một đề mới.",
        correct,
        total: items.length,
        notes: [],
        items,
      };
    }
    if (!live.paper) {
      return { band: null, bandLabel: "Không có bài", caution: live.note ?? "", notes: [] };
    }
    const items = live.paper.questions.map((q) => {
      const yours = q.kind === "multi" ? (multi[q.id] ?? []).slice().sort().join(" ") : (answers[q.id] ?? "");
      const marked = q.kind === "gap" ? answerOk(yours, q.accept, q.wordLimit) : choiceOk(yours, q.accept);
      return { id: q.id, prompt: q.prompt, yours, answer: q.accept[0], ok: marked.ok, explain: marked.ok ? q.explain : `${marked.reason} ${q.explain}` };
    });
    const correct = items.filter((i) => i.ok).length;
    const table = live.paper.skill === "listening" ? LISTENING_40 : live.module === "general" ? READING_GT_40 : READING_AC_40;
    const estimate = estimateRatio(correct, items.length, table);
    const caution =
      items.length < 20
        ? `Bài ${items.length} câu. Band ${formatBand(estimate.band)} là nếu bạn giữ đúng tỷ lệ này trên 40 câu ${live.paper.skill === "listening" ? "Listening" : live.module === "general" ? "Reading General" : "Reading Academic"}. Bài ngắn dễ lệch nửa band.`
        : "Quy đổi theo ngưỡng công bố tham chiếu. Đề thật có thể lệch nửa band.";
    return {
      band: estimate.band,
      bandLabel: `Ước lượng ${formatBand(estimate.band)}`,
      caution,
      correct,
      total: items.length,
      raw40: estimate.raw40,
      notes: [`Đúng ${correct}/${items.length}. Tương đương khoảng ${estimate.raw40.toFixed(1)}/40.`],
      items,
    };
  }

  const usedShared = new Set(
    Object.entries(answers)
      .filter(([, v]) => v)
      .map(([, v]) => v),
  );

  return (
    <div className="mx-auto flex w-full max-w-3xl flex-col gap-4">
      <div className="no-print sticky top-0 z-10 flex items-center justify-between gap-3 border-b border-line bg-paper/95 py-3 backdrop-blur">
        <Button variant="ghost" size="md" onClick={onExit}>
          <ArrowLeft className="size-4" />
          Thoát
        </Button>
        <div className="text-right">
          <p className="font-serif text-2xl leading-none">{phase === "cover" ? clock(live.minutes * 60) : clock(left)}</p>
          <p className="text-xs text-muted">{live.spec.strict ? "Phòng thi" : "Luyện"}</p>
        </div>
      </div>

      {phase === "cover" ? (
        <Cover live={live} onBegin={begin} />
      ) : live.spec.kind === "vocab" && live.theme != null ? (
        <VocabPane themeIndex={live.theme} known={known} toggle={toggleVocab} onDone={() => onDone({ band: null, bandLabel: "Đã xem cụm từ", caution: "Không chấm band.", notes: [] })} />
      ) : live.spec.kind === "dictation" ? (
        <DictationPane
          sentences={sentences}
          index={dictIndex}
          draft={dictDraft}
          marks={dictMarks}
          onDraft={setDictDraft}
          onPlay={playSentence}
          onCheck={() => {
            setDictMarks((m) => ({ ...m, [dictIndex]: dictDraft }));
            setDictDraft("");
            setDictIndex((i) => Math.min(sentences.length - 1, i + 1));
          }}
          onSubmit={finish}
        />
      ) : live.writing ? (
        <WritingPane task={live.writing} essay={essay} words={words} onChange={setEssay} onSubmit={finish} />
      ) : live.speaking ? (
        <SpeakingPane
          task={live.speaking}
          step={partStep}
          setStep={setPartStep}
          transcript={transcript}
          setTranscript={setTranscript}
          pron={pron}
          setPron={setPron}
          recording={recording}
          blobUrl={blobUrl}
          audioError={audioError}
          speakLeft={speakLeft}
          onRecord={toggleRecord}
          onPrep={() => setSpeakLeft(live.speaking?.parts[partStep]?.prep ?? 60)}
          onSpeak={() => setSpeakLeft(live.speaking?.parts[partStep]?.speak ?? 120)}
          onSubmit={finish}
        />
      ) : live.paper ? (
        <ObjectivePane
          live={live}
          answers={answers}
          multi={multi}
          usedShared={usedShared}
          showScript={showScript}
          played={played}
          running={running}
          strict={live.spec.strict}
          onAnswer={setAnswer}
          onMulti={toggleMulti}
          onPlay={playScript}
          onToggleRun={() => setRunning((v) => !v)}
          onScript={() => setShowScript(true)}
          onSubmit={finish}
        />
      ) : (
        <p className="rounded-2xl border border-line bg-card p-4">{live.note}</p>
      )}
    </div>
  );
}

function Cover({ live, onBegin }: { live: Live; onBegin: () => void }) {
  return (
    <section className="flex flex-col gap-4 rounded-3xl border border-line bg-card p-5">
      <p className="text-sm font-semibold uppercase tracking-wide text-forest">Đề luyện gốc · không phải đề Cambridge</p>
      <h1 className="font-serif text-3xl leading-tight">{live.title}</h1>
      {live.paper ? <p className="text-sm text-muted">{live.paper.section}</p> : null}
      <p className="text-base">{live.paper?.instruction || live.writing?.prompt.split("\n")[0] || live.note || "Làm bài rồi mới xem đáp án."}</p>
      <ul className="flex flex-col gap-2 text-sm text-muted">
        <li>Thời gian gợi ý: {live.minutes} phút. Hết giờ thì nộp.</li>
        <li>Listening và Reading chấm đúng/sai theo đáp án, rồi quy đổi tỷ lệ.</li>
        <li>Writing và Speaking đối chiếu tiêu chí công khai. Máy không tự nhận là giám khảo.</li>
      </ul>
      {live.note ? <p className="rounded-2xl bg-clay-soft px-3 py-2 text-sm text-clay">{live.note}</p> : null}
      <Button size="lg" onClick={onBegin}>
        Bắt đầu
      </Button>
    </section>
  );
}

function ObjectivePane(props: {
  live: Live;
  answers: Record<string, string>;
  multi: Record<string, string[]>;
  usedShared: Set<string>;
  showScript: boolean;
  played: boolean;
  running: boolean;
  strict: boolean;
  onAnswer: (id: string, value: string) => void;
  onMulti: (id: string, option: string) => void;
  onPlay: () => void;
  onToggleRun: () => void;
  onScript: () => void;
  onSubmit: () => void;
}) {
  const paper = props.live.paper!;
  const [pane, setPane] = useState<"text" | "ask">(paper.passage || paper.figure ? "text" : "ask");
  const material = (
    <div className="flex flex-col gap-3">
      {paper.figure === "centre" ? <CentrePlan /> : null}
      {paper.figure === "filter" ? <FilterPlan /> : null}
      {paper.figure === "pier" ? <PierPlan /> : null}
      {paper.passage ? <article className="whitespace-pre-wrap font-serif text-base leading-relaxed">{paper.passage}</article> : null}
      {paper.script ? (
        <div className="flex flex-col gap-2">
          <div className="flex flex-wrap gap-2">
            <Button variant="moss" onClick={props.onPlay} disabled={props.strict && props.played}>
              <Play className="size-4" />
              {props.played ? "Nghe lại" : "Phát audio"}
            </Button>
            {!props.strict ? (
              <Button variant="line" onClick={props.onToggleRun}>
                {props.running ? <Pause className="size-4" /> : <Play className="size-4" />}
                {props.running ? "Tạm giờ" : "Tiếp tục giờ"}
              </Button>
            ) : null}
            {!props.strict ? (
              <Button variant="ghost" onClick={props.onScript}>
                Mở transcript
              </Button>
            ) : null}
          </div>
          <p className="text-sm text-muted">Giọng máy trên máy bạn. Phòng thi chỉ cho nghe một lượt.</p>
          {props.showScript && !props.strict ? (
            <p className="whitespace-pre-wrap rounded-2xl bg-moss p-3 text-sm">{paper.script}</p>
          ) : null}
        </div>
      ) : null}
      {paper.shared ? (
        <div className="rounded-2xl border border-line p-3">
          <p className="mb-2 text-sm font-semibold">{paper.shared.note}</p>
          <ul className="flex flex-col gap-1 text-sm">
            {paper.shared.options.map((o) => (
              <li key={o.id}>
                <span className="font-semibold">{o.label.length < 4 ? o.id : ""}</span> {o.label.length < 4 ? "" : o.label}
              </li>
            ))}
          </ul>
        </div>
      ) : null}
    </div>
  );
  const asks = (
    <div className="flex flex-col gap-4">
      <p className="text-sm text-muted">{paper.instruction}</p>
      {paper.questions.map((q) => (
        <QuestionField
          key={q.id}
          q={q}
          shared={q.options ? undefined : paper.shared?.options}
          exclusive={Boolean(paper.shared?.exclusive && !q.options)}
          used={props.usedShared}
          value={props.answers[q.id] ?? ""}
          checks={props.multi[q.id] ?? []}
          onChange={props.onAnswer}
          onMulti={props.onMulti}
        />
      ))}
      <Button size="lg" onClick={props.onSubmit}>
        Nộp bài
      </Button>
    </div>
  );
  return (
    <div className="flex flex-col gap-4">
      <div className="grid grid-cols-2 gap-2 md:hidden">
        <Button variant={pane === "text" ? "primary" : "line"} onClick={() => setPane("text")}>
          Đề
        </Button>
        <Button variant={pane === "ask" ? "primary" : "line"} onClick={() => setPane("ask")}>
          Câu hỏi
        </Button>
      </div>
      <div className="hidden gap-6 md:grid md:grid-cols-2">
        {material}
        {asks}
      </div>
      <div className="md:hidden">{pane === "text" ? material : asks}</div>
    </div>
  );
}

function QuestionField({
  q,
  shared,
  exclusive,
  used,
  value,
  checks,
  onChange,
  onMulti,
}: {
  q: Question;
  shared?: Option[];
  exclusive: boolean;
  used: Set<string>;
  value: string;
  checks: string[];
  onChange: (id: string, value: string) => void;
  onMulti: (id: string, option: string) => void;
}) {
  const options = q.options ?? shared ?? [];
  return (
    <fieldset className="rounded-2xl border border-line bg-card p-3">
      <legend className="px-1 text-sm font-semibold">{q.prompt}</legend>
      {q.kind === "gap" ? (
        <input
          className="mt-2 w-full rounded-xl border border-line bg-paper px-3 py-3 outline-none focus:border-forest"
          value={value}
          aria-label={q.prompt}
          onChange={(e) => onChange(q.id, e.target.value)}
          placeholder={q.wordLimit ? `Tối đa ${q.wordLimit} từ` : "Đáp án"}
        />
      ) : q.kind === "multi" ? (
        <div className="mt-2 flex flex-col gap-2">
          {options.map((o) => (
            <label key={o.id} className="flex min-h-11 items-center gap-3 rounded-xl border border-line px-3">
              <input type="checkbox" checked={checks.includes(o.id)} onChange={() => onMulti(q.id, o.id)} />
              <span>{o.label}</span>
            </label>
          ))}
        </div>
      ) : (
        <div className="mt-2 flex flex-col gap-2">
          {options.map((o) => {
            const taken = exclusive && used.has(o.id) && value !== o.id;
            return (
              <label key={o.id} className={`flex min-h-11 items-center gap-3 rounded-xl border px-3 ${value === o.id ? "border-forest bg-moss" : "border-line"} ${taken ? "opacity-40" : ""}`}>
                <input type="radio" name={q.id} disabled={taken} checked={value === o.id} onChange={() => onChange(q.id, o.id)} />
                <span>{o.label}</span>
              </label>
            );
          })}
        </div>
      )}
    </fieldset>
  );
}

function WritingPane({
  task,
  essay,
  words,
  onChange,
  onSubmit,
}: {
  task: NonNullable<Live["writing"]>;
  essay: string;
  words: number;
  onChange: (v: string) => void;
  onSubmit: () => void;
}) {
  const short = words < task.minWords;
  return (
    <div className="flex flex-col gap-4">
      <article className="whitespace-pre-wrap rounded-3xl border border-line bg-card p-4 text-sm leading-relaxed">{task.prompt}</article>
      {task.chart ? <TaskChart chart={task.chart} /> : null}
      {task.process ? (
        <ol className="list-decimal space-y-2 rounded-2xl border border-line bg-card p-4 pl-8">
          {task.process.map((step) => (
            <li key={step}>{step}</li>
          ))}
        </ol>
      ) : null}
      {task.changes ? (
        <div className="grid gap-3 sm:grid-cols-2">
          {task.changes.map((col) => (
            <div key={col.when} className="rounded-2xl border border-line bg-card p-3">
              <p className="font-semibold">{col.when}</p>
              <ul className="mt-2 list-disc pl-4 text-sm">
                {col.points.map((p) => (
                  <li key={p}>{p}</li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      ) : null}
      <label className="text-sm font-semibold" htmlFor="essay">
        Bài viết · {words} từ {short ? `· còn thiếu so với ${task.minWords}` : "· đủ sàn"}
      </label>
      <textarea
        id="essay"
        value={essay}
        onChange={(e) => onChange(e.target.value)}
        rows={14}
        className="w-full rounded-2xl border border-line bg-card p-3 outline-none focus:border-forest"
        placeholder="Viết bằng tiếng Anh. Chia đoạn bằng một dòng trống."
      />
      <Button size="lg" onClick={onSubmit}>
        Nộp bài
      </Button>
    </div>
  );
}

function SpeakingPane(props: {
  task: NonNullable<Live["speaking"]>;
  step: number;
  setStep: (n: number) => void;
  transcript: string;
  setTranscript: (v: string) => void;
  pron: number | null;
  setPron: (n: number) => void;
  recording: boolean;
  blobUrl: string;
  audioError: string;
  speakLeft: number | null;
  onRecord: () => void;
  onPrep: () => void;
  onSpeak: () => void;
  onSubmit: () => void;
}) {
  const part = props.task.parts[props.step];
  return (
    <div className="flex flex-col gap-4">
      <div className="flex flex-wrap gap-2">
        {props.task.parts.map((p, i) => (
          <Button key={p.name} variant={i === props.step ? "primary" : "line"} onClick={() => props.setStep(i)}>
            {p.name}
          </Button>
        ))}
      </div>
      <section className="rounded-3xl border border-line bg-card p-4">
        <h2 className="font-serif text-2xl">{part.name}</h2>
        <ul className="mt-3 flex flex-col gap-2">
          {part.lines.map((line) => (
            <li key={line}>{line}</li>
          ))}
        </ul>
        <div className="mt-4 flex flex-wrap gap-2">
          {part.prep ? (
            <Button variant="line" onClick={props.onPrep}>
              Chuẩn bị {part.prep}s
            </Button>
          ) : null}
          {part.speak ? (
            <Button variant="line" onClick={props.onSpeak}>
              Nói {part.speak}s
            </Button>
          ) : null}
          {props.speakLeft != null ? <span className="self-center font-serif text-xl">{clock(props.speakLeft)}</span> : null}
        </div>
      </section>
      <div className="flex flex-wrap gap-2">
        <Button variant={props.recording ? "clay" : "primary"} onClick={props.onRecord}>
          {props.recording ? <Square className="size-4" /> : <Play className="size-4" />}
          {props.recording ? "Dừng thu" : "Thu âm"}
        </Button>
      </div>
      {props.audioError ? <p className="text-sm text-clay">{props.audioError}</p> : null}
      {props.blobUrl ? <audio controls src={props.blobUrl} className="w-full" /> : null}
      <label className="text-sm font-semibold" htmlFor="transcript">
        Transcript (máy chép hoặc bạn dán)
      </label>
      <textarea
        id="transcript"
        value={props.transcript}
        onChange={(e) => props.setTranscript(e.target.value)}
        rows={6}
        className="w-full rounded-2xl border border-line bg-card p-3 outline-none focus:border-forest"
      />
      <div>
        <p className="text-sm font-semibold">Tự đối chiếu phát âm sau khi nghe lại</p>
        <div className="mt-2 flex flex-wrap gap-2">
          {[4, 5, 6, 7, 8, 9].map((n) => (
            <Button key={n} variant={props.pron === n ? "primary" : "line"} onClick={() => props.setPron(n)}>
              {n}
            </Button>
          ))}
        </div>
      </div>
      <Button size="lg" onClick={props.onSubmit}>
        Nộp phần nói
      </Button>
    </div>
  );
}

function DictationPane(props: {
  sentences: string[];
  index: number;
  draft: string;
  marks: Record<number, string>;
  onDraft: (v: string) => void;
  onPlay: () => void;
  onCheck: () => void;
  onSubmit: () => void;
}) {
  const line = props.sentences[props.index];
  const saved = props.marks[props.index];
  return (
    <div className="flex flex-col gap-3">
      <p className="text-sm text-muted">
        Câu {props.index + 1}/{props.sentences.length}. Nghe rồi viết. Dấu câu không bị so.
      </p>
      <Button variant="moss" onClick={props.onPlay}>
        <Play className="size-4" />
        Nghe câu này
      </Button>
      <textarea
        value={props.draft}
        onChange={(e) => props.onDraft(e.target.value)}
        rows={4}
        className="w-full rounded-2xl border border-line bg-card p-3 outline-none focus:border-forest"
        aria-label="Câu bạn chép"
      />
      {saved ? <p className="rounded-2xl bg-moss p-3 text-sm">Đã lưu câu này.</p> : null}
      {line ? <p className="text-sm text-muted">Câu gốc chỉ hiện sau khi nộp cả bài.</p> : null}
      <div className="flex flex-wrap gap-2">
        <Button variant="line" onClick={props.onCheck} disabled={!line}>
          Lưu và câu sau
        </Button>
        <Button onClick={props.onSubmit}>Nộp bài chép</Button>
      </div>
    </div>
  );
}

function VocabPane({
  themeIndex,
  known,
  toggle,
  onDone,
}: {
  themeIndex: number;
  known: Record<string, boolean>;
  toggle: (id: string) => void;
  onDone: () => void;
}) {
  const theme = THEMES[themeIndex];
  const [open, setOpen] = useState<string | null>(null);
  return (
    <div className="flex flex-col gap-3">
      <h2 className="font-serif text-3xl">{theme.title}</h2>
      <p className="text-sm text-muted">{theme.stage}. Bấm để thấy nghĩa và câu. Đánh dấu cụm đã dùng được.</p>
      {theme.items.map((item) => {
        const id = `${theme.id}:${item.en}`;
        return (
          <article key={id} className="rounded-2xl border border-line bg-card p-3">
            <button className="w-full text-left font-semibold" onClick={() => setOpen(open === id ? null : id)}>
              {item.en}
            </button>
            {open === id ? (
              <p className="mt-2 text-sm">
                {item.vi}. {item.ex}
              </p>
            ) : null}
            <Button className="mt-2" variant={known[id] ? "moss" : "line"} onClick={() => toggle(id)}>
              {known[id] ? "Đã thuộc" : "Chưa thuộc"}
            </Button>
          </article>
        );
      })}
      <Button onClick={onDone}>Xong phần từ</Button>
    </div>
  );
}

declare global {
  interface Window {
    SpeechRecognition?: SpeechRecognitionConstructor;
    webkitSpeechRecognition?: SpeechRecognitionConstructor;
  }
}

type SpeechRecognitionConstructor = new () => {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  onresult: (event: { results: ArrayLike<ArrayLike<{ transcript: string }>> }) => void;
  onerror: () => void;
  start: () => void;
  stop: () => void;
};
