export type Module = "academic" | "general";

export type Skill = "listening" | "reading" | "writing" | "speaking";

export type ObjectiveType =
  | "form"
  | "note"
  | "table"
  | "flow"
  | "summary"
  | "sentence"
  | "short"
  | "mcq"
  | "mcq-multi"
  | "matching"
  | "map"
  | "diagram"
  | "tfng"
  | "ynng"
  | "headings"
  | "info-match"
  | "features"
  | "endings"
  | "summary-bank";

export type WritingType =
  | "line"
  | "bar"
  | "pie"
  | "table-chart"
  | "mixed"
  | "process"
  | "map-change"
  | "letter-formal"
  | "letter-semi"
  | "letter-informal"
  | "opinion"
  | "discussion"
  | "adv"
  | "problem"
  | "twopart";

export type SpeakingType = "part1" | "part2" | "part3" | "speaking-full";

export type TaskType = ObjectiveType | WritingType | SpeakingType | "dictation" | "vocab";

export type Option = { id: string; label: string };

export type Question = {
  id: string;
  prompt: string;
  kind: "gap" | "radio" | "multi";
  options?: Option[];
  accept: string[];
  wordLimit?: number;
  explain: string;
};

export type Paper = {
  id: string;
  module: Module | "both";
  skill: "listening" | "reading";
  types: ObjectiveType[];
  title: string;
  section: string;
  instruction: string;
  minutes: number;
  script?: string;
  passage?: string;
  figure?: "centre" | "filter" | "pier";
  shared?: { exclusive: boolean; note: string; options: Option[] };
  questions: Question[];
};

export type Series = { name: string; points: { x: string; y: number }[] };

export type ChartModel =
  | { kind: "bar" | "line"; title: string; unit: string; series: Series[] }
  | { kind: "pie"; title: string; unit: string; slices: { name: string; y: number }[] }
  | { kind: "table"; title: string; unit: string; headers: string[]; rows: string[][] }
  | { kind: "mixed"; title: string; barUnit: string; lineUnit: string; bars: Series; line: Series };

export type WritingTask = {
  id: string;
  module: Module;
  type: WritingType;
  title: string;
  prompt: string;
  minWords: number;
  minutes: number;
  keywords: string[];
  bullets?: { text: string; keys: string[] }[];
  chart?: ChartModel;
  process?: string[];
  changes?: { when: string; points: string[] }[];
  ideas: string[];
};

export type SpeakingTask = {
  id: string;
  type: SpeakingType;
  title: string;
  minutes: number;
  parts: { name: string; minutes: number; prep?: number; speak?: number; lines: string[] }[];
  keywords: string[];
};

export type CriterionScore = {
  key: string;
  label: string;
  band: number;
  note: string;
};

export type ItemReview = {
  id: string;
  prompt: string;
  yours: string;
  answer: string;
  ok: boolean;
  explain: string;
};

export type GradePayload = {
  band: number | null;
  bandLabel: string;
  caution: string;
  correct?: number;
  total?: number;
  raw40?: number;
  criteria?: CriterionScore[];
  notes: string[];
  items?: ItemReview[];
  outline?: string[];
};
