export type VocabItem = { en: string; vi: string; ex: string };

export type VocabTheme = { id: string; title: string; stage: string; items: VocabItem[] };

export const THEMES: VocabTheme[] = [
  {
    id: "study",
    title: "Học tập",
    stage: "Nền",
    items: [
      { en: "hand in an assignment", vi: "nộp bài tập", ex: "Students must hand in the assignment by Friday." },
      { en: "fall behind", vi: "bị tụt lại", ex: "She fell behind after missing a week." },
      { en: "meet a deadline", vi: "kịp hạn", ex: "Working in a group helps some people meet a deadline." },
      { en: "take notes", vi: "ghi chép", ex: "I take notes while the lecturer is speaking." },
      { en: "revise for an exam", vi: "ôn thi", ex: "He revises for exams in the library." },
      { en: "a heavy workload", vi: "khối lượng việc nặng", ex: "The course has a heavy workload in the first term." },
    ],
  },
  {
    id: "health",
    title: "Sức khoẻ",
    stage: "Nền",
    items: [
      { en: "a balanced diet", vi: "chế độ ăn cân bằng", ex: "A balanced diet matters more than a short-term cleanse." },
      { en: "suffer from stress", vi: "chịu đựng căng thẳng", ex: "Night staff often suffer from stress." },
      { en: "cut down on sugar", vi: "cắt giảm đường", ex: "The clinic advised him to cut down on sugar." },
      { en: "preventive care", vi: "chăm sóc phòng ngừa", ex: "Preventive care is cheaper than emergency treatment." },
      { en: "a sedentary job", vi: "công việc ít vận động", ex: "A sedentary job can weaken the back." },
      { en: "life expectancy", vi: "tuổi thọ", ex: "Life expectancy rose as clean water spread." },
    ],
  },
  {
    id: "city",
    title: "Đô thị",
    stage: "Trung cấp",
    items: [
      { en: "public transport", vi: "giao thông công cộng", ex: "Reliable public transport reduces road congestion." },
      { en: "residential area", vi: "khu dân cư", ex: "The warehouse was turned into a residential area." },
      { en: "traffic congestion", vi: "ùn tắc", ex: "Traffic congestion peaks at 7 a.m." },
      { en: "urban sprawl", vi: "đô thị lan rộng", ex: "Urban sprawl swallowed the rice fields." },
      { en: "pedestrian zone", vi: "phố đi bộ", ex: "The market became a pedestrian zone on Sundays." },
      { en: "affordable housing", vi: "nhà ở vừa túi tiền", ex: "The city lacks affordable housing near stations." },
    ],
  },
  {
    id: "env",
    title: "Môi trường",
    stage: "Trung cấp",
    items: [
      { en: "carbon emissions", vi: "khí thải carbon", ex: "The factory cut carbon emissions by switching fuel." },
      { en: "single-use plastic", vi: "nhựa dùng một lần", ex: "The cafe stopped providing single-use plastic." },
      { en: "renewable energy", vi: "năng lượng tái tạo", ex: "Renewable energy now powers the campus at noon." },
      { en: "habitat loss", vi: "mất môi trường sống", ex: "Habitat loss, not hunting, explains the decline." },
      { en: "waste disposal", vi: "xử lý rác", ex: "Waste disposal is a municipal duty." },
      { en: "a tipping point", vi: "ngưỡng không đảo ngược", ex: "Scientists fear a tipping point in the delta." },
    ],
  },
  {
    id: "work",
    title: "Công việc",
    stage: "Trung cấp",
    items: [
      { en: "job satisfaction", vi: "sự hài lòng với công việc", ex: "Pay alone does not guarantee job satisfaction." },
      { en: "a heavy workload", vi: "khối lượng việc lớn", ex: "Staff left because of the heavy workload." },
      { en: "career prospects", vi: "triển vọng nghề nghiệp", ex: "The role offers limited career prospects." },
      { en: "work-life balance", vi: "cân bằng công việc và đời sống", ex: "Parents often rank work-life balance above salary." },
      { en: "manual labour", vi: "lao động chân tay", ex: "Manual labour is still poorly paid in the region." },
      { en: "a permanent contract", vi: "hợp đồng dài hạn", ex: "She was offered a permanent contract after six months." },
    ],
  },
  {
    id: "tech",
    title: "Công nghệ",
    stage: "Nâng cao",
    items: [
      { en: "artificial intelligence", vi: "trí tuệ nhân tạo", ex: "Artificial intelligence marked the test papers overnight." },
      { en: "data privacy", vi: "quyền riêng tư dữ liệu", ex: "Data privacy matters when schools store recordings." },
      { en: "automate a process", vi: "tự động hoá một quy trình", ex: "The plant automated the bottling process." },
      { en: "a digital divide", vi: "khoảng cách số", ex: "The digital divide leaves rural pupils without practice." },
      { en: "face-to-face contact", vi: "tiếp xúc trực tiếp", ex: "Some skills still require face-to-face contact." },
      { en: "intellectual property", vi: "sở hữu trí tuệ", ex: "The photos are protected as intellectual property." },
    ],
  },
  {
    id: "media",
    title: "Truyền thông",
    stage: "Nâng cao",
    items: [
      { en: "target advertising", vi: "quảng cáo nhắm đối tượng", ex: "Target advertising follows children onto video sites." },
      { en: "a reliable source", vi: "nguồn đáng tin", ex: "A reliable source states the date and the method." },
      { en: "go viral", vi: "lan rất nhanh", ex: "The clip went viral before the school could reply." },
      { en: "bias in reporting", vi: "thiên lệch khi đưa tin", ex: "Bias in reporting is not the same as a factual error." },
      { en: "freedom of the press", vi: "tự do báo chí", ex: "Freedom of the press does not protect invented quotes." },
      { en: "consumer culture", vi: "văn hoá tiêu dùng", ex: "Consumer culture treats a holiday as a product." },
    ],
  },
  {
    id: "society",
    title: "Xã hội",
    stage: "Nâng cao",
    items: [
      { en: "an ageing population", vi: "dân số già hoá", ex: "An ageing population raises the cost of care." },
      { en: "social cohesion", vi: "gắn kết xã hội", ex: "Shared parks can support social cohesion." },
      { en: "income inequality", vi: "bất bình đẳng thu nhập", ex: "Income inequality widened after the factory closed." },
      { en: "cultural heritage", vi: "di sản văn hoá", ex: "The festival is part of the town's cultural heritage." },
      { en: "a petty crime", vi: "tội nhỏ", ex: "Bicycle theft is a petty crime that still scares commuters." },
      { en: "community service", vi: "phục vụ cộng đồng", ex: "The court ordered forty hours of community service." },
    ],
  },
];
