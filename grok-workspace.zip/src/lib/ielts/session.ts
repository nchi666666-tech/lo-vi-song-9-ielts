import { generateSpeaking, generateWriting } from "./generate";
import { PAPERS } from "./papers";
import type { Spec } from "./plan";
import type { Mistake } from "./store";
import type { Module, Paper, Skill } from "./types";
import { THEMES } from "./vocab";

export type Live = {
  key: string;
  spec: Spec;
  module: Module;
  title: string;
  minutes: number;
  paper?: Paper;
  writing?: ReturnType<typeof generateWriting>;
  speaking?: ReturnType<typeof generateSpeaking>;
  theme?: number;
  review?: Mistake[];
  note?: string;
};

export function buildLive(spec: Spec, seed: number, module: Module, mistakes: Mistake[]): Live {
  const key = `${spec.kind}:${spec.type}:${seed}:${module}`;
  if (spec.kind === "vocab") {
    return { key, spec, module, title: THEMES[seed % THEMES.length].title, minutes: 12, theme: seed % THEMES.length };
  }
  if (spec.kind === "review") {
    const open = mistakes.filter((m) => !m.resolved);
    return {
      key,
      spec,
      module,
      title: open.length ? "Ôn câu đã sai" : "Sổ lỗi đang trống",
      minutes: 15,
      review: open.slice(0, 8),
      note: open.length ? "" : "Hãy làm một bài Listening hoặc Reading trước. Câu sai sẽ vào sổ.",
    };
  }
  if (spec.kind === "writing") {
    const writing = generateWriting(spec.type as Parameters<typeof generateWriting>[0], module, seed);
    return { key, spec, module, title: writing.title, minutes: writing.minutes, writing };
  }
  if (spec.kind === "speaking") {
    const speaking = generateSpeaking(spec.type as Parameters<typeof generateSpeaking>[0], seed);
    return { key, spec, module, title: speaking.title, minutes: speaking.minutes, speaking };
  }
  if (spec.kind === "dictation") {
    const pool = PAPERS.filter((p) => p.script);
    const paper = pool[seed % pool.length];
    return { key, spec, module, title: `Chép chính tả · ${paper.title}`, minutes: 12, paper };
  }
  const pool = PAPERS.filter((p) => p.types.includes(spec.type as Paper["types"][number]));
  const preferred = pool.filter((p) => p.module === "both" || p.module === module);
  const list = preferred.length ? preferred : pool;
  if (!list.length) {
    return {
      key,
      spec,
      module,
      title: "Chưa có đề dạng này",
      minutes: 1,
      note: "Dạng này chưa có bài gốc. Hãy chọn dạng khác, hoặc đổi Academic / General.",
    };
  }
  const paper = list[seed % list.length];
  const switched = paper.module !== "both" && paper.module !== module;
  return {
    key,
    spec,
    module,
    title: paper.title,
    minutes: paper.minutes,
    paper,
    note: switched ? "Dạng này chủ yếu thuộc module kia. Bài vẫn mở để bạn luyện, và được ghi rõ là đề Academic hoặc General." : undefined,
  };
}

export function skillOf(spec: Spec): Skill {
  return spec.skill;
}
