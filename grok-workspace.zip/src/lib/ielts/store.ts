import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { CriterionScore, ItemReview, Module, Skill } from "./types";

export type Profile = {
  nickname: string;
  module: Module;
  target: number;
  examDate: string;
  minutes: number;
  horizon: 30 | 90;
  current: Record<Skill, number>;
  accent: "en-GB" | "en-US" | "en-AU";
  planStart: string;
};

export type Attempt = {
  id: string;
  at: number;
  skill: Skill;
  module: Module;
  type: string;
  title: string;
  band: number | null;
  bandLabel: string;
  correct?: number;
  total?: number;
  notes: string[];
  items?: ItemReview[];
  criteria?: CriterionScore[];
};

export type Mistake = {
  id: string;
  at: number;
  skill: Skill;
  type: string;
  prompt: string;
  yours: string;
  answer: string;
  why: string;
  resolved: boolean;
};

type Tab = "home" | "practice" | "plan" | "notebook";

type State = {
  profile: Profile;
  tab: Tab;
  attempts: Attempt[];
  mistakes: Mistake[];
  ticks: Record<string, boolean>;
  knownVocab: Record<string, boolean>;
  seed: number;
  setTab: (tab: Tab) => void;
  patchProfile: (patch: Partial<Profile>) => void;
  setCurrent: (skill: Skill, band: number) => void;
  ensure: () => void;
  bumpSeed: () => number;
  toggleTick: (key: string) => void;
  markTick: (key: string) => void;
  toggleVocab: (id: string) => void;
  resolveMistake: (id: string) => void;
  record: (attempt: Attempt, wrongs: Mistake[]) => void;
  restartPlan: () => void;
};

const emptyCurrent = { listening: 5.5, reading: 5.5, writing: 5.5, speaking: 5.5 };

export const useStudio = create<State>()(
  persist(
    (set, get) => ({
      profile: {
        nickname: "",
        module: "academic",
        target: 7,
        examDate: "",
        minutes: 90,
        horizon: 90,
        current: emptyCurrent,
        accent: "en-GB",
        planStart: "",
      },
      tab: "home",
      attempts: [],
      mistakes: [],
      ticks: {},
      knownVocab: {},
      seed: 1,
      setTab: (tab) => set({ tab }),
      patchProfile: (patch) => set((s) => ({ profile: { ...s.profile, ...patch } })),
      setCurrent: (skill, band) =>
        set((s) => ({ profile: { ...s.profile, current: { ...s.profile.current, [skill]: band } } })),
      ensure: () => {
        if (get().profile.planStart) return;
        const planStart = new Date().toISOString().slice(0, 10);
        set((s) => ({ profile: { ...s.profile, planStart } }));
      },
      bumpSeed: () => {
        const seed = get().seed + 1;
        set({ seed });
        return seed;
      },
      toggleTick: (key) => set((s) => ({ ticks: { ...s.ticks, [key]: !s.ticks[key] } })),
      markTick: (key) => set((s) => ({ ticks: { ...s.ticks, [key]: true } })),
      toggleVocab: (id) => set((s) => ({ knownVocab: { ...s.knownVocab, [id]: !s.knownVocab[id] } })),
      resolveMistake: (id) =>
        set((s) => ({ mistakes: s.mistakes.map((m) => (m.id === id ? { ...m, resolved: true } : m)) })),
      record: (attempt, wrongs) =>
        set((s) => ({
          attempts: [attempt, ...s.attempts].slice(0, 40),
          mistakes: [...wrongs, ...s.mistakes.filter((m) => !wrongs.some((w) => w.id === m.id))].slice(0, 200),
        })),
      restartPlan: () =>
        set((s) => ({
          ticks: {},
          profile: { ...s.profile, planStart: new Date().toISOString().slice(0, 10) },
        })),
    }),
    {
      name: "lo-vi-song-v1",
      partialize: (s) => ({
        profile: s.profile,
        attempts: s.attempts,
        mistakes: s.mistakes,
        ticks: s.ticks,
        knownVocab: s.knownVocab,
        seed: s.seed,
      }),
    },
  ),
);
