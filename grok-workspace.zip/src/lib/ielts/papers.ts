import type { Paper } from "./types";

const yn = [
  { id: "Y", label: "Yes" },
  { id: "N", label: "No" },
  { id: "NG", label: "Not Given" },
];
const tf = [
  { id: "T", label: "True" },
  { id: "F", label: "False" },
  { id: "NG", label: "Not Given" },
];

export const PAPERS: Paper[] = [
  {
    id: "l-homestay",
    module: "both",
    skill: "listening",
    types: ["form"],
    title: "Đặt phòng homestay Riverside",
    section: "Listening · Section 1 · Hội thoại hằng ngày",
    minutes: 8,
    instruction: "Điền mỗi chỗ trống bằng KHÔNG QUÁ HAI TỪ VÀ/HOẶC MỘT SỐ. Viết đúng chính tả như trên form.",
    script:
      "Officer: Good morning, Riverside Homestay, Maya speaking. Student: Hello, I would like to book a room. My surname is Harrington. That is H-A-R-R-I-N-G-T-O-N. Officer: Thank you. What is your nationality? Student: I am Canadian. Officer: How long will you stay? Student: Six months, and I will start on the third of March. Officer: We have a single room or a shared room. Student: A single room, please. Officer: Any notes for the kitchen? Student: Yes. I am allergic to nuts, so please write nut allergy on the form. Officer: Certainly. A contact number? Student: It is 0416 883 290. Officer: The single room is 180 dollars a week, bills included. Student: That is fine.",
    questions: [
      { id: "q1", prompt: "1. Surname", kind: "gap", accept: ["Harrington"], wordLimit: 1, explain: "Maya không nhắc lại cả tên. Họ được đánh vần: Harrington." },
      { id: "q2", prompt: "2. Nationality", kind: "gap", accept: ["Canadian", "Canada"], wordLimit: 1, explain: "Câu nghe được là I am Canadian." },
      { id: "q3", prompt: "3. Length of stay", kind: "gap", accept: ["six months", "6 months"], wordLimit: 2, explain: "Six months. Viết 6 months cũng được chấp nhận ở bài luyện này." },
      { id: "q4", prompt: "4. Start date", kind: "gap", accept: ["3 March", "March 3", "3rd March"], wordLimit: 2, explain: "the third of March. Giới hạn hai từ nên viết 3 March, không viết the third of March." },
      { id: "q5", prompt: "5. Room type", kind: "gap", accept: ["single", "single room"], wordLimit: 2, explain: "Người nghe chọn single, không phải shared." },
      { id: "q6", prompt: "6. Kitchen note", kind: "gap", accept: ["nut allergy", "nuts"], wordLimit: 2, explain: "Nhân viên đọc lại thành nut allergy. Allergic to nuts là ba từ, sẽ bị tính sai vì thừa giới hạn." },
      { id: "q7", prompt: "7. Phone", kind: "gap", accept: ["0416883290", "0416 883 290"], wordLimit: 3, explain: "0416 883 290. Chính tả số phải đủ." },
      { id: "q8", prompt: "8. Weekly rent ($)", kind: "gap", accept: ["180", "180 dollars"], wordLimit: 2, explain: "180 dollars a week. Ô đã có đơn vị tiền nên 180 là đủ." },
    ],
  },
  {
    id: "l-centre",
    module: "both",
    skill: "listening",
    types: ["map"],
    title: "Sơ đồ Northgate Community Centre",
    section: "Listening · Section 2 · Một người nói",
    minutes: 8,
    figure: "centre",
    shared: {
      exclusive: true,
      note: "Chữ trên sơ đồ",
      options: "ABCDEFGH".split("").map((id) => ({ id, label: id })),
    },
    instruction: "Nhìn sơ đồ. Mỗi câu chọn MỘT chữ cái A–H. Mỗi chữ chỉ dùng một lần. Bạn đang đứng ở lối vào, phía dưới sơ đồ.",
    script:
      "Welcome to the Northgate Community Centre. Please look at the plan. The entrance is at the bottom centre. To the left of the entrance are the bike racks, letter H. To the right of the entrance are the toilets, letter F. Directly above the entrance is the main hall, letter C, where we hold concerts. Reception is above the bike racks, letter A. The dance studio is above the toilets, letter D. The cafe is in the top-left corner, letter B, with windows onto the street. The quiet garden is the top-middle space, letter E. The staff office is the top-right room, letter G. Please do not leave bags in the hall.",
    questions: [
      { id: "q1", prompt: "Cafe", kind: "radio", accept: ["B"], explain: "Top-left corner, letter B." },
      { id: "q2", prompt: "Dance studio", kind: "radio", accept: ["D"], explain: "Above the toilets, letter D." },
      { id: "q3", prompt: "Quiet garden", kind: "radio", accept: ["E"], explain: "Top-middle, letter E. Đừng chọn hall chỉ vì nghe chữ concerts." },
      { id: "q4", prompt: "Toilets", kind: "radio", accept: ["F"], explain: "Right of the entrance, letter F." },
      { id: "q5", prompt: "Staff office", kind: "radio", accept: ["G"], explain: "Top-right, letter G." },
      { id: "q6", prompt: "Bike racks", kind: "radio", accept: ["H"], explain: "Left of the entrance, letter H. Opposite không phải left." },
    ],
  },
  {
    id: "l-survey",
    module: "both",
    skill: "listening",
    types: ["mcq", "matching", "short", "mcq-multi"],
    title: "Thảo luận khảo sát rác sông",
    section: "Listening · Section 3 · Nhóm học thuật",
    minutes: 10,
    instruction: "Chọn đúng chữ cái, hoặc điền không quá hai từ. Hai câu chọn nhiều đáp án: cần đủ chữ cái.",
    script:
      "Tutor: Linh, Marco, where is the survey now? Linh: We changed the topic. It is not river wildlife. It is plastic in the river through the campus. Tutor: How will you collect evidence? Marco: Not online forms, and not a laboratory. We will do short interviews and take photos of the banks. Tutor: What is blocking you? Linh: The questions are clear, and we have a camera. We just have too few responses, only twelve. Tutor: Then split the jobs. Linh designs the questionnaire. Marco contacts the council about permission. I will not write the results. Marco writes the results section, and Linh makes the charts. Both of you check the final draft. Also choose two risks to mention: rain on the interview day, and people refusing to be photographed. Do not include laboratory cost. We have no lab.",
    questions: [
      {
        id: "q1",
        prompt: "1. Chủ đề khảo sát bây giờ là gì?",
        kind: "radio",
        options: [
          { id: "A", label: "Động vật hoang dã ven sông" },
          { id: "B", label: "Rác nhựa trên sông" },
          { id: "C", label: "Tiếng ồn nhà máy" },
        ],
        accept: ["B"],
        explain: "Linh sửa lại: not river wildlife, it is plastic.",
      },
      {
        id: "q2",
        prompt: "2. Họ thu thập dữ liệu bằng cách nào?",
        kind: "radio",
        options: [
          { id: "A", label: "Chỉ biểu mẫu online" },
          { id: "B", label: "Phỏng vấn ngắn và chụp ảnh" },
          { id: "C", label: "Thí nghiệm trong lab" },
        ],
        accept: ["B"],
        explain: "Marco loại online và laboratory, giữ interviews and photos.",
      },
      {
        id: "q3",
        prompt: "3. Trở ngại chính hiện tại?",
        kind: "radio",
        options: [
          { id: "A", label: "Quá ít phản hồi" },
          { id: "B", label: "Câu hỏi chưa rõ" },
          { id: "C", label: "Không có máy ảnh" },
        ],
        accept: ["A"],
        explain: "Questions are clear, they have a camera, only twelve responses.",
      },
      {
        id: "q4",
        prompt: "4. Ai thiết kế bảng câu hỏi?",
        kind: "radio",
        options: [
          { id: "A", label: "Linh" },
          { id: "B", label: "Marco" },
          { id: "C", label: "Giảng viên" },
        ],
        accept: ["A"],
        explain: "Linh designs the questionnaire.",
      },
      {
        id: "q5",
        prompt: "5. Ai liên hệ hội đồng?",
        kind: "radio",
        options: [
          { id: "A", label: "Linh" },
          { id: "B", label: "Marco" },
          { id: "C", label: "Giảng viên" },
        ],
        accept: ["B"],
        explain: "Marco contacts the council.",
      },
      {
        id: "q6",
        prompt: "6. Ai viết phần kết quả?",
        kind: "radio",
        options: [
          { id: "A", label: "Linh" },
          { id: "B", label: "Marco" },
          { id: "C", label: "Cả hai" },
        ],
        accept: ["B"],
        explain: "Marco writes the results. Linh chỉ làm charts. Both chỉ check bản cuối.",
      },
      {
        id: "q7",
        prompt: "7–8. Chọn HAI rủi ro cần nêu. Điền hai chữ cái, ví dụ A C.",
        kind: "multi",
        options: [
          { id: "A", label: "Trời mưa đúng ngày phỏng vấn" },
          { id: "B", label: "Chi phí phòng lab" },
          { id: "C", label: "Người dân từ chối bị chụp ảnh" },
          { id: "D", label: "Mất cả bản thảo" },
        ],
        accept: ["A C", "C A"],
        explain: "Tutor nêu rain và refusing to be photographed, và nói đừng đưa laboratory cost.",
      },
      {
        id: "q8",
        prompt: "9. Họ mới có bao nhiêu phản hồi? (một số)",
        kind: "gap",
        accept: ["12", "twelve"],
        wordLimit: 1,
        explain: "only twelve.",
      },
    ],
  },
  {
    id: "l-mangrove",
    module: "both",
    skill: "listening",
    types: ["note", "sentence", "summary"],
    title: "Bài giảng: rừng ngập mặn",
    section: "Listening · Section 4 · Bài giảng",
    minutes: 10,
    instruction: "Mỗi chỗ trống MỘT TỪ, lấy từ bài nghe. Không đổi từ đồng nghĩa.",
    script:
      "Today we look at mangroves. These trees tolerate salty water along tropical coasts. Their dense roots trap sediment, which slowly raises the shore. A single hectare can store up to one thousand tonnes of carbon in soil and wood. Locally, the greatest threat is shrimp farming, not tourism. Restoration succeeds when the village owns the project, rather than receiving a one-day planting event. Seedlings stay in a nursery for six months before they are moved to the mud. In short, mangroves protect coasts only if the community keeps control after the volunteers leave.",
    questions: [
      { id: "q1", prompt: "Note: water that mangroves tolerate — ______ water", kind: "gap", accept: ["salty"], wordLimit: 1, explain: "salty water. Tropical mô tả bờ biển, không phải loại nước." },
      { id: "q2", prompt: "Note: roots trap ______", kind: "gap", accept: ["sediment"], wordLimit: 1, explain: "trap sediment." },
      { id: "q3", prompt: "Note: up to ______ tonnes of carbon per hectare", kind: "gap", accept: ["1000", "1,000", "one thousand"], wordLimit: 2, explain: "one thousand tonnes." },
      { id: "q4", prompt: "Sentence: The greatest local threat is ______ farming.", kind: "gap", accept: ["shrimp"], wordLimit: 1, explain: "shrimp farming, và bài nói not tourism." },
      { id: "q5", prompt: "Sentence: The village must own the ______.", kind: "gap", accept: ["project"], wordLimit: 1, explain: "owns the project." },
      { id: "q6", prompt: "Summary: Seedlings spend six months in a ______.", kind: "gap", accept: ["nursery"], wordLimit: 1, explain: "in a nursery." },
    ],
  },
  {
    id: "l-bikes",
    module: "both",
    skill: "listening",
    types: ["table"],
    title: "Bảng thuê xe đạp thành phố",
    section: "Listening · Section 1 · Thông tin dịch vụ",
    minutes: 8,
    instruction: "Điền bảng. Mỗi ô KHÔNG QUÁ HAI TỪ VÀ/HOẶC MỘT SỐ.",
    script:
      "There are three zones in the city bike scheme. In the Central zone, bikes can be taken from 5:30 in the morning until midnight, and the deposit is 20 dollars. The Riverside zone opens from 6 in the morning until 9 in the evening. Its deposit is 35 dollars. The Hill zone is open at weekends only, and there is no deposit, because the bikes there are older.",
    questions: [
      { id: "q1", prompt: "Central · Giờ mở cửa", kind: "gap", accept: ["5:30 to midnight", "5.30 to midnight", "5:30-midnight", "530 to midnight"], wordLimit: 4, explain: "from 5:30 in the morning until midnight. Bài luyện chấp nhận 5:30 to midnight." },
      { id: "q2", prompt: "Central · Tiền đặt cọc ($)", kind: "gap", accept: ["20"], wordLimit: 1, explain: "20 dollars." },
      { id: "q3", prompt: "Riverside · Tiền đặt cọc ($)", kind: "gap", accept: ["35"], wordLimit: 1, explain: "35 dollars. Đừng lấy nhầm 20 của Central." },
      { id: "q4", prompt: "Hill · Khi nào mở", kind: "gap", accept: ["weekends", "weekends only"], wordLimit: 2, explain: "at weekends only." },
      { id: "q5", prompt: "Hill · Tiền đặt cọc", kind: "gap", accept: ["none", "no deposit", "free", "0"], wordLimit: 2, explain: "there is no deposit." },
    ],
  },
  {
    id: "l-filter",
    module: "both",
    skill: "listening",
    types: ["diagram", "flow"],
    title: "Sơ đồ bể lọc nước",
    section: "Listening · Section 4 · Mô tả quy trình",
    minutes: 7,
    figure: "filter",
    instruction: "Điền MỘT TỪ cho mỗi bể, theo đúng thứ tự nước chảy từ trên xuống.",
    script:
      "Dirty water enters the top tank, A, which is packed with cloth. It then drops into tank B, a bed of gravel. Below that, tank C holds sand. The lowest tank, D, contains charcoal, and cleaner water leaves through the pipe under D. If you reverse the gravel and the sand, the filter blocks within a day.",
    questions: [
      { id: "q1", prompt: "Bể A (trên cùng)", kind: "gap", accept: ["cloth"], wordLimit: 1, explain: "packed with cloth." },
      { id: "q2", prompt: "Bể B", kind: "gap", accept: ["gravel"], wordLimit: 1, explain: "a bed of gravel." },
      { id: "q3", prompt: "Bể C", kind: "gap", accept: ["sand"], wordLimit: 1, explain: "holds sand. Đảo gravel và sand sẽ sai vì bài cảnh báo điều đó." },
      { id: "q4", prompt: "Bể D (dưới cùng)", kind: "gap", accept: ["charcoal"], wordLimit: 1, explain: "contains charcoal." },
    ],
  },
  {
    id: "r-shade",
    module: "academic",
    skill: "reading",
    types: ["tfng", "sentence", "short"],
    title: "Bóng mát mượn ở điểm chờ xe",
    section: "Reading Academic · một passage luyện",
    minutes: 15,
    instruction: "TRUE nếu bài nói cùng ý. FALSE nếu bài nói ngược. NOT GIVEN nếu bài không đủ thông tin. Câu điền: không quá hai từ lấy từ bài.",
    passage: `Cities measure heat at street level, not only in the air above a roof. A team in Da Nang and another in Lyon spent two summers recording the temperature of bus-stop seats at 2 p.m. Seats under a continuous tree canopy were, on average, 7 degrees Celsius cooler than seats in full sun. Seats under a metal roof were only 2 degrees cooler, and the metal itself was often too hot to touch. The researchers did not claim that trees reduce the temperature of a whole city by 7 degrees. The figure applied only to the shaded seat.

A second finding surprised the planners. The cooling depended on leaves, not on the colour of the pavement. When the same stops were photographed in January, after the plane trees had dropped their leaves, the advantage almost disappeared, even though the pavement had not been repainted. Evergreen species kept a smaller, steadier shade of about 3 degrees through the winter months in Lyon. Da Nang has no such winter, so the species that mattered there were those that kept a dense crown in the dry months of April and May.

The project also watched how people waited. In extreme heat, passengers at unshaded stops were more likely to stand in the road to catch the first bus. The authors call this a safety problem rather than a comfort problem. They do not state that trees reduce the number of road accidents. They only note that risky waiting was more common above 36 degrees at unshaded stops.

Funding came from the municipal transport budget, not from a health ministry. The report recommends planting shade at the fifty hottest stops before replacing metal roofs across the city. It gives no cost for that programme.`,
    questions: [
      { id: "q1", prompt: "1. Con số 7 độ nói về cả thành phố.", kind: "radio", options: tf, accept: ["F"], explain: "The figure applied only to the shaded seat. Đây là FALSE, không phải NOT GIVEN, vì bài phủ định rõ." },
      { id: "q2", prompt: "2. Mái kim loại làm ghế mát hơn cây.", kind: "radio", options: tf, accept: ["F"], explain: "Cây 7 độ, mái kim loại chỉ 2 độ." },
      { id: "q3", prompt: "3. Độ mát phụ thuộc vào màu vỉa hè.", kind: "radio", options: tf, accept: ["F"], explain: "depended on leaves, not on the colour of the pavement." },
      { id: "q4", prompt: "4. Cây plane ở Lyon vẫn giữ lá vào tháng Một.", kind: "radio", options: tf, accept: ["F"], explain: "had dropped their leaves." },
      { id: "q5", prompt: "5. Cây thường xanh ở Lyon cho khoảng 3 độ mát vào mùa đông.", kind: "radio", options: tf, accept: ["T"], explain: "about 3 degrees through the winter months in Lyon." },
      { id: "q6", prompt: "6. Nhóm tác giả chứng minh cây làm giảm tai nạn giao thông.", kind: "radio", options: tf, accept: ["F"], explain: "They do not state that trees reduce the number of road accidents." },
      { id: "q7", prompt: "7. Nghiên cứu được Bộ Y tế tài trợ.", kind: "radio", options: tf, accept: ["F"], explain: "municipal transport budget, not from a health ministry." },
      { id: "q8", prompt: "8. Báo cáo nêu chi phí trồng cây tại 50 điểm nóng nhất.", kind: "radio", options: tf, accept: ["NG"], explain: "It gives no cost. Không có con số chi phí để kết luận đắt hay rẻ, nên NOT GIVEN chứ không phải FALSE về một mức giá cụ thể nào." },
      { id: "q9", prompt: "9. Mái kim loại chỉ hạ nhiệt ghế khoảng ______ độ.", kind: "gap", accept: ["2", "two"], wordLimit: 1, explain: "only 2 degrees cooler." },
      { id: "q10", prompt: "10. Chờ xe rủi ro phổ biến hơn khi nhiệt độ vượt ______ độ.", kind: "gap", accept: ["36"], wordLimit: 1, explain: "above 36 degrees." },
    ],
  },
  {
    id: "r-seeds",
    module: "academic",
    skill: "reading",
    types: ["headings", "info-match"],
    title: "Muối, hạt và một thư viện",
    section: "Reading Academic · tiêu đề đoạn",
    minutes: 16,
    instruction: "Mỗi tiêu đề chỉ dùng một lần. Có tiêu đề thừa. Câu nối thông tin: chọn đoạn chứa đúng chi tiết, không phải đoạn cùng chủ đề chung.",
    passage: `A
A seed bank is a working store, not a display of pretty jars. Its job is to keep copies of crop varieties so that a farm can start again after a flood, a disease, or a war. Staff dry the seed, seal it, and record the farm it came from. Visitors are rare, and almost nothing is labelled for the public.

B
One well-known store sits inside a mountain. The rooms are held at minus 18 degrees. A local coal mine would have been warmer and cheaper, but the planners rejected it because the rock there moves. The mountain site was chosen for stillness, not for scenery.

C
Along one branch of the Mekong, collectors spent four harvests gathering rice from family plots. They labelled each sack with the village name and the month of cutting. They were not trying to find the highest-yielding plant. They wanted the varieties that families already trusted in salty water.

D
Cold on its own does not prove that a seed is alive. Every fifth year, staff take a small sample, warm it, and count how many grains germinate. If the rate falls below an agreed line, a new sample is grown and dried again. The test is dull, and it is the part that keeps the collection honest.

E
Critics say a frozen room gives governments an excuse to ignore living farms. The keepers of the collection reply that a drawer of seed cannot replace a field, and they publish that limit on the first page of their annual report. They ask only that the copies exist while the argument continues.`,
    shared: {
      exclusive: true,
      note: "Danh sách tiêu đề",
      options: [
        { id: "i", label: "i. Một bản sao không thay được cánh đồng" },
        { id: "ii", label: "ii. Vì sao căn hầm trong núi được giữ lạnh" },
        { id: "iii", label: "iii. Thu thập lúa dọc một nhánh sông" },
        { id: "iv", label: "iv. Việc một ngân hàng hạt giống thực sự làm" },
        { id: "v", label: "v. Kiểm tra hạt cũ còn nảy được không" },
        { id: "vi", label: "vi. Chi phí gửi hạt qua biên giới" },
        { id: "vii", label: "vii. Các đầu bếp dùng lúa cổ" },
      ],
    },
    questions: [
      { id: "q1", prompt: "Đoạn A", kind: "radio", accept: ["iv"], explain: "Đoạn A định nghĩa việc ngân hàng hạt làm: giữ bản sao để trồng lại. Tiêu đề về cánh đồng nằm ở đoạn E." },
      { id: "q2", prompt: "Đoạn B", kind: "radio", accept: ["ii"], explain: "minus 18 degrees và lý do chọn núi. Không có câu nào khác nêu nhiệt độ." },
      { id: "q3", prompt: "Đoạn C", kind: "radio", accept: ["iii"], explain: "Mekong, bốn vụ, lúa gia đình." },
      { id: "q4", prompt: "Đoạn D", kind: "radio", accept: ["v"], explain: "germinate mỗi năm năm một lần." },
      { id: "q5", prompt: "Đoạn E", kind: "radio", accept: ["i"], explain: "Critics và câu reply rằng drawer không thay field." },
      { id: "q6", prompt: "Đoạn nào nêu một nhiệt độ?", kind: "radio", options: ["A", "B", "C", "D", "E"].map((id) => ({ id, label: id })), accept: ["B"], explain: "Chỉ đoạn B có minus 18 degrees." },
      { id: "q7", prompt: "Đoạn nào có một sự phản đối?", kind: "radio", options: ["A", "B", "C", "D", "E"].map((id) => ({ id, label: id })), accept: ["E"], explain: "Critics say… chỉ xuất hiện ở E." },
      { id: "q8", prompt: "Đoạn nào nói mục tiêu không phải là giống lúa năng suất cao nhất?", kind: "radio", options: ["A", "B", "C", "D", "E"].map((id) => ({ id, label: id })), accept: ["C"], explain: "They were not trying to find the highest-yielding plant." },
    ],
  },
  {
    id: "r-opinion",
    module: "academic",
    skill: "reading",
    types: ["ynng", "summary-bank", "mcq", "mcq-multi"],
    title: "Một lập luận về thư viện còn sách giấy",
    section: "Reading Academic · quan điểm tác giả",
    minutes: 15,
    instruction: "YES nếu khớp ý tác giả. NO nếu trái ý tác giả. NOT GIVEN nếu tác giả chưa nói. Ngân hàng từ: mỗi từ chỉ một lần.",
    passage: `I am not arguing that every town must keep a large public library. I am arguing that a library which still lends paper books does a job that a phone cannot measure. The quiet rooms, the slow choice of a shelf, and the fact that a book can be finished without a subscription are not romantic extras. They are the service.

Councils often quote falling door counts and then cut the book budget first, while the building stays open as a place to borrow laptops. That choice treats the library as a room with wifi. It ignores why many readers still travel to borrow a novel they could, in theory, buy online. They travel because the copy is free for three weeks, and because nobody is scoring how fast they turn the page.

I do not claim that paper is always better for study. A student revising a diagram may prefer a screen. My claim is narrower: for long stories, paper still encourages a kind of attention that notifications damage. If a council must save money, I would rather see shorter opening hours than a library with no stories left on the shelf.

None of this proves that people who read novels are kinder, and I will not pretend to have that evidence.`,
    shared: {
      exclusive: true,
      note: "Ngân hàng từ cho phần tóm tắt",
      options: [
        { id: "hours", label: "hours" },
        { id: "laptops", label: "laptops" },
        { id: "stories", label: "stories" },
        { id: "kindness", label: "kindness" },
        { id: "speed", label: "speed" },
        { id: "paper", label: "paper" },
      ],
    },
    questions: [
      { id: "q1", prompt: "1. Tác giả cho rằng mọi thị trấn đều cần một thư viện lớn.", kind: "radio", options: yn, accept: ["N"], explain: "Câu đầu: I am not arguing that every town must keep a large public library. Đây là NO, vì tác giả phủ nhận chính ý đó." },
      { id: "q2", prompt: "2. Tác giả coi sách giấy là thứ luôn tốt hơn cho việc học.", kind: "radio", options: yn, accept: ["N"], explain: "I do not claim that paper is always better for study." },
      { id: "q3", prompt: "3. Tác giả muốn giữ chuyện trên kệ hơn là giữ nguyên giờ mở cửa.", kind: "radio", options: yn, accept: ["Y"], explain: "rather see shorter opening hours than a library with no stories." },
      { id: "q4", prompt: "4. Tác giả nghĩ người đọc tiểu thuyết thì tử tế hơn.", kind: "radio", options: yn, accept: ["NG"], explain: "Tác giả nói mình không có bằng chứng và sẽ không giả bộ. Không kết luận họ tử tế hay không. NOT GIVEN." },
      { id: "q5", prompt: "5. Nếu phải tiết kiệm, tác giả ưu tiên cắt ______.", kind: "radio", accept: ["hours"], explain: "shorter opening hours. Từ trong ngân hàng là hours." },
      { id: "q6", prompt: "6. Thứ tác giả không muốn biến mất khỏi kệ là ______.", kind: "radio", accept: ["stories"], explain: "no stories left on the shelf." },
      {
        id: "q7",
        prompt: "7. Vì sao nhiều người vẫn đến mượn tiểu thuyết, theo tác giả?",
        kind: "radio",
        options: [
          { id: "A", label: "Vì bản giấy luôn giúp học bài tốt hơn" },
          { id: "B", label: "Vì bản mượn miễn phí trong ba tuần và không ai chấm tốc độ đọc" },
          { id: "C", label: "Vì hội đồng bắt họ đến để giữ wifi" },
        ],
        accept: ["B"],
        explain: "free for three weeks, và nobody is scoring how fast they turn the page." },
      {
        id: "q8",
        prompt: "8–9. Chọn HAI điều tác giả coi là dịch vụ của thư viện có sách giấy.",
        kind: "multi",
        options: [
          { id: "A", label: "Phòng yên" },
          { id: "B", label: "Bằng chứng người đọc tử tế hơn" },
          { id: "C", label: "Đọc hết một cuốn mà không cần gói thuê bao" },
          { id: "D", label: "Điểm danh tốc độ lật trang" },
        ],
        accept: ["A C"],
        explain: "quiet rooms và finished without a subscription. Kindness bị chính tác giả loại. Việc chấm tốc độ là thứ thư viện không làm.",
      },
    ],
  },
  {
    id: "r-features",
    module: "academic",
    skill: "reading",
    types: ["features", "endings"],
    title: "Ba nghiên cứu nhỏ về nhịp làm việc",
    section: "Reading Academic · nối người với phát hiện",
    minutes: 14,
    instruction: "Một người có thể được chọn nhiều hơn một lần. Với câu nối đuôi, cả câu phải đúng ngữ pháp và đúng bài.",
    passage: `Dr Okonkwo followed night-shift nurses for one month. The group that finished work and then slept in a fully dark room reported fewer morning headaches. Nurses who used a phone in bed did not gain the same rest, even when they slept the same number of hours.

Prof. Berg changed the start of the school day in two secondary schools from 7:30 to 8:30 for a single term. Teachers recorded fewer late arrivals. Test scores did not rise. Berg therefore refuses the claim that a later start automatically improves grades.

Dr Phan measured noise in an open office. When the team wore simple headphones for two hours a day, short tasks were finished faster. Long writing tasks did not improve. Phan warns that headphones are a tool for brief work, not a cure for a badly planned room.

Okonkwo adds a caution that Berg and Phan do not discuss: a dark room is useless if the journey home itself is unsafe.`,
    questions: [
      {
        id: "q1",
        prompt: "1. Ngủ đủ giờ nhưng vẫn không đỡ nếu dùng điện thoại trên giường.",
        kind: "radio",
        options: [
          { id: "A", label: "Okonkwo" },
          { id: "B", label: "Berg" },
          { id: "C", label: "Phan" },
        ],
        accept: ["A"],
        explain: "Chỉ Okonkwo theo dõi y tá và điện thoại.",
      },
      {
        id: "q2",
        prompt: "2. Đi học muộn giảm, điểm kiểm tra thì không tăng.",
        kind: "radio",
        options: [
          { id: "A", label: "Okonkwo" },
          { id: "B", label: "Berg" },
          { id: "C", label: "Phan" },
        ],
        accept: ["B"],
        explain: "Berg: fewer late arrivals, test scores did not rise.",
      },
      {
        id: "q3",
        prompt: "3. Tai nghe chỉ giúp việc ngắn.",
        kind: "radio",
        options: [
          { id: "A", label: "Okonkwo" },
          { id: "B", label: "Berg" },
          { id: "C", label: "Phan" },
        ],
        accept: ["C"],
        explain: "Phan: brief work, long writing did not improve.",
      },
      {
        id: "q4",
        prompt: "4. Nhắc rằng đường về nhà không an toàn thì phòng tối cũng vô ích.",
        kind: "radio",
        options: [
          { id: "A", label: "Okonkwo" },
          { id: "B", label: "Berg" },
          { id: "C", label: "Phan" },
        ],
        accept: ["A"],
        explain: "Câu cuối là của Okonkwo, và nói Berg cùng Phan không bàn chuyện này.",
      },
      {
        id: "q5",
        prompt: "5. A later school start, in Berg's study, ______",
        kind: "radio",
        options: [
          { id: "A", label: "raised test scores within one term." },
          { id: "B", label: "reduced late arrivals but not test scores." },
          { id: "C", label: "made headphones unnecessary." },
        ],
        accept: ["B"],
        explain: "Nối đuôi phải khớp cả dữ liệu của Berg. A trái bài. C không liên quan.",
      },
      {
        id: "q6",
        prompt: "6. Headphones in Phan's office ______",
        kind: "radio",
        options: [
          { id: "A", label: "sped up short tasks only." },
          { id: "B", label: "improved long writing more than short tasks." },
          { id: "C", label: "replaced the need for a dark bedroom." },
        ],
        accept: ["A"],
        explain: "short tasks faster, long writing did not improve.",
      },
    ],
  },
  {
    id: "r-notices",
    module: "general",
    skill: "reading",
    types: ["matching"],
    title: "Sáu thông báo trong công ty",
    section: "Reading General · Section 1",
    minutes: 10,
    instruction: "Nối mỗi người với MỘT thông báo. Có thông báo không dùng. Mỗi chữ cái một lần.",
    passage: `A. Night-shift meal allowance. Staff who work after 10 p.m. may claim the meal allowance. Send the form to Payroll by Friday.

B. The bicycle cage code changes on Monday. Collect the new code from Reception before the weekend. Do not share it by group chat.

C. Free eye test for staff who use a screen for most of the day. The clinic is on Level 2. Book a time on the intranet.

D. Lost property: a black laptop was found in Meeting Room 2. Claim it at Security and bring your staff card.

E. Fire wardens will meet on Thursday at 4 p.m. in Room 4. Only listed wardens need to attend.

F. Wednesday IELTS writing class for staff, limited to 12 places. Email learning@northwind.example if you want a seat.`,
    shared: {
      exclusive: true,
      note: "Thông báo",
      options: "ABCDEF".split("").map((id) => ({ id, label: id })),
    },
    questions: [
      {
        id: "q1",
        prompt: "Mai làm ca đêm và muốn nhận tiền ăn.",
        kind: "radio",
        accept: ["A"],
        explain: "Meal allowance, ca sau 10 giờ đêm, gửi Payroll. Không phải lớp học.",
      },
      {
        id: "q2",
        prompt: "Jonas đi xe đạp và cần mã khoá mới.",
        kind: "radio",
        accept: ["B"],
        explain: "Bicycle cage code, lấy ở Reception.",
      },
      {
        id: "q3",
        prompt: "Hoa nhìn màn hình cả ngày và mắt mỏi.",
        kind: "radio",
        accept: ["C"],
        explain: "Eye test cho người dùng màn hình. Đừng chọn laptop chỉ vì có chữ màn hình gián tiếp.",
      },
      {
        id: "q4",
        prompt: "Ravi để quên laptop đen ở phòng họp.",
        kind: "radio",
        accept: ["D"],
        explain: "Lost property, black laptop, Security kèm staff card.",
      },
    ],
  },
  {
    id: "r-leave",
    module: "general",
    skill: "reading",
    types: ["tfng", "sentence"],
    title: "Nội quy nghỉ phép xưởng Northwind",
    section: "Reading General · Section 2",
    minutes: 12,
    instruction: "TRUE / FALSE / NOT GIVEN dựa trên nội quy, không dựa trên chỗ làm bạn từng biết. Câu điền không quá hai từ trong bài.",
    passage: `Northwind Workshop leave rules

Annual leave must be requested at least ten days before the first day off. Requests sent by text message are not accepted. Use the paper form or the staff intranet.

A maximum of four people from the same shift may be away on the same day. Supervisors may refuse a fifth request even if that worker has unused days.

Sick leave of one or two days does not require a doctor's note. From the third day, a note is required. The note must name the dates, not the illness. Workers do not have to tell colleagues the diagnosis.

Leave during the last week of December is granted in order of the date of the request. Job title does not give priority. Unused annual leave cannot be paid as cash, except when a contract ends.`,
    questions: [
      { id: "q1", prompt: "1. Có thể xin nghỉ bằng tin nhắn.", kind: "radio", options: tf, accept: ["F"], explain: "Requests sent by text message are not accepted." },
      { id: "q2", prompt: "2. Cùng một ca, tối đa bốn người được nghỉ cùng ngày.", kind: "radio", options: tf, accept: ["T"], explain: "A maximum of four people from the same shift." },
      { id: "q3", prompt: "3. Nghỉ ốm một ngày vẫn cần giấy bác sĩ.", kind: "radio", options: tf, accept: ["F"], explain: "One or two days do not require a note." },
      { id: "q4", prompt: "4. Giấy bác sĩ phải ghi tên bệnh.", kind: "radio", options: tf, accept: ["F"], explain: "must name the dates, not the illness." },
      { id: "q5", prompt: "5. Trưởng ca được ưu tiên nghỉ tuần cuối tháng Mười hai.", kind: "radio", options: tf, accept: ["F"], explain: "Job title does not give priority." },
      { id: "q6", prompt: "6. Nhân viên có thể bán ngày phép chưa dùng cho đồng nghiệp.", kind: "radio", options: tf, accept: ["NG"], explain: "Bài nói không đổi ngày phép thành tiền trừ khi hết hợp đồng. Không nói gì về việc bán cho đồng nghiệp. NOT GIVEN." },
      { id: "q7", prompt: "7. Đơn nghỉ năm phải gửi trước ít nhất ______ ngày.", kind: "gap", accept: ["ten", "10"], wordLimit: 1, explain: "at least ten days." },
      { id: "q8", prompt: "8. Giấy bác sĩ bắt đầu cần từ ngày thứ ______.", kind: "gap", accept: ["third", "3", "3rd"], wordLimit: 1, explain: "From the third day." },
    ],
  },
  {
    id: "l-pharmacy",
    module: "both",
    skill: "listening",
    types: ["form"],
    title: "Lấy thuốc tại nhà thuốc Hale",
    section: "Listening · Section 1 · Hội thoại hằng ngày",
    minutes: 8,
    instruction: "Điền mỗi chỗ trống bằng KHÔNG QUÁ HAI TỪ VÀ/HOẶC MỘT SỐ.",
    script:
      "Chemist: Hale Pharmacy, good afternoon. Caller: Hello, I need to collect a repeat prescription. My surname is Okonkwo. That is O-K-O-N-K-W-O. Chemist: Thank you. Date of birth? Caller: The fourteenth of July. Chemist: Is this a new medicine? Caller: No. It is a repeat, the same tablets as last month. Chemist: We can have it ready after half past four. Caller: Please also note that I am allergic to penicillin. Chemist: I will write penicillin on the form. A phone number? Caller: 07700 900 418. Chemist: The charge today is 12 pounds. Caller: Fine. I will come after 4:30.",
    questions: [
      { id: "q1", prompt: "1. Surname", kind: "gap", accept: ["Okonkwo"], wordLimit: 1, explain: "Được đánh vần O-K-O-N-K-W-O." },
      { id: "q2", prompt: "2. Date of birth", kind: "gap", accept: ["14 July", "July 14", "14th July"], wordLimit: 2, explain: "the fourteenth of July. Giới hạn hai từ nên viết 14 July." },
      { id: "q3", prompt: "3. Type of order", kind: "gap", accept: ["repeat"], wordLimit: 1, explain: "Người gọi nói it is a repeat, không phải new." },
      { id: "q4", prompt: "4. Ready after", kind: "gap", accept: ["4:30", "4.30", "16:30"], wordLimit: 2, explain: "after half past four. Viết 4:30, không viết cả cụm half past four vì thừa hai từ." },
      { id: "q5", prompt: "5. Allergy", kind: "gap", accept: ["penicillin"], wordLimit: 1, explain: "allergic to penicillin." },
      { id: "q6", prompt: "6. Phone", kind: "gap", accept: ["07700900418", "07700 900 418"], wordLimit: 3, explain: "07700 900 418." },
      { id: "q7", prompt: "7. Charge (£)", kind: "gap", accept: ["12", "12 pounds"], wordLimit: 2, explain: "12 pounds. Ô đã có đơn vị tiền." },
    ],
  },
  {
    id: "l-canal",
    module: "both",
    skill: "listening",
    types: ["note", "sentence", "summary"],
    title: "Chợ đêm trên kênh",
    section: "Listening · Section 4 · Bài giảng ngắn",
    minutes: 9,
    instruction: "Điền KHÔNG QUÁ HAI TỪ VÀ/HOẶC MỘT SỐ, lấy từ bài nghe.",
    script:
      "Tonight I will describe the canal market in Greyport. It opens at dusk, not at noon. Most stalls sell noodles and fruit. Fish is sold in the morning market, not here. The stone bridge is closed to cars, but bicycles may cross. On a typical Saturday the market receives about 400 visitors. Waste is collected by boat, because trucks cannot reach the towpath. The entry fee for adults is two dollars. Children pay nothing. Please do not write tourism as the reason the market grew. The lecturer says it grew because the bus station moved next to the canal.",
    questions: [
      { id: "q1", prompt: "Note: thị trường mở lúc ______", kind: "gap", accept: ["dusk"], wordLimit: 1, explain: "opens at dusk, not at noon." },
      { id: "q2", prompt: "Note: hầu hết sạp bán noodles and ______", kind: "gap", accept: ["fruit"], wordLimit: 1, explain: "noodles and fruit. Cá bán ở chợ sáng." },
      { id: "q3", prompt: "Sentence: The bridge is closed to ______.", kind: "gap", accept: ["cars"], wordLimit: 1, explain: "closed to cars. Xe đạp vẫn qua được." },
      { id: "q4", prompt: "Note: khoảng ______ visitors vào thứ Bảy", kind: "gap", accept: ["400", "four hundred"], wordLimit: 2, explain: "about 400 visitors." },
      { id: "q5", prompt: "Summary: Waste is collected by ______.", kind: "gap", accept: ["boat"], wordLimit: 1, explain: "collected by boat." },
      { id: "q6", prompt: "Sentence: Adults pay two ______.", kind: "gap", accept: ["dollars"], wordLimit: 1, explain: "two dollars. Trẻ em không trả." },
      { id: "q7", prompt: "Note: chợ lớn lên vì the ______ moved", kind: "gap", accept: ["bus station"], wordLimit: 2, explain: "because the bus station moved. Không phải tourism." },
    ],
  },
  {
    id: "l-ferry",
    module: "both",
    skill: "listening",
    types: ["table"],
    title: "Ba bến phà",
    section: "Listening · Section 2 · Một người nói",
    minutes: 8,
    instruction: "Điền bảng. Mỗi ô không quá hai từ và/hoặc một số. Đừng lấy nhầm số của bến bên cạnh.",
    script:
      "Here are the three ferry stops. The Red stop runs every 15 minutes and the fare is 2 pounds 50. The Blue stop runs once an hour and the fare is 4 pounds. The Green stop opens at weekends only, and residents pay nothing. Visitors at Green still pay 1 pound. Please do not copy the Red fare onto the Blue row.",
    questions: [
      { id: "q1", prompt: "Red · Tần suất", kind: "gap", accept: ["15 minutes"], wordLimit: 2, explain: "every 15 minutes. Viết 15 minutes, không chép cả câu." },
      { id: "q2", prompt: "Red · Giá (£)", kind: "gap", accept: ["2.50", "2.5", "250"], wordLimit: 1, explain: "2 pounds 50. Viết 2.50." },
      { id: "q3", prompt: "Blue · Tần suất", kind: "gap", accept: ["hourly"], wordLimit: 1, explain: "once an hour. Viết hourly. Đừng lấy 15 minutes của bến Red." },
      { id: "q4", prompt: "Blue · Giá (£)", kind: "gap", accept: ["4", "4 pounds"], wordLimit: 2, explain: "4 pounds." },
      { id: "q5", prompt: "Green · Khi nào chạy", kind: "gap", accept: ["weekends", "weekends only"], wordLimit: 2, explain: "at weekends only." },
      { id: "q6", prompt: "Green · Giá cho người ở địa phương", kind: "gap", accept: ["nothing", "free", "0"], wordLimit: 1, explain: "residents pay nothing. Khách vẫn trả 1 pound, đừng điền 1." },
    ],
  },
  {
    id: "l-pier",
    module: "both",
    skill: "listening",
    types: ["map"],
    title: "Cầu cảng Greyport",
    section: "Listening · Section 2 · Sơ đồ",
    minutes: 8,
    figure: "pier",
    shared: {
      exclusive: true,
      note: "Chữ trên cầu cảng",
      options: "ABCDE".split("").map((id) => ({ id, label: id })),
    },
    instruction: "Nhìn cầu cảng. Mỗi chỗ chọn một chữ A–E. Mỗi chữ một lần. Lối vào ở bên trái.",
    script:
      "Welcome to Greyport pier. You are standing at the west entrance, on the left of the plan. The first hut, letter A, is the ticket office. Buy tickets there, not at the cafe. The next hut, letter B, is the cafe. The boat hire desk is in the middle, letter C. The toilets are letter D, just before the end of the pier. The gift shop, letter E, is at the far east end and it is closed this month. The water is below the row of huts.",
    questions: [
      { id: "q1", prompt: "Quầy vé", kind: "radio", accept: ["A"], explain: "First hut, letter A. Không mua vé ở quán." },
      { id: "q2", prompt: "Quán cà phê", kind: "radio", accept: ["B"], explain: "Next hut, letter B." },
      { id: "q3", prompt: "Thuê thuyền", kind: "radio", accept: ["C"], explain: "In the middle, letter C." },
      { id: "q4", prompt: "Nhà vệ sinh", kind: "radio", accept: ["D"], explain: "Just before the end, letter D." },
      { id: "q5", prompt: "Cửa hàng quà, đang đóng", kind: "radio", accept: ["E"], explain: "Far east end, letter E." },
    ],
  },
  {
    id: "l-cistern",
    module: "both",
    skill: "listening",
    types: ["diagram", "flow"],
    title: "Bể lọc nước mưa",
    section: "Listening · Section 3 · Sơ đồ quy trình",
    minutes: 8,
    figure: "filter",
    instruction: "Điền MỘT TỪ cho mỗi bể. Nước đi từ A xuống D. Đây không phải bài lọc vải-sỏi-cát-than của lần trước.",
    script:
      "This rainwater cistern is different from the cloth filter you may have seen. Tank A, at the top, is only a mesh. It catches leaves. Tank B holds charcoal. Tank C holds sand. Tank D, at the bottom, holds gravel. If you swap sand and gravel, the pipe blocks. The mesh is not cloth, and there is no cloth in this design.",
    questions: [
      { id: "q1", prompt: "Bể A (trên cùng)", kind: "gap", accept: ["mesh"], wordLimit: 1, explain: "only a mesh. Không phải cloth." },
      { id: "q2", prompt: "Bể B", kind: "gap", accept: ["charcoal"], wordLimit: 1, explain: "holds charcoal." },
      { id: "q3", prompt: "Bể C", kind: "gap", accept: ["sand"], wordLimit: 1, explain: "holds sand." },
      { id: "q4", prompt: "Bể D (dưới cùng)", kind: "gap", accept: ["gravel"], wordLimit: 1, explain: "holds gravel. Đảo sand và gravel sẽ tắc ống." },
    ],
  },
  {
    id: "l-poster",
    module: "both",
    skill: "listening",
    types: ["mcq", "matching", "short", "mcq-multi"],
    title: "Nhóm làm poster chợ",
    section: "Listening · Section 3 · Nhiều người nói",
    minutes: 10,
    instruction: "Nghe một lượt. Câu chọn nhiều: đủ hai chữ cái. Câu điền: không quá hai từ.",
    script:
      "Tutor: Your poster failed because it had too much text, not because the colour was wrong. Nina: I thought the photos were the problem. Tutor: The photos were fine. Nina will interview the shopkeepers. Marco will print the new poster. The tutor will only check the spelling. Do not give the interviews to Marco. The deadline is Friday. Two risks matter: the market may close early, and the printer may run out of blue ink. The cost of the paper is not a risk we need on the poster. The word you still need for the title is harbour.",
    questions: [
      {
        id: "q1",
        prompt: "1. Vì sao poster thất bại?",
        kind: "radio",
        options: [
          { id: "A", label: "Màu sai" },
          { id: "B", label: "Quá nhiều chữ" },
          { id: "C", label: "Ảnh mờ" },
        ],
        accept: ["B"],
        explain: "too much text. Ảnh thì fine, màu không phải lý do.",
      },
      {
        id: "q2",
        prompt: "2. Ai phỏng vấn tiểu thương?",
        kind: "radio",
        options: [
          { id: "A", label: "Nina" },
          { id: "B", label: "Marco" },
          { id: "C", label: "Giảng viên" },
        ],
        accept: ["A"],
        explain: "Nina will interview the shopkeepers.",
      },
      {
        id: "q3",
        prompt: "3. Ai in poster mới?",
        kind: "radio",
        options: [
          { id: "A", label: "Nina" },
          { id: "B", label: "Marco" },
          { id: "C", label: "Giảng viên" },
        ],
        accept: ["B"],
        explain: "Marco will print. Giảng viên chỉ check spelling.",
      },
      {
        id: "q4",
        prompt: "4. Ai soát chính tả?",
        kind: "radio",
        options: [
          { id: "A", label: "Nina" },
          { id: "B", label: "Marco" },
          { id: "C", label: "Giảng viên" },
        ],
        accept: ["C"],
        explain: "The tutor will only check the spelling.",
      },
      { id: "q5", prompt: "5. Hạn nộp là ______.", kind: "gap", accept: ["Friday"], wordLimit: 1, explain: "The deadline is Friday." },
      { id: "q6", prompt: "6. Từ còn thiếu trên tiêu đề là ______.", kind: "gap", accept: ["harbour", "harbor"], wordLimit: 1, explain: "the word you still need for the title is harbour." },
      {
        id: "q7",
        prompt: "7–8. Chọn HAI rủi ro cần ghi.",
        kind: "multi",
        options: [
          { id: "A", label: "Chợ đóng sớm" },
          { id: "B", label: "Hết mực xanh" },
          { id: "C", label: "Giá giấy" },
          { id: "D", label: "Mất ảnh" },
        ],
        accept: ["A B", "B A"],
        explain: "market may close early, and the printer may run out of blue ink. Giá giấy không phải rủi ro cần nêu.",
      },
    ],
  },
  {
    id: "r-ferries",
    module: "academic",
    skill: "reading",
    types: ["tfng", "sentence", "short"],
    title: "Phà thay cho hàng xe trên cầu",
    section: "Reading Academic · đoạn ngắn",
    minutes: 14,
    instruction: "TRUE / FALSE / NOT GIVEN theo bài, không theo thành phố bạn biết. Chỗ trống không quá hai từ trong bài.",
    passage: `For six years the east bridge in Hale carried a queue that rarely moved before 9 a.m. In 2019 the council kept the bridge for bicycles and opened a small ferry for cars. The ferry does not replace the bridge. It only takes vehicles that have booked a place the day before.

The first survey counted 180 cars a morning, not 180 people. A later count in winter found fewer cars, but the report does not give that winter number. Drivers who miss the boat wait for the next one. They are not allowed to drive back onto the bridge.

The ferry fee is paid by the driver, not by the city. Children who walk on with a parent pay nothing. The council has not published the cost of building the landing stage, so a claim about that cost cannot be checked from this text.`,
    questions: [
      { id: "q1", prompt: "1. Cầu phía đông bị dỡ.", kind: "radio", options: tf, accept: ["F"], explain: "The council kept the bridge for bicycles." },
      { id: "q2", prompt: "2. Xe muốn lên phà phải đặt chỗ từ hôm trước.", kind: "radio", options: tf, accept: ["T"], explain: "booked a place the day before." },
      { id: "q3", prompt: "3. Khảo sát đầu đếm 180 người mỗi buổi sáng.", kind: "radio", options: tf, accept: ["F"], explain: "180 cars, not 180 people." },
      { id: "q4", prompt: "4. Báo cáo nêu số xe mùa đông.", kind: "radio", options: tf, accept: ["F"], explain: "does not give that winter number. Đây là FALSE vì bài phủ định việc nêu con số, không phải NOT GIVEN." },
      { id: "q5", prompt: "5. Tài xế lỡ phà được quay lên cầu.", kind: "radio", options: tf, accept: ["F"], explain: "not allowed to drive back onto the bridge." },
      { id: "q6", prompt: "6. Thành phố trả phí vé phà.", kind: "radio", options: tf, accept: ["F"], explain: "paid by the driver, not by the city." },
      { id: "q7", prompt: "7. Bài nêu chi phí xây bến.", kind: "radio", options: tf, accept: ["NG"], explain: "has not published the cost. Không có con số để kết luận đắt hay rẻ. NOT GIVEN." },
      { id: "q8", prompt: "8. The bridge is now kept for ______.", kind: "gap", accept: ["bicycles"], wordLimit: 1, explain: "kept the bridge for bicycles." },
      { id: "q9", prompt: "9. Children who walk on pay ______.", kind: "gap", accept: ["nothing"], wordLimit: 1, explain: "pay nothing." },
    ],
  },
  {
    id: "r-lamps",
    module: "academic",
    skill: "reading",
    types: ["headings", "info-match"],
    title: "Đèn đường và côn trùng",
    section: "Reading Academic · tiêu đề đoạn",
    minutes: 14,
    instruction: "Mỗi tiêu đề một lần. Có tiêu đề thừa. Câu hỏi đoạn: chọn đoạn chứa đúng chi tiết.",
    passage: `A
The town replaced orange street lamps with white ones to save power. Engineers measured the bill. They did not set out to study insects. The change in the light was a side effect of a budget decision.

B
A biology class then counted moths under both colours. White lamps drew more moths, and the students found the same pattern on three streets. They did not claim that every insect species behaves this way.

C
Shopkeepers on Bridge Street asked for the orange lamps to return because customers said the white light felt harsh. The request was about comfort, not about moths. The council has not voted on it.

D
One researcher warns that a short student count is not a city-wide study. She asks for a full year of data before any lamp is changed again. She does not oppose saving power. She opposes a quick conclusion.`,
    shared: {
      exclusive: true,
      note: "Tiêu đề",
      options: [
        { id: "i", label: "i. Một quyết định để giảm tiền điện" },
        { id: "ii", label: "ii. Đếm bướm đêm dưới hai màu đèn" },
        { id: "iii", label: "iii. Vì sao cửa hàng muốn màu cũ" },
        { id: "iv", label: "iv. Cảnh báo về kết luận quá sớm" },
        { id: "v", label: "v. Chi phí thay toàn bộ cột đèn" },
        { id: "vi", label: "vi. Loài chim bỏ phố vì ánh sáng" },
      ],
    },
    questions: [
      { id: "q1", prompt: "Đoạn A", kind: "radio", accept: ["i"], explain: "save power, budget decision. Không phải bài nghiên cứu côn trùng." },
      { id: "q2", prompt: "Đoạn B", kind: "radio", accept: ["ii"], explain: "counted moths under both colours." },
      { id: "q3", prompt: "Đoạn C", kind: "radio", accept: ["iii"], explain: "customers said the white light felt harsh." },
      { id: "q4", prompt: "Đoạn D", kind: "radio", accept: ["iv"], explain: "warns against a quick conclusion. Bà không phản đối việc tiết kiệm điện." },
      { id: "q5", prompt: "Đoạn nào nói đèn trắng hút nhiều bướm đêm hơn?", kind: "radio", options: ["A", "B", "C", "D"].map((id) => ({ id, label: id })), accept: ["B"], explain: "Chỉ đoạn B có kết quả đếm." },
      { id: "q6", prompt: "Đoạn nào nói hội đồng chưa bỏ phiếu?", kind: "radio", options: ["A", "B", "C", "D"].map((id) => ({ id, label: id })), accept: ["C"], explain: "The council has not voted on it." },
    ],
  },
  {
    id: "r-tools",
    module: "academic",
    skill: "reading",
    types: ["features", "endings"],
    title: "Ba cách giảm ồn lớp học",
    section: "Reading Academic · nối người với ý",
    minutes: 12,
    instruction: "Mỗi người một ý. Câu hoàn thành: chọn kết đúng cả ngữ pháp lẫn thông tin.",
    passage: `Ibrahim tested soft pads under chair legs. The pads cut the scraping noise, but test scores did not change.

Cho tried a one-minute silence before written work. Students finished long answers more often. Short quizzes stayed the same.

Adeyemi moved the noisiest group into the corridor for group talk. The classroom became quieter, and fewer pupils arrived late to the next lesson. She did not measure test scores.`,
    questions: [
      {
        id: "q1",
        prompt: "Giảm tiếng kéo ghế",
        kind: "radio",
        options: [
          { id: "A", label: "Ibrahim" },
          { id: "B", label: "Cho" },
          { id: "C", label: "Adeyemi" },
        ],
        accept: ["A"],
        explain: "soft pads under chair legs.",
      },
      {
        id: "q2",
        prompt: "Một phút im lặng trước bài viết",
        kind: "radio",
        options: [
          { id: "A", label: "Ibrahim" },
          { id: "B", label: "Cho" },
          { id: "C", label: "Adeyemi" },
        ],
        accept: ["B"],
        explain: "one-minute silence before written work.",
      },
      {
        id: "q3",
        prompt: "Đưa nhóm ồn ra hành lang",
        kind: "radio",
        options: [
          { id: "A", label: "Ibrahim" },
          { id: "B", label: "Cho" },
          { id: "C", label: "Adeyemi" },
        ],
        accept: ["C"],
        explain: "moved the noisiest group into the corridor.",
      },
      {
        id: "q4",
        prompt: "Miếng lót chân ghế …",
        kind: "radio",
        options: [
          { id: "A", label: "raised test scores within a week." },
          { id: "B", label: "cut a scraping noise but not test scores." },
          { id: "C", label: "stopped students arriving late." },
        ],
        accept: ["B"],
        explain: "cut the scraping noise, but test scores did not change.",
      },
      {
        id: "q5",
        prompt: "Phút im lặng của Cho …",
        kind: "radio",
        options: [
          { id: "A", label: "helped long answers more than short quizzes." },
          { id: "B", label: "made short quizzes much faster." },
          { id: "C", label: "moved the noisy group outside." },
        ],
        accept: ["A"],
        explain: "long answers more often. Short quizzes stayed the same.",
      },
    ],
  },
  {
    id: "r-screen",
    module: "academic",
    skill: "reading",
    types: ["ynng", "summary-bank", "mcq", "mcq-multi"],
    title: "Màn hình trong thư viện trường",
    section: "Reading Academic · ý tác giả",
    minutes: 14,
    instruction: "YES / NO / NOT GIVEN là ý tác giả. Ngân hàng từ: mỗi từ một lần. Câu chọn nhiều cần đủ hai chữ.",
    passage: `I am not asking the school to remove every screen from the library. I am asking it to keep one silent room without them. Pupils who need a laptop can sit in the main hall.

I do not claim that paper is always better for revision. I do claim that a flashing page makes nearby readers lose the line they were on. If money is short, I would rather reduce the number of new screens than shorten the opening hours.

I have no evidence that pupils who read novels are kinder than others, and I will not pretend that I do. The quiet room is a practical request, not a moral one.`,
    shared: {
      exclusive: true,
      note: "Ngân hàng từ",
      options: [
        { id: "screens", label: "screens" },
        { id: "hours", label: "hours" },
        { id: "kindness", label: "kindness" },
        { id: "hall", label: "hall" },
      ],
    },
    questions: [
      { id: "q1", prompt: "1. Tác giả muốn cất hết màn hình khỏi thư viện.", kind: "radio", options: yn, accept: ["N"], explain: "not asking the school to remove every screen." },
      { id: "q2", prompt: "2. Tác giả cho rằng giấy luôn tốt hơn khi ôn bài.", kind: "radio", options: yn, accept: ["N"], explain: "I do not claim that paper is always better." },
      { id: "q3", prompt: "3. Tác giả ưu tiên bớt màn hình mới hơn là cắt giờ mở cửa.", kind: "radio", options: yn, accept: ["Y"], explain: "rather reduce the number of new screens than shorten the opening hours." },
      { id: "q4", prompt: "4. Tác giả nghĩ người đọc tiểu thuyết tử tế hơn.", kind: "radio", options: yn, accept: ["NG"], explain: "no evidence, and will not pretend. NOT GIVEN, không phải NO về một kết luận tác giả không đưa." },
      { id: "q5", prompt: "5. Nếu thiếu tiền, tác giả muốn giảm số ______ mới.", kind: "radio", accept: ["screens"], explain: "reduce the number of new screens." },
      { id: "q6", prompt: "6. Học sinh cần laptop có thể ngồi ở ______.", kind: "radio", accept: ["hall"], explain: "sit in the main hall." },
      {
        id: "q7",
        prompt: "7. Tác giả xin phòng im lặng chủ yếu vì điều gì?",
        kind: "radio",
        options: [
          { id: "A", label: "Vì giấy luôn giúp điểm cao hơn" },
          { id: "B", label: "Vì trang nhấp nháy làm người bên cạnh mất dòng" },
          { id: "C", label: "Vì hội đồng bắt học sinh bỏ laptop" },
        ],
        accept: ["B"],
        explain: "a flashing page makes nearby readers lose the line.",
      },
      {
        id: "q8",
        prompt: "8–9. Tác giả công nhận hai điều nào?",
        kind: "multi",
        options: [
          { id: "A", label: "Không đòi bỏ mọi màn hình" },
          { id: "B", label: "Có bằng chứng người đọc tử tế hơn" },
          { id: "C", label: "Không nói giấy luôn tốt hơn" },
          { id: "D", label: "Muốn rút ngắn giờ mở cửa" },
        ],
        accept: ["A C", "C A"],
        explain: "not remove every screen, and does not claim paper is always better. B và D trái bài.",
      },
    ],
  },
  {
    id: "r-gt-pool",
    module: "general",
    skill: "reading",
    types: ["short"],
    title: "Nội quy bể bơi nhân viên",
    section: "Reading General · trả lời ngắn",
    minutes: 10,
    instruction: "Trả lời bằng KHÔNG QUÁ HAI TỪ VÀ/HOẶC MỘT SỐ lấy từ bài. Không viết cả câu.",
    passage: `Staff pool at the Hale works

The pool opens at 6:30 a.m. on weekdays and at 8 a.m. on Sundays. It is closed on Mondays for cleaning.

Lane 1 is for slow swimmers. Lane 4 is reserved for classes. A class runs at noon and lasts 40 minutes.

Children under 12 must stay with an adult. The deepest water is 1.8 metres. Lockers take a one-pound coin, which is returned when you open the locker.

Food is not allowed on the pool deck. Water bottles are allowed. Report a lost watch at the desk before you leave, because the desk closes 15 minutes after the last swim.`,
    questions: [
      { id: "q1", prompt: "1. Bể mở lúc mấy giờ vào ngày thường?", kind: "gap", accept: ["6:30", "6.30", "630"], wordLimit: 1, explain: "6:30 a.m. on weekdays. 8 a.m. là Chủ nhật." },
      { id: "q2", prompt: "2. Ngày nào bể đóng để vệ sinh?", kind: "gap", accept: ["Mondays", "Monday"], wordLimit: 1, explain: "closed on Mondays." },
      { id: "q3", prompt: "3. Làn nào dành cho người bơi chậm?", kind: "gap", accept: ["1", "lane 1"], wordLimit: 2, explain: "Lane 1. Lane 4 là lớp học." },
      { id: "q4", prompt: "4. Lớp học kéo dài bao lâu?", kind: "gap", accept: ["40 minutes"], wordLimit: 2, explain: "lasts 40 minutes." },
      { id: "q5", prompt: "5. Trẻ dưới tuổi nào phải có người lớn đi cùng?", kind: "gap", accept: ["12"], wordLimit: 1, explain: "under 12." },
      { id: "q6", prompt: "6. Chỗ sâu nhất là bao nhiêu mét?", kind: "gap", accept: ["1.8", "1.8 metres"], wordLimit: 2, explain: "1.8 metres." },
      { id: "q7", prompt: "7. Tủ đồ nhận đồng xu mệnh giá nào?", kind: "gap", accept: ["one pound", "1 pound", "one-pound"], wordLimit: 2, explain: "a one-pound coin." },
    ],
  },
  {
    id: "r-gt-course",
    module: "general",
    skill: "reading",
    types: ["mcq"],
    title: "Lớp sơ cứu cho ca đêm",
    section: "Reading General · trắc nghiệm",
    minutes: 10,
    instruction: "Chọn một đáp án. Đáp án đúng thường được viết lại, không chép nguyên một dòng sai chỗ.",
    passage: `Night-shift first-aid class

The class is for staff who work after 8 p.m. Day staff may join only if a night worker gives up a seat. There are 16 seats. The class is on Thursday at 5 p.m. in Room 2, not in the canteen.

You must bring your staff card. A notebook is useful but not required. The trainer will not mark a test. Attendance is recorded so that the site can show who has had the lesson.

Email learning@hale.example before Tuesday if you want a seat. Messages sent to a supervisor are not counted as a booking. If you are ill on the day, your seat can be given to the next person on the list. It is not kept for the following week.`,
    questions: [
      {
        id: "q1",
        prompt: "1. Lớp này dành trước hết cho ai?",
        kind: "radio",
        options: [
          { id: "A", label: "Mọi nhân viên ban ngày" },
          { id: "B", label: "Người làm việc sau 8 giờ tối" },
          { id: "C", label: "Chỉ quản lý" },
        ],
        accept: ["B"],
        explain: "staff who work after 8 p.m. Ban ngày chỉ vào nếu ca đêm nhường chỗ.",
      },
      {
        id: "q2",
        prompt: "2. Lớp học ở đâu?",
        kind: "radio",
        options: [
          { id: "A", label: "Phòng 2" },
          { id: "B", label: "Căng tin" },
          { id: "C", label: "Phòng y tế" },
        ],
        accept: ["A"],
        explain: "in Room 2, not in the canteen.",
      },
      {
        id: "q3",
        prompt: "3. Buổi học có bài kiểm tra được chấm không?",
        kind: "radio",
        options: [
          { id: "A", label: "Có, và điểm ghi vào hồ sơ" },
          { id: "B", label: "Không, chỉ ghi danh có mặt" },
          { id: "C", label: "Chỉ chấm nếu mang vở" },
        ],
        accept: ["B"],
        explain: "will not mark a test. Attendance is recorded.",
      },
      {
        id: "q4",
        prompt: "4. Đặt chỗ bằng cách nào?",
        kind: "radio",
        options: [
          { id: "A", label: "Nhắn cho quản lý" },
          { id: "B", label: "Email learning@hale.example trước thứ Ba" },
          { id: "C", label: "Đến sớm thứ Năm" },
        ],
        accept: ["B"],
        explain: "Email before Tuesday. Tin nhắn cho supervisor không tính là booking.",
      },
      {
        id: "q5",
        prompt: "5. Nếu đau ốm đúng ngày học thì chỗ đó thế nào?",
        kind: "radio",
        options: [
          { id: "A", label: "Giữ đến tuần sau" },
          { id: "B", label: "Có thể chuyển cho người kế trên danh sách" },
          { id: "C", label: "Được hoàn tiền" },
        ],
        accept: ["B"],
        explain: "given to the next person. It is not kept for the following week.",
      },
    ],
  },
  {
    id: "r-gt-board",
    module: "general",
    skill: "reading",
    types: ["matching"],
    title: "Bảng tin ký túc xá",
    section: "Reading General · Section 1",
    minutes: 10,
    instruction: "Nối mỗi người với MỘT thông báo. Có thông báo thừa. Mỗi chữ một lần.",
    passage: `A. Laundry tokens are sold at the office until 6 p.m. The machines do not take cash.

B. The east gate will be locked at 11 p.m. this Friday because of a concert. Use the north gate after that time.

C. A blue helmet was left in the bike shed. Describe the stickers before you collect it from the porter.

D. Volunteers are needed to sort books for the Saturday sale. Meet in the common room at 9 a.m. No heavy lifting.

E. The water in Block C will be off from 1 p.m. to 3 p.m. on Wednesday. Fill a bottle earlier.

F. Guitar lessons, beginner only, start next month. Pay the tutor directly. The office does not take this fee.`,
    shared: {
      exclusive: true,
      note: "Thông báo",
      options: "ABCDEF".split("").map((id) => ({ id, label: id })),
    },
    questions: [
      { id: "q1", prompt: "Priya cần xu giặt vì máy không nhận tiền mặt.", kind: "radio", accept: ["A"], explain: "Laundry tokens, machines do not take cash." },
      { id: "q2", prompt: "Sam về sau 11 giờ tối thứ Sáu và cần cổng còn mở.", kind: "radio", accept: ["B"], explain: "Use the north gate after 11 p.m. Friday." },
      { id: "q3", prompt: "Linh mất mũ bảo hiểm xanh ở nhà xe.", kind: "radio", accept: ["C"], explain: "blue helmet in the bike shed. Phải mô tả stickers." },
      { id: "q4", prompt: "Omar muốn phụ bán sách sáng thứ Bảy, không khuân đồ nặng.", kind: "radio", accept: ["D"], explain: "sort books, no heavy lifting, 9 a.m." },
      { id: "q5", prompt: "Hana ở Block C và cần nước trước buổi chiều thứ Tư.", kind: "radio", accept: ["E"], explain: "water off 1 p.m. to 3 p.m. Wednesday. Không phải lớp guitar." },
    ],
  },
  {
    id: "r-gt-safety",
    module: "general",
    skill: "reading",
    types: ["tfng", "sentence"],
    title: "Nội quy kho Hale",
    section: "Reading General · Section 2",
    minutes: 12,
    instruction: "TRUE / FALSE / NOT GIVEN theo nội quy. Chỗ trống không quá hai từ trong bài.",
    passage: `Hale warehouse safety note

Visitors must sign the book at the door. A high-visibility vest is provided at the same desk. Hard hats are required only in the rack aisles, not in the office.

Forklifts have priority in every aisle. Pedestrians must wait at the yellow line. Running is not allowed, even when a lorry is late.

Accidents, including small cuts, must be written in the red book before the end of the shift. The book is kept in the office, not in the first-aid box. Staff do not have to name a witness if nobody else was there.

Personal headphones are banned on the floor. The radio used by the supervisor is allowed. The note does not say whether phones may stay in a pocket.`,
    questions: [
      { id: "q1", prompt: "1. Khách phải ký sổ ở cửa.", kind: "radio", options: tf, accept: ["T"], explain: "Visitors must sign the book at the door." },
      { id: "q2", prompt: "2. Mũ cứng bắt buộc cả trong văn phòng.", kind: "radio", options: tf, accept: ["F"], explain: "only in the rack aisles, not in the office." },
      { id: "q3", prompt: "3. Người đi bộ được ưu tiên trong lối đi.", kind: "radio", options: tf, accept: ["F"], explain: "Forklifts have priority." },
      { id: "q4", prompt: "4. Vết đứt nhỏ không cần ghi sổ.", kind: "radio", options: tf, accept: ["F"], explain: "including small cuts, must be written in the red book." },
      { id: "q5", prompt: "5. Sổ để trong hộp sơ cứu.", kind: "radio", options: tf, accept: ["F"], explain: "kept in the office, not in the first-aid box." },
      { id: "q6", prompt: "6. Nhân viên được nghe headphone cá nhân ở khu sàn.", kind: "radio", options: tf, accept: ["F"], explain: "Personal headphones are banned on the floor." },
      { id: "q7", prompt: "7. Điện thoại để trong túi thì được phép.", kind: "radio", options: tf, accept: ["NG"], explain: "The note does not say whether phones may stay in a pocket." },
      { id: "q8", prompt: "8. Accidents must be written in the ______ book.", kind: "gap", accept: ["red"], wordLimit: 1, explain: "the red book." },
      { id: "q9", prompt: "9. Pedestrians wait at the yellow ______.", kind: "gap", accept: ["line"], wordLimit: 1, explain: "at the yellow line." },
    ],
  },
  {
    id: "r-gt-view",
    module: "general",
    skill: "reading",
    types: ["ynng"],
    title: "Thư của quản lý ca về giờ nghỉ",
    section: "Reading General · ý người viết",
    minutes: 8,
    instruction: "YES nếu khớp ý người viết. NO nếu trái ý đó. NOT GIVEN nếu người viết chưa nói.",
    passage: `A note from the shift manager

I am not arguing that the break should be removed. I am arguing that a ten-minute break in the middle of a hot shift is too short. I do not claim that a longer break will raise output. I only claim that people make fewer mistakes with the seals when they have had water.

I have no figures for other sites, and I will not guess whether they agree. What I ask for here is twenty minutes, not a new canteen.`,
    questions: [
      { id: "q1", prompt: "1. Người viết muốn bỏ giờ nghỉ.", kind: "radio", options: yn, accept: ["N"], explain: "I am not arguing that the break should be removed." },
      { id: "q2", prompt: "2. Người viết cho rằng nghỉ mười phút giữa ca nóng là quá ngắn.", kind: "radio", options: yn, accept: ["Y"], explain: "a ten-minute break ... is too short." },
      { id: "q3", prompt: "3. Người viết khẳng định nghỉ lâu hơn sẽ tăng sản lượng.", kind: "radio", options: yn, accept: ["N"], explain: "I do not claim that a longer break will raise output." },
      { id: "q4", prompt: "4. Người viết nghĩ các xưởng khác cũng đồng ý.", kind: "radio", options: yn, accept: ["NG"], explain: "no figures for other sites, and will not guess. NOT GIVEN." },
      { id: "q5", prompt: "5. Người viết xin một căng tin mới.", kind: "radio", options: yn, accept: ["N"], explain: "twenty minutes, not a new canteen." },
    ],
  },
  {
    id: "r-gt-two",
    module: "general",
    skill: "reading",
    types: ["mcq-multi"],
    title: "Hai việc cần làm trước thứ Sáu",
    section: "Reading General · chọn hai ý",
    minutes: 8,
    instruction: "Mỗi câu chọn ĐỦ HAI chữ cái. Thừa hoặc thiếu đều sai.",
    passage: `Before Friday, two tasks are required. Return the locker key to the office, and complete the fire-exit quiz on the intranet. Bringing a packed lunch is allowed but not required. The optional first-aid talk on Thursday is not part of this list.

For the site visit, you must wear closed shoes and a high-visibility vest. A hard hat will be lent at the gate. Gloves are optional. Cameras are not allowed, but that rule is separate from the clothing list.`,
    questions: [
      {
        id: "q1",
        prompt: "1–2. Trước thứ Sáu, hai việc nào là bắt buộc?",
        kind: "multi",
        options: [
          { id: "A", label: "Trả chìa khoá tủ" },
          { id: "B", label: "Làm bài thoát hiểm trên intranet" },
          { id: "C", label: "Mang cơm" },
          { id: "D", label: "Dự buổi sơ cứu thứ Năm" },
        ],
        accept: ["A B", "B A"],
        explain: "Return the locker key and complete the fire-exit quiz. Cơm và buổi sơ cứu không bắt buộc.",
      },
      {
        id: "q2",
        prompt: "3–4. Khi đi thăm xưởng, hai thứ nào bắt buộc mặc?",
        kind: "multi",
        options: [
          { id: "A", label: "Giày kín" },
          { id: "B", label: "Áo phản quang" },
          { id: "C", label: "Găng tay" },
          { id: "D", label: "Mũ cứng của riêng mình" },
        ],
        accept: ["A B", "B A"],
        explain: "closed shoes and a high-visibility vest. Mũ được cho mượn, không phải bắt mang mũ riêng. Găng tay optional.",
      },
    ],
  },
];

export function papersFor(type: string, module: "academic" | "general"): Paper[] {
  const all = PAPERS.filter((p) => p.types.includes(type as Paper["types"][number]));
  const preferred = all.filter((p) => p.module === "both" || p.module === module);
  return preferred.length ? preferred : all;
}
