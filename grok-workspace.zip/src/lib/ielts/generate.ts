import type { ChartModel, Module, SpeakingTask, WritingTask, WritingType } from "./types";

type Topic = {
  id: string;
  module: Module | "both";
  keywords: string[];
  opinion: string;
  viewA: string;
  viewB: string;
  adv: string;
  problem: string;
  why: string;
  what: string;
  ideas: string[];
};

const TOPICS: Topic[] = [
  {
    id: "salary",
    module: "both",
    keywords: ["salary", "job", "satisfaction", "work", "pay"],
    opinion: "The most important part of any job is the salary.",
    viewA: "Some people believe salary matters more than anything else in a job.",
    viewB: "Others argue that enjoyment of the work matters more than pay.",
    adv: "choosing a job mainly because of the salary",
    problem: "Many employees stay in jobs that make them unhappy.",
    why: "Why do many people remain in jobs they do not enjoy?",
    what: "What could employers do to make work more satisfying?",
    ideas: ["Lương phải đủ sống nên không thể bỏ qua", "Thu nhập cao vẫn kiệt sức nếu việc vô nghĩa", "Người thấy việc có ích thường gắn bó lâu hơn"],
  },
  {
    id: "university",
    module: "academic",
    keywords: ["university", "education", "students", "academic", "degree"],
    opinion: "University education should be available to everyone who wants it, regardless of academic results.",
    viewA: "Some people think every applicant should be allowed to enter university.",
    viewB: "Others think places should be kept for students with strong academic results.",
    adv: "opening university to every applicant",
    problem: "University places are limited while demand keeps rising.",
    why: "Why do so many young people want a university degree?",
    what: "Should governments restrict entry or expand universities?",
    ideas: ["Bằng cấp đang là điều kiện của nhiều nghề", "Lớp quá đông làm giảm chất lượng", "Học nghề có thể hợp hơn với một số người"],
  },
  {
    id: "remote",
    module: "both",
    keywords: ["remote", "home", "office", "employees", "work"],
    opinion: "Employees should be allowed to work from home most of the week.",
    viewA: "Some people think working from home raises productivity.",
    viewB: "Others think offices are necessary for teamwork and learning.",
    adv: "working from home for most of the week",
    problem: "Companies are unsure how to manage staff who rarely meet.",
    why: "Why do some employees prefer working from home?",
    what: "How can companies keep teamwork if staff are remote?",
    ideas: ["Bớt thời gian đi đường", "Việc cần kèm cặp thì khó khi ở xa", "Lịch lai một vài ngày ở văn phòng"],
  },
  {
    id: "transport",
    module: "academic",
    keywords: ["transport", "roads", "traffic", "public", "cities"],
    opinion: "Governments should spend more on public transport than on building new roads.",
    viewA: "Some people want more roads to reduce traffic jams.",
    viewB: "Others want the money spent on buses and trains instead.",
    adv: "investing mainly in public transport",
    problem: "Traffic congestion wastes time in many cities.",
    why: "Why do cities keep building new roads even when they fill up quickly?",
    what: "What should governments do to move people more efficiently?",
    ideas: ["Đường mới thường đầy xe rất nhanh", "Xe buýt và tàu chở được nhiều người hơn", "Người dân chỉ bỏ xe máy khi chuyến công cộng đúng giờ"],
  },
  {
    id: "plastic",
    module: "both",
    keywords: ["plastic", "ban", "waste", "environment", "shops"],
    opinion: "Single-use plastic should be banned in all shops.",
    viewA: "Some people support a total ban on single-use plastic.",
    viewB: "Others think a ban would hurt small shops and some disabled customers.",
    adv: "banning single-use plastic in shops",
    problem: "Plastic waste is blocking drains and rivers.",
    why: "Why is single-use plastic still so common?",
    what: "What can shops and customers do to reduce it?",
    ideas: ["Nhựa dùng một lần rẻ và tiện", "Lệnh cấm cần phương án cho người không tự mang túi", "Phí túi vải thường hiệu quả hơn khẩu hiệu"],
  },
  {
    id: "zoos",
    module: "both",
    keywords: ["zoos", "animals", "wildlife", "conservation"],
    opinion: "Zoos are no longer acceptable in the modern world.",
    viewA: "Some people think zoos protect endangered animals.",
    viewB: "Others think it is cruel to keep wild animals in enclosures.",
    adv: "keeping wild animals in zoos",
    problem: "Some animal species are disappearing from the wild.",
    why: "Why do zoos remain popular?",
    what: "Are there better ways to protect endangered species?",
    ideas: ["Chuồng nuôi có thể cứu giống quý khi rừng mất", "Động vật mất hành vi tự nhiên", "Bảo vệ nơi sống quan trọng hơn làm cảnh"],
  },
  {
    id: "adverts",
    module: "both",
    keywords: ["advertising", "children", "parents", "media"],
    opinion: "Advertising aimed at children should be banned.",
    viewA: "Some people think adverts help children learn about new products.",
    viewB: "Others think children cannot judge adverts and should be protected.",
    adv: "allowing companies to advertise directly to children",
    problem: "Children put pressure on parents to buy advertised products.",
    why: "Why do companies target children?",
    what: "How should governments regulate this advertising?",
    ideas: ["Trẻ chưa phân biệt được quảng cáo và thông tin", "Phụ huynh vẫn là người trả tiền", "Cấm ở giờ thiếu nhi khả thi hơn cấm tuyệt đối"],
  },
  {
    id: "gapyear",
    module: "both",
    keywords: ["gap", "year", "students", "travel", "work"],
    opinion: "Students should take a gap year before university.",
    viewA: "Some people think a gap year makes students more mature.",
    viewB: "Others think it delays study and is a waste of time.",
    adv: "taking a year off before university",
    problem: "Many first-year students drop out because they chose the wrong course.",
    why: "Why do some students feel lost when they start university?",
    what: "Would a structured gap year help, and how?",
    ideas: ["Một năm có việc hoặc tình nguyện giúp biết mình muốn gì", "Năm trống không kế hoạch dễ trôi", "Đi học ngay cũng không sai nếu đã chọn đúng ngành"],
  },
  {
    id: "museums",
    module: "academic",
    keywords: ["museums", "free", "culture", "visitors", "government"],
    opinion: "Museums should be free for everyone.",
    viewA: "Some people think free entry lets more citizens learn.",
    viewB: "Others think visitors should pay so museums can protect their collections.",
    adv: "making museum entry free",
    problem: "Some local museums are closing because they cannot cover their costs.",
    why: "Why is it difficult for museums to stay open?",
    what: "Who should pay for museums?",
    ideas: ["Vé miễn phí tăng lượng khách nhưng giảm doanh thu", "Nhà nước có thể trợ giá cho học sinh", "Phí với khách du lịch, miễn với người địa phương"],
  },
  {
    id: "ai",
    module: "academic",
    keywords: ["artificial", "intelligence", "schools", "students", "teachers"],
    opinion: "Artificial intelligence should be used for most teaching in schools.",
    viewA: "Some people think AI can give every pupil instant feedback.",
    viewB: "Others think a teacher’s judgement cannot be replaced.",
    adv: "using artificial intelligence as the main teacher",
    problem: "Teachers spend too much time marking and too little time talking to pupils.",
    why: "Why are schools experimenting with artificial intelligence?",
    what: "What limits should schools set?",
    ideas: ["Máy chấm nhanh bài trắc nghiệm", "Máy không thấy học sinh đang buồn hay bị bắt nạt", "Dùng máy để chấm vặt, giáo viên giữ việc nói chuyện"],
  },
  {
    id: "ageing",
    module: "academic",
    keywords: ["ageing", "elderly", "population", "care", "workers"],
    opinion: "The retirement age should be raised because people now live longer.",
    viewA: "Some people think older workers should stay in jobs longer.",
    viewB: "Others think physically hard jobs cannot be extended safely.",
    adv: "raising the official retirement age",
    problem: "There are not enough care workers for an ageing population.",
    why: "Why is an ageing population expensive for a country?",
    what: "What can governments do, apart from raising the retirement age?",
    ideas: ["Người khoẻ có thể làm việc lâu hơn", "Nghề chân tay không chịu thêm năm như nhau", "Tăng lương điều dưỡng và nhận lao động di cư có kiểm tra"],
  },
  {
    id: "fashion",
    module: "both",
    keywords: ["fashion", "clothes", "waste", "consumers"],
    opinion: "Fast fashion does more harm than good.",
    viewA: "Some people enjoy cheap clothes that follow new trends.",
    viewB: "Others blame fast fashion for waste and poor working conditions.",
    adv: "buying cheap fashionable clothes several times a year",
    problem: "Unwanted clothes are piling up in landfill.",
    why: "Why do people buy clothes they rarely wear?",
    what: "What should shoppers and brands do?",
    ideas: ["Giá rẻ khiến quần áo thành đồ dùng một mùa", "Công nhân may chịu áp lực đơn hàng gấp", "Mua ít, sửa, và cửa hàng nhận lại đồ cũ"],
  },
  {
    id: "homework",
    module: "both",
    keywords: ["homework", "children", "school", "parents", "teachers"],
    opinion: "Children should not be given homework until secondary school.",
    viewA: "Some people think homework builds independent study habits.",
    viewB: "Others think primary pupils need rest and play after school.",
    adv: "giving homework to primary-school children",
    problem: "Many children are exhausted by evening study.",
    why: "Why do primary schools set homework?",
    what: "How much homework, if any, is reasonable?",
    ideas: ["Một ít bài giúp phụ huynh thấy con đang học gì", "Bài quá nhiều cướp giờ ngủ", "Đọc chung với gia đình có ích hơn bài chép"],
  },
  {
    id: "language",
    module: "both",
    keywords: ["language", "primary", "children", "english", "school"],
    opinion: "A foreign language should be compulsory in primary school.",
    viewA: "Some people think young children learn pronunciation more easily.",
    viewB: "Others think primary pupils should master their first language first.",
    adv: "teaching a foreign language from the first years of primary school",
    problem: "Many secondary students still cannot hold a simple conversation in a foreign language.",
    why: "Why do language lessons at school often fail?",
    what: "What would make early language teaching useful?",
    ideas: ["Trẻ bắt chước âm tốt hơn người lớn", "Giáo viên tiểu học không phải ai cũng đủ ngữ âm", "Lớp nhỏ và nói nhiều quan trọng hơn ngữ pháp sớm"],
  },
  {
    id: "tourism",
    module: "general",
    keywords: ["tourism", "hometown", "visitors", "local", "jobs"],
    opinion: "Tourism does more harm than good in small towns.",
    viewA: "Some people think visitors bring jobs and pride to a town.",
    viewB: "Others think rents rise and daily life becomes a performance.",
    adv: "encouraging more tourists to visit small towns",
    problem: "Some hometowns become too expensive for the people who grew up there.",
    why: "Why can tourism hurt the people who live in a place all year?",
    what: "How can a town welcome visitors without losing itself?",
    ideas: ["Việc làm theo mùa không phải việc làm ổn định", "Giá nhà bị khách thuê ngắn ngày đẩy lên", "Giới hạn số phòng và giữ chợ cho người địa phương"],
  },
  {
    id: "shops",
    module: "general",
    keywords: ["shops", "online", "local", "shopping", "community"],
    opinion: "Online shopping is destroying local shops, and that is a serious loss.",
    viewA: "Some people think online shopping saves time and money.",
    viewB: "Others think empty high streets damage community life.",
    adv: "doing most of your shopping online",
    problem: "Many neighbourhood shops are closing.",
    why: "Why do people stop visiting local shops?",
    what: "What can towns do to keep useful shops open?",
    ideas: ["Mua mạng rẻ và giao tận nhà", "Mất chỗ hỏi han và sửa đồ gần nhà", "Phố đi bộ và thuế cửa hàng trống có thể giúp"],
  },
  {
    id: "noise",
    module: "general",
    keywords: ["neighbours", "noise", "housing", "community"],
    opinion: "People who live in flats should accept noise from their neighbours.",
    viewA: "Some people think city life is noisy and complaints are unreasonable.",
    viewB: "Others think everyone has a right to sleep and to quiet study.",
    adv: "living in a crowded block of flats",
    problem: "Arguments between neighbours about noise are becoming more common.",
    why: "Why is noise such a common cause of conflict in cities?",
    what: "What rules would be fair?",
    ideas: ["Tường mỏng biến sinh hoạt thường thành ồn", "Giờ yên tĩnh sau 10 giờ đêm dễ thống nhất", "Nói chuyện trực tiếp trước khi gọi bảo vệ"],
  },
  {
    id: "sport",
    module: "general",
    keywords: ["sport", "community", "health", "clubs", "young"],
    opinion: "Local sports clubs do more for a community than large professional stadiums.",
    viewA: "Some people think a famous team makes a city proud.",
    viewB: "Others think amateur clubs keep more people active.",
    adv: "spending public money on a large stadium",
    problem: "Fewer teenagers are playing sport outside school.",
    why: "Why are local clubs more useful than a stadium for daily life?",
    what: "How can towns get more young people playing?",
    ideas: ["Sân nhỏ gần nhà dễ đến hơn sân vận động", "Một đội nổi tiếng chủ yếu bán vé và truyền hình", "Giảm phí câu lạc bộ và mở sân buổi tối"],
  },
];

const LETTERS: {
  tone: "letter-formal" | "letter-semi" | "letter-informal";
  title: string;
  prompt: string;
  keywords: string[];
  bullets: { text: string; keys: string[] }[];
  ideas: string[];
}[] = [
  {
    tone: "letter-formal",
    title: "Hành lý thất lạc",
    keywords: ["luggage", "flight", "airline", "compensation"],
    prompt:
      "You recently flew to another city. Your luggage did not arrive. Write a letter to the airline manager. In your letter:\n- describe the flight and when you noticed the problem\n- explain what was in the luggage and why you need it\n- say what you want the airline to do",
    bullets: [
      { text: "Chuyến bay và lúc phát hiện mất đồ", keys: ["flight", "airport", "arrive", "landed"] },
      { text: "Đồ bên trong và vì sao cần", keys: ["clothes", "medicine", "laptop", "documents", "gift", "suitcase"] },
      { text: "Yêu cầu cụ thể", keys: ["compensation", "deliver", "refund", "replace", "contact"] },
    ],
    ideas: ["Dear Sir or Madam", "Yours faithfully", "Không viết tắt"],
  },
  {
    tone: "letter-formal",
    title: "Khiếu nại khoá học tối",
    keywords: ["course", "manager", "timetable", "refund"],
    prompt:
      "You paid for an evening course, but several classes were cancelled. Write to the centre manager.\n- explain which course you joined\n- describe the problems\n- say what you want the centre to do",
    bullets: [
      { text: "Tên khoá và lý do ghi danh", keys: ["course", "class", "evening", "enrolled"] },
      { text: "Buổi bị huỷ hoặc giáo viên vắng", keys: ["cancelled", "absent", "teacher", "problem"] },
      { text: "Học bù hoặc hoàn tiền", keys: ["refund", "replace", "continue", "timetable"] },
    ],
    ideas: ["Giọng bình tĩnh, có ngày tháng", "Một yêu cầu rõ, không đe doạ"],
  },
  {
    tone: "letter-semi",
    title: "Nhờ hàng xóm trông cây",
    keywords: ["neighbour", "plants", "holiday", "key"],
    prompt:
      "You are going away for two weeks. Write to your neighbour.\n- say when you will be away\n- ask them to look after your plants\n- offer to return the favour",
    bullets: [
      { text: "Thời gian vắng nhà", keys: ["weeks", "holiday", "away", "leave", "return"] },
      { text: "Việc tưới cây", keys: ["plants", "water", "flowers", "garden"] },
      { text: "Đáp lại", keys: ["help", "return", "favour", "thank"] },
    ],
    ideas: ["Dear + tên", "Kind regards", "Chỉ dẫn ngắn, đừng viết thành nhật ký"],
  },
  {
    tone: "letter-semi",
    title: "Xin thầy dời buổi thuyết trình",
    keywords: ["teacher", "presentation", "date", "reason"],
    prompt:
      "You cannot give your class presentation on the planned day. Write to your teacher.\n- remind them of the original date\n- explain why you cannot attend\n- suggest another time",
    bullets: [
      { text: "Ngày cũ", keys: ["presentation", "date", "monday", "tuesday", "wednesday", "thursday", "friday", "class"] },
      { text: "Lý do", keys: ["ill", "hospital", "family", "interview", "clash"] },
      { text: "Ngày mới", keys: ["suggest", "next", "reschedule", "available"] },
    ],
    ideas: ["Biết tên người nhận nên dùng sincerely", "Đừng kể dài bệnh sử"],
  },
  {
    tone: "letter-informal",
    title: "Rủ bạn đi lễ hội",
    keywords: ["friend", "festival", "visit", "stay"],
    prompt:
      "A festival is happening in your city. Write to a friend and invite them to stay with you.\n- describe the festival\n- explain what you can do together\n- give practical details about the visit",
    bullets: [
      { text: "Lễ hội là gì", keys: ["festival", "music", "food", "parade", "street"] },
      { text: "Hoạt động chung", keys: ["together", "watch", "try", "walk"] },
      { text: "Ở lại và giờ tàu", keys: ["stay", "room", "train", "bus", "ticket", "weekend"] },
    ],
    ideas: ["Dear + tên", "Được viết tắt", "Best wishes hoặc Love, không dùng faithfully"],
  },
  {
    tone: "letter-informal",
    title: "Cảm ơn kỳ nghỉ ở nhà bạn",
    keywords: ["thank", "stay", "friend", "photos"],
    prompt:
      "You recently stayed at a friend’s house. Write to thank them.\n- say what you enjoyed\n- mention something you are sending them\n- invite them to visit you",
    bullets: [
      { text: "Kỷ niệm thích", keys: ["enjoyed", "food", "walk", "family", "beach", "city"] },
      { text: "Món đang gửi", keys: ["send", "photos", "gift", "book"] },
      { text: "Lời mời đáp lại", keys: ["visit", "invite", "come", "stay"] },
    ],
    ideas: ["Mở bằng lời cảm ơn, đừng giải thích đề", "Một chi tiết cụ thể đáng tin hơn ba tính từ"],
  },
];

function jitter(n: number, seed: number, i: number) {
  const d = ((seed * 17 + i * 13) % 7) - 3;
  return Math.max(2, n + d);
}

function barChart(seed: number): ChartModel {
  const years = ["2018", "2020", "2022", "2024"];
  const baseA = [22, 28, 35, 41];
  const baseB = [40, 36, 30, 24];
  const baseC = [15, 18, 19, 21];
  return {
    kind: "bar",
    title: "Thư viện thành phố: lượt mượn sách mỗi năm (nghìn)",
    unit: "nghìn lượt",
    series: [
      { name: "Chi nhánh Trung tâm", points: years.map((x, i) => ({ x, y: jitter(baseA[i], seed, i) })) },
      { name: "Chi nhánh Sông", points: years.map((x, i) => ({ x, y: jitter(baseB[i], seed, i + 4) })) },
      { name: "Chi nhánh Đồi", points: years.map((x, i) => ({ x, y: jitter(baseC[i], seed, i + 8) })) },
    ],
  };
}

function lineChart(seed: number): ChartModel {
  const years = ["2015", "2017", "2019", "2021", "2023"];
  const a = [30, 42, 48, 61, 74];
  const b = [55, 53, 49, 44, 38];
  return {
    kind: "line",
    title: "Hành khách metro mỗi ngày (nghìn) ở hai thành phố",
    unit: "nghìn người",
    series: [
      { name: "Hải Đăng", points: years.map((x, i) => ({ x, y: jitter(a[i], seed, i) })) },
      { name: "An Bình", points: years.map((x, i) => ({ x, y: jitter(b[i], seed, i + 5) })) },
    ],
  };
}

function pieChart(seed: number): ChartModel {
  const base = [
    { name: "Tắm và vòi", y: 34 },
    { name: "Giặt", y: 22 },
    { name: "Nấu ăn", y: 18 },
    { name: "Tưới cây", y: 16 },
    { name: "Khác", y: 10 },
  ];
  const slices = base.map((s, i) => ({ ...s, y: jitter(s.y, seed, i) }));
  const sum = slices.reduce((a, s) => a + s.y, 0);
  const fixed = slices.map((s) => ({ ...s, y: Math.round((s.y / sum) * 100) }));
  const drift = 100 - fixed.reduce((a, s) => a + s.y, 0);
  fixed[0].y += drift;
  return { kind: "pie", title: "Một hộ gia đình dùng nước máy vào việc gì (%)", unit: "%", slices: fixed };
}

function tableChart(seed: number): ChartModel {
  const ages = ["18–24", "25–34", "35–49", "50+"];
  const online = [62, 48, 31, 18].map((n, i) => String(jitter(n, seed, i)));
  const campus = [21, 33, 40, 28].map((n, i) => String(jitter(n, seed, i + 3)));
  return {
    kind: "table",
    title: "Người lớn đang học một khoá: tỷ lệ theo hình thức (%)",
    unit: "%",
    headers: ["Độ tuổi", "Học online", "Học tại lớp"],
    rows: ages.map((age, i) => [age, online[i], campus[i]]),
  };
}

function mixedChart(seed: number): ChartModel {
  const years = ["2016", "2018", "2020", "2022", "2024"];
  return {
    kind: "mixed",
    title: "Cà phê xuất khẩu của một vùng: sản lượng và giá",
    barUnit: "nghìn tấn",
    lineUnit: "USD / kg",
    bars: { name: "Sản lượng", points: years.map((x, i) => ({ x, y: jitter([40, 46, 44, 58, 63][i], seed, i) })) },
    line: { name: "Giá", points: years.map((x, i) => ({ x, y: jitter([6, 5, 7, 5, 4][i], seed, i + 6) })) },
  };
}

const PROCESSES = [
  {
    title: "Quy trình tái chế chai thuỷ tinh",
    prompt:
      "The diagram shows how glass bottles are recycled.\n\nSummarise the information by selecting and reporting the main features, and make comparisons where relevant.\n\nWrite at least 150 words.",
    steps: [
      "Thu vỏ chai thuỷ tinh từ thùng tái chế",
      "Phân loại theo màu tại nhà máy",
      "Rửa và nghiền thành mảnh nhỏ",
      "Nung chảy trong lò",
      "Đổ vào khuôn chai mới",
      "Làm nguội, kiểm tra và đưa lại cho hãng nước",
    ],
    ideas: ["Sáu bước, từ thùng rác đến chai mới", "Dùng bị động", "Không bình luận tốt xấu"],
  },
  {
    title: "Quy trình đóng trà túi lọc",
    prompt:
      "The diagram shows how tea bags are produced.\n\nSummarise the information by selecting and reporting the main features, and make comparisons where relevant.\n\nWrite at least 150 words.",
    steps: [
      "Hái lá và phơi héo trong nhà kho",
      "Cắt lá thành mảnh nhỏ",
      "Ủ lá đen hoặc giữ lá xanh không ủ",
      "Sấy cho đến khi lá giòn",
      "Đong vào túi giấy rồi cho vào hộp",
      "Kiểm tra trọng lượng và gửi tới cửa hàng",
    ],
    ideas: ["Bắt đầu ở vườn, kết thúc ở hộp", "Một nhánh được ủ, một nhánh không", "Không khen thương hiệu"],
  },
];

const MAP_SETS = [
  {
    title: "Công viên bờ sông năm 2005 và hiện tại",
    prompt:
      "The notes below describe a riverside park in 2005 and the same park now.\n\nSummarise the information by selecting and reporting the main features, and make comparisons where relevant.\n\nWrite at least 150 words.",
    changes: [
      {
        when: "Năm 2005",
        points: ["Bãi đất trống ở phía bắc", "Một con đường đất cắt ngang công viên", "Hồ nhỏ ở góc đông", "Không có quán cà phê"],
      },
      {
        when: "Hiện tại",
        points: ["Bãi đất trở thành sân chơi trẻ em", "Đường đất được thay bằng lối đi bộ", "Hồ được nới rộng và có cầu gỗ", "Quán cà phê xây cạnh cổng nam"],
      },
    ],
    ideas: ["Phía bắc đổi nhiều nhất", "Đường đất thành lối đi", "Thêm quán và cầu"],
  },
  {
    title: "Sân trường năm 2010 và hiện tại",
    prompt:
      "The notes below describe a school yard in 2010 and the same yard now.\n\nSummarise the information by selecting and reporting the main features, and make comparisons where relevant.\n\nWrite at least 150 words.",
    changes: [
      {
        when: "Năm 2010",
        points: ["Bãi cỏ ở phía tây", "Một dãy xe đạp không có mái", "Căng tin nhỏ cạnh cổng bắc", "Không có vườn rau"],
      },
      {
        when: "Hiện tại",
        points: ["Bãi cỏ thành sân bóng rổ", "Chỗ xe đạp có mái và nằm phía đông", "Căng tin được mở rộng", "Vườn rau chiếm góc nam"],
      },
    ],
    ideas: ["Phía tây mất bãi cỏ", "Chỗ xe đạp đổi hướng", "Thêm vườn, căng tin to hơn"],
  },
];

function fits(topic: Topic, module: Module) {
  return topic.module === "both" || topic.module === module;
}

export function generateWriting(type: WritingType, module: Module, seed: number): WritingTask {
  if (type.startsWith("letter")) {
    const pool = LETTERS.filter((l) => l.tone === type);
    const item = pool[seed % pool.length];
    return {
      id: `${type}-${seed}`,
      module: "general",
      type,
      title: item.title,
      prompt: `You should spend about 20 minutes on this task.\n\n${item.prompt}\n\nWrite at least 150 words.`,
      minWords: 150,
      minutes: 20,
      keywords: item.keywords,
      bullets: item.bullets,
      ideas: item.ideas,
    };
  }
  if (["bar", "line", "pie", "table-chart", "mixed", "process", "map-change"].includes(type)) {
    const pickedProcess = PROCESSES[seed % PROCESSES.length];
    const pickedMap = MAP_SETS[seed % MAP_SETS.length];
    const chart =
      type === "bar" ? barChart(seed) : type === "line" ? lineChart(seed) : type === "pie" ? pieChart(seed) : type === "table-chart" ? tableChart(seed) : type === "mixed" ? mixedChart(seed) : undefined;
    const title =
      chart && "title" in chart ? chart.title : type === "process" ? pickedProcess.title : pickedMap.title;
    return {
      id: `${type}-${seed}`,
      module: "academic",
      type,
      title,
      prompt:
        type === "process"
          ? pickedProcess.prompt
          : type === "map-change"
            ? pickedMap.prompt
            : "The chart below shows information about a town.\n\nSummarise the information by selecting and reporting the main features, and make comparisons where relevant.\n\nWrite at least 150 words.",
      minWords: 150,
      minutes: 20,
      keywords: ["overall", "increase", "decrease", "percent", "while"],
      chart,
      process: type === "process" ? pickedProcess.steps : undefined,
      changes: type === "map-change" ? pickedMap.changes : undefined,
      ideas:
        type === "process"
          ? pickedProcess.ideas
          : type === "map-change"
            ? pickedMap.ideas
            : ["Nhóm cái đang tăng với cái đang giảm", "Chọn đỉnh và điểm cắt", "Một câu overview không có số vụn"],
    };
  }
  const pool = TOPICS.filter((t) => fits(t, module));
  const topic = pool[seed % pool.length];
  const stem =
    type === "opinion"
      ? `${topic.opinion}\n\nTo what extent do you agree or disagree?`
      : type === "discussion"
        ? `${topic.viewA} ${topic.viewB}\n\nDiscuss both these views and give your own opinion.`
        : type === "adv"
          ? `Do the advantages of ${topic.adv} outweigh the disadvantages?`
          : type === "problem"
            ? `${topic.problem}\n\nWhat are the causes of this problem, and what solutions can you suggest?`
            : `${topic.why}\n${topic.what}`;
  return {
    id: `${type}-${topic.id}-${seed}`,
    module,
    type,
    title: topic.opinion.slice(0, 72),
    prompt: `You should spend about 40 minutes on this task.\n\nWrite about the following topic:\n\n${stem}\n\nGive reasons for your answer and include any relevant examples from your own knowledge or experience.\n\nWrite at least 250 words.`,
    minWords: 250,
    minutes: 40,
    keywords: topic.keywords,
    ideas: topic.ideas,
  };
}

const PART1 = [
  {
    topic: "Work or study",
    lines: ["Do you work or are you a student?", "What do you enjoy about it?", "What is difficult about it?", "Would you like to change anything?"],
  },
  {
    topic: "Your hometown",
    lines: ["Where is your hometown?", "What do visitors usually do there?", "Has it changed in recent years?", "Would you like to live there in the future?"],
  },
  {
    topic: "Food",
    lines: ["What do you usually eat for breakfast?", "Who cooks in your home?", "Do you prefer eating out or eating at home?", "Is there a dish you would like to learn?"],
  },
  {
    topic: "Phones",
    lines: ["How often do you use your phone?", "What do you use it for most?", "Do you think you use it too much?", "At what age should a child have a phone?"],
  },
  {
    topic: "Walking",
    lines: ["Do you like walking?", "Where do you walk in your city?", "Did you walk more when you were a child?", "Is walking popular where you live?"],
  },
  {
    topic: "Music",
    lines: ["What kind of music do you like?", "When do you listen to music?", "Have your tastes changed?", "Do you prefer live music or recordings?"],
  },
];

const CARDS = [
  ["a cafe you like working in", "cà phê", ["Why do people pay to sit in cafes when they could stay at home?", "Do quiet public places matter in a city?", "Will cafes disappear because of delivery apps?"]],
  ["a difficult decision that turned out well", "quyết định", ["How do families in your country make big decisions?", "Do young people take more risks than their parents?", "Is it better to decide quickly or to wait?"]],
  ["a skill you learned outside school", "kỹ năng", ["Should schools teach practical skills?", "Who is the best person to teach a skill, a relative or a professional?", "Are free online lessons enough?"]],
  ["a place in your city that has become crowded", "nơi đông", ["Why do some public places become too popular?", "Should cities limit visitor numbers?", "How can residents still enjoy their own city?"]],
  ["a book or film that changed your mind", "sách hoặc phim", ["Do stories change how people behave?", "Are films more powerful than books?", "Should schools choose what teenagers watch?"]],
  ["an older person you admire", "người lớn tuổi", ["What can younger people learn from older relatives?", "Are the elderly respected in your country?", "Should adult children live with their parents?"]],
  ["a journey that took longer than planned", "chuyến đi", ["Why are delays so stressful?", "Is public transport reliable where you live?", "Would you rather travel slowly and cheaply, or quickly and expensively?"]],
  ["a local shop you would miss if it closed", "cửa hàng", ["Why do small shops close?", "Should towns protect them?", "Do you enjoy shopping, or do you only buy what you need?"]],
  ["a time you helped a neighbour", "hàng xóm", ["Do people know their neighbours today?", "Is it the government’s job or the neighbours’ job to look after a street?", "Can apps replace real favours?"]],
  ["a festival you enjoyed", "lễ hội", ["Why are festivals important?", "Do they become too commercial?", "Should festivals stay traditional or change with young people?"]],
  ["a piece of technology you waited to buy", "công nghệ", ["Why do people queue for new devices?", "Does advertising create needs?", "Is the newest product usually worth the money?"]],
  ["a park or river you like", "công viên", ["Do cities spend enough on green space?", "Who should pay to keep a park clean?", "Is a small park more useful than a large stadium?"]],
];

function card(seed: number): [string, string, string[]] {
  const row = CARDS[seed % CARDS.length];
  return [row[0] as string, row[1] as string, row[2] as string[]];
}

export function generateSpeaking(type: SpeakingTask["type"], seed: number): SpeakingTask {
  const p1 = PART1[seed % PART1.length];
  const [cue, vi, part3] = card(seed);
  const part1Block = { name: "Part 1", minutes: 5, lines: p1.lines.map((l) => `${p1.topic}: ${l}`) };
  const part2Block = {
    name: "Part 2",
    minutes: 3,
    prep: 60,
    speak: 120,
    lines: [
      `Describe ${cue}.`,
      "You should say:",
      "what it is or who was involved",
      "when it happened or when you go there",
      "what you did",
      "and explain why it stays in your memory.",
    ],
  };
  const part3Block = { name: "Part 3", minutes: 5, lines: part3 };
  const parts =
    type === "part1" ? [part1Block] : type === "part2" ? [part2Block] : type === "part3" ? [part3Block] : [part1Block, part2Block, part3Block];
  return {
    id: `${type}-${seed}`,
    type,
    title: type === "part1" ? p1.topic : type === "part3" ? `Thảo luận: ${vi}` : `Cue card: ${vi}`,
    minutes: type === "speaking-full" ? 14 : type === "part2" ? 4 : 5,
    parts,
    keywords: String(cue).split(" ").filter((w) => w.length > 3),
  };
}

export const WRITING_TYPES: WritingType[] = [
  "opinion",
  "discussion",
  "adv",
  "problem",
  "twopart",
  "bar",
  "line",
  "pie",
  "table-chart",
  "mixed",
  "process",
  "map-change",
  "letter-formal",
  "letter-semi",
  "letter-informal",
];

export function writingTypesFor(module: Module): WritingType[] {
  return WRITING_TYPES.filter((t) => (module === "academic" ? !t.startsWith("letter") : t.startsWith("letter") || ["opinion", "discussion", "adv", "problem", "twopart"].includes(t)));
}
