/** Public-style raw-score thresholds. Real IELTS forms shift by about half a band.
 *  These are study references, not a promise of an official result.
 */

export type BandRow = { min: number; band: number };

export const LISTENING_40: BandRow[] = [
  { min: 39, band: 9 },
  { min: 37, band: 8.5 },
  { min: 35, band: 8 },
  { min: 32, band: 7.5 },
  { min: 30, band: 7 },
  { min: 26, band: 6.5 },
  { min: 23, band: 6 },
  { min: 18, band: 5.5 },
  { min: 16, band: 5 },
  { min: 13, band: 4.5 },
  { min: 11, band: 4 },
  { min: 8, band: 3.5 },
  { min: 6, band: 3 },
  { min: 4, band: 2.5 },
  { min: 2, band: 2 },
  { min: 1, band: 1 },
  { min: 0, band: 0 },
];

export const READING_AC_40: BandRow[] = [
  { min: 39, band: 9 },
  { min: 37, band: 8.5 },
  { min: 35, band: 8 },
  { min: 33, band: 7.5 },
  { min: 30, band: 7 },
  { min: 27, band: 6.5 },
  { min: 23, band: 6 },
  { min: 19, band: 5.5 },
  { min: 15, band: 5 },
  { min: 13, band: 4.5 },
  { min: 10, band: 4 },
  { min: 8, band: 3.5 },
  { min: 6, band: 3 },
  { min: 4, band: 2.5 },
  { min: 2, band: 2 },
  { min: 1, band: 1 },
  { min: 0, band: 0 },
];

export const READING_GT_40: BandRow[] = [
  { min: 40, band: 9 },
  { min: 39, band: 8.5 },
  { min: 37, band: 8 },
  { min: 36, band: 7.5 },
  { min: 34, band: 7 },
  { min: 32, band: 6.5 },
  { min: 30, band: 6 },
  { min: 27, band: 5.5 },
  { min: 23, band: 5 },
  { min: 19, band: 4.5 },
  { min: 15, band: 4 },
  { min: 12, band: 3.5 },
  { min: 9, band: 3 },
  { min: 6, band: 2.5 },
  { min: 4, band: 2 },
  { min: 1, band: 1 },
  { min: 0, band: 0 },
];

export function bandFromRaw40(raw: number, table: BandRow[]): number {
  const r = Math.max(0, Math.min(40, raw));
  for (const row of table) if (r + 1e-9 >= row.min) return row.band;
  return 0;
}

export function estimateRatio(correct: number, total: number, table: BandRow[]) {
  if (total <= 0) return { band: 0, raw40: 0 };
  const raw40 = (correct / total) * 40;
  return { band: bandFromRaw40(raw40, table), raw40 };
}

export function roundHalf(n: number): number {
  return Math.max(0, Math.min(9, Math.round(n * 2) / 2));
}

export function formatBand(n: number): string {
  return n.toFixed(1);
}
