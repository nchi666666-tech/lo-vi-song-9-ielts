import { roundHalf } from "./bands";
import type { CriterionScore, WritingTask } from "./types";
import { wordList } from "./grade";

const LINKERS = [
  "however",
  "moreover",
  "furthermore",
  "therefore",
  "meanwhile",
  "whereas",
  "although",
  "though",
  "while",
  "because",
  "since",
  "unless",
  "despite",
  "nevertheless",
  "consequently",
  "instead",
  "finally",
  "overall",
  "firstly",
  "secondly",
  "additionally",
];

const AWL = new Set([
  "achieve",
  "adequate",
  "analyse",
  "analyze",
  "approach",
  "appropriate",
  "area",
  "assess",
  "assume",
  "authority",
  "available",
  "benefit",
  "concept",
  "consistent",
  "constitute",
  "context",
  "contrast",
  "contribute",
  "create",
  "data",
  "define",
  "derive",
  "distribute",
  "economy",
  "environment",
  "establish",
  "estimate",
  "evaluate",
  "evidence",
  "export",
  "factor",
  "finance",
  "function",
  "identify",
  "income",
  "indicate",
  "individual",
  "interpret",
  "involve",
  "issue",
  "labour",
  "labor",
  "legal",
  "locate",
  "maintain",
  "major",
  "method",
  "occur",
  "percent",
  "period",
  "policy",
  "principle",
  "proceed",
  "process",
  "require",
  "research",
  "respond",
  "role",
  "section",
  "significant",
  "similar",
  "source",
  "specific",
  "structure",
  "theory",
  "vary",
]);

const SLIPS: { re: RegExp; label: string }[] = [
  { re: /\binformations\b/i, label: "information không có dạng số nhiều" },
  { re: /\bequipments\b/i, label: "equipment là danh từ không đếm được" },
  { re: /\badvices\b/i, label: "advice không thêm -s" },
  { re: /\bfurnitures\b/i, label: "furniture không thêm -s" },
  { re: /\bmore easier\b/i, label: "không dùng more + dạng so sánh -er" },
  { re: /\bmore better\b/i, label: "better đã là so sánh hơn" },
  { re: /\bdiscuss about\b/i, label: "discuss không đi với about" },
  { re: /\bmention about\b/i, label: "mention không đi với about" },
  { re: /\breturn back\b/i, label: "return đã có nghĩa quay lại" },
  { re: /\bin the other hand\b/i, label: "cụm đúng là on the other hand" },
  { re: /\baccording to me\b/i, label: "không nói according to me" },
  { re: /\bdespite of\b/i, label: "despite không đi với of" },
  { re: /\balthough but\b/i, label: "although và but không đi cùng" },
  { re: /\bevery countries\b/i, label: "every + danh từ số ít" },
  { re: /\bchildrens\b/i, label: "dạng số nhiều là children" },
  { re: /\bpeople is\b/i, label: "people đi với động từ số nhiều" },
  { re: /\bthey was\b/i, label: "they đi với were" },
  { re: /\b(he|she|it) go\b/i, label: "ngôi thứ ba số ít: goes" },
  { re: /\ba hour\b/i, label: "hour bắt đầu bằng âm /aʊ/ nên dùng an" },
  { re: /\blisten music\b/i, label: "listen to music" },
  { re: /\bdepend of\b/i, label: "depend on" },
  { re: /\bmarried with\b/i, label: "married to" },
];

const STOP = new Set(
  "the a an of to and or in on for with that this these those from by as at is are was were be been being it its their his her they we you i not no about into over after before than then so if but".split(
    " ",
  ),
);

function sentences(text: string): string[] {
  return text
    .split(/[.!?]+/)
    .map((s) => s.trim())
    .filter((s) => s.length > 0);
}

function paragraphs(text: string): string[] {
  const blocks = text
    .split(/\n\s*\n/)
    .map((s) => s.trim())
    .filter(Boolean);
  return blocks.length ? blocks : text.trim() ? [text.trim()] : [];
}

function contentWords(text: string): string[] {
  return (text.toLowerCase().match(/[a-z']+/g) ?? []).filter((w) => w.length > 3 && !STOP.has(w));
}

function clamp(n: number, lo: number, hi: number) {
  return Math.max(lo, Math.min(hi, n));
}

function copiedChunk(essay: string, prompt: string): boolean {
  const e = essay.toLowerCase().replace(/\s+/g, " ");
  const words = prompt.toLowerCase().replace(/[^a-z\s]/g, " ").split(/\s+/).filter((w) => w.length > 2);
  for (let i = 0; i < words.length - 10; i++) {
    const slice = words.slice(i, i + 11).join(" ");
    if (slice.length > 40 && e.includes(slice)) return true;
  }
  return false;
}

export function scoreWriting(task: WritingTask, essay: string): { criteria: CriterionScore[]; notes: string[]; band: number } {
  const text = essay.trim();
  const words = wordList(text);
  const wc = text ? words.length : 0;
  const notes: string[] = [];
  const slips = SLIPS.filter((s) => s.re.test(text)).map((s) => s.label);
  const sents = sentences(text);
  const paras = paragraphs(text);
  const lower = text.toLowerCase();

  if (wc <= 20) {
    notes.push("Dưới hoặc bằng 20 từ: public descriptor xếp mức này ở Band 1, trừ khi chỉ chép đề.");
    const criteria = ["Task", "Coherence", "Lexical", "Grammar"].map((label, i) => ({
      key: ["tr", "cc", "lr", "gra"][i],
      label,
      band: copiedChunk(text, task.prompt) || wc === 0 ? 1 : 1,
      note: "Không đủ ngôn ngữ để chấm các tiêu chí phía trên.",
    }));
    return { criteria, notes, band: 1 };
  }

  const promptWords = new Set(contentWords(task.prompt));
  const essayWords = contentWords(text);
  const overlap = essayWords.filter((w) => promptWords.has(w));
  const overlapUnique = new Set(overlap).size;
  const offTopic = wc > 80 && overlapUnique < 2;

  const unique = new Set(essayWords);
  const ttr = essayWords.length ? unique.size / essayWords.length : 0;
  const awlHits = [...unique].filter((w) => AWL.has(w)).length;

  const linkerHits = LINKERS.flatMap((w) => {
    const n = lower.split(w).length - 1;
    return n > 0 ? Array(n).fill(w) : [];
  });
  const linkerUnique = new Set(linkerHits).size;
  const complex = sents.filter((s) => /\b(which|who|whose|although|because|while|whereas|unless|if|despite|that)\b/i.test(s)).length;
  const avgLen = sents.length ? wc / sents.length : 0;
  const numbers = (text.match(/\d+(?:\.\d+)?/g) ?? []).map((n) => String(Number(n)));
  const neededNumbers = (task.chart ? collectNumbers(task.chart) : []).map((n) => String(n));
  const numberHits = new Set(numbers.filter((n) => neededNumbers.includes(n))).size;

  let tr = 5;
  let cc = 5;
  let lr = 5;
  let gra = 5;

  if (task.minWords === 250) {
    const hasPosition = /\b(i agree|i disagree|i do not agree|disagree|i believe|in my opinion|i would argue|this essay)\b/i.test(text);
    const both =
      /\b(on the one hand|others|another view|while some|however)\b/i.test(text) && overlapUnique >= 1;
    if (task.type === "opinion") {
      tr = hasPosition ? 6.5 : 5;
      if (!hasPosition) notes.push("Chưa thấy câu trả lời thẳng (agree / disagree).");
    } else if (task.type === "discussion") {
      tr = hasPosition && both ? 6.5 : hasPosition || both ? 5.5 : 4.5;
      if (!both) notes.push("Dạng discussion cần cả hai quan điểm, rồi mới đến ý bạn.");
    } else if (task.type === "adv") {
      const adv = /\b(advantage|benefit|drawback|disadvantage)\b/i.test(text);
      tr = adv && hasPosition ? 6.5 : adv ? 6 : 5;
      if (!adv) notes.push("Thiếu từ khoá advantage / disadvantage — dễ bị coi là chưa đáp ứng đề.");
    } else if (task.type === "problem") {
      const ok = /\b(problem|issue|solution|measure|address|tackle)\b/i.test(text);
      tr = ok ? 6.5 : 5;
      if (!ok) notes.push("Cần nêu vấn đề và biện pháp, không chỉ tả hiện tượng.");
    } else if (task.type === "twopart") {
      const qMarks = (task.prompt.match(/\?/g) ?? []).length;
      tr = paras.length >= 3 && overlapUnique >= 2 ? 6.5 : 5;
      notes.push(qMarks > 1 ? "Đề có hai câu hỏi: mỗi câu cần một đoạn riêng." : "Kiểm tra xem mọi vế của đề đã được trả lời.");
    }
    if (paras.length >= 4 && hasPosition) tr += 0.5;
    if (wc >= 280 && paras.length >= 4) tr += 0.5;
    if (wc < 250) {
      tr -= wc < 200 ? 2 : 1;
      notes.push(`Thiếu độ dài: ${wc}/250 từ. Task Response bị kéo xuống vì ý không đủ chỗ để phát triển.`);
    }
  } else if (task.type.startsWith("letter")) {
    const groups = task.bullets ?? [];
    const hit = groups.filter((g) => g.keys.some((k) => lower.includes(k.toLowerCase()))).length;
    tr = 4 + hit;
    notes.push(`Bullet được đụng tới: ${hit}/${groups.length}.`);
    if (!/dear\b/i.test(text)) {
      tr -= 0.5;
      notes.push("Thiếu lời chào Dear …");
    }
    if (task.type === "letter-formal" && /\b(i'm|don't|can't|won't|it's|hey|hi )\b/i.test(text)) {
      tr -= 0.5;
      notes.push("Thư formal nên tránh viết tắt và giọng quá suồng sã.");
    }
    if (task.type === "letter-informal" && /yours faithfully/i.test(text)) {
      notes.push("Thư informal không kết bằng Yours faithfully.");
      tr -= 0.5;
    }
    if (wc < 150) {
      tr -= wc < 120 ? 1.5 : 1;
      notes.push(`Thiếu từ: ${wc}/150.`);
    }
  } else {
    const overview = /\b(overall|in general|it is clear|what stands out|the most noticeable)\b/i.test(text);
    tr = overview ? 6 : 5;
    if (!overview) notes.push("Chưa có overview. Với Task 1 Academic, thiếu câu này thường không qua được Band 6 ở Task Achievement.");
    if (neededNumbers.length) {
      const cover = numberHits / neededNumbers.length;
      notes.push(`Số liệu trong bài khớp biểu đồ: ${numberHits}/${neededNumbers.length}.`);
      if (cover >= 0.6) tr += 1;
      else if (cover >= 0.3) tr += 0.5;
      else notes.push("Đang tả cảm tính, ít số. Hãy chọn mốc đầu–cuối, đỉnh và ngoại lệ.");
    }
    if (task.type === "process" && /\b(then|next|after|finally|first|stage|is|are)\b/i.test(text)) tr += 0.5;
    if (task.type === "map-change" && /\b(became|was built|replaced|added|removed|converted|while|whereas)\b/i.test(text)) tr += 0.5;
    if (/\b(i think|i believe|in my opinion|i agree)\b/i.test(text)) {
      tr -= 0.5;
      notes.push("Task 1 không đưa quan điểm cá nhân.");
    }
    if (wc < 150) {
      tr -= wc < 120 ? 1.5 : 1;
      notes.push(`Thiếu từ: ${wc}/150.`);
    }
  }

  if (offTopic) {
    tr = Math.min(tr, 4);
    notes.push("Rất ít từ khoá của đề xuất hiện trong bài. Có thể đang lệch đề.");
  }
  if (copiedChunk(text, task.prompt)) {
    tr -= 1;
    notes.push("Có một đoạn dài chép nguyên đề. Phần chép không được tính là ý của bạn.");
  }

  if (paras.length >= 4) cc = 6.5;
  else if (paras.length === 3) cc = 6;
  else if (paras.length === 2) cc = 5;
  else {
    cc = 4.5;
    notes.push("Chưa chia đoạn. Coherence bị giới hạn khi cả bài là một khối.");
  }
  if (linkerUnique >= 4) cc += 0.5;
  if (linkerUnique === 0) {
    cc -= 0.5;
    notes.push("Chưa có từ nối. Người đọc phải tự đoán quan hệ giữa các câu.");
  }
  const heavy = LINKERS.find((w) => lower.split(w).length - 1 >= 4);
  if (heavy) {
    cc -= 0.5;
    notes.push(`"${heavy}" bị lặp như một khuôn. Band 6 cảnh báo cohesive devices máy móc.`);
  }
  if (/\bin conclusion|to conclude|overall\b/i.test(text) && task.minWords === 250) cc += 0.5;

  if (ttr >= 0.55) lr = 6.5;
  else if (ttr >= 0.42) lr = 6;
  else lr = 5;
  if (awlHits >= 6) lr += 0.5;
  if (awlHits < 2 && wc > 150) {
    lr -= 0.5;
    notes.push("Từ vựng còn xoay quanh từ rất phổ thông. Thử thay bằng collocation đúng chủ đề.");
  }
  const freq = new Map<string, number>();
  for (const w of essayWords) freq.set(w, (freq.get(w) ?? 0) + 1);
  const repeated = [...freq.entries()].filter(([w, n]) => n >= 8 && !promptWords.has(w)).sort((a, b) => b[1] - a[1])[0];
  if (repeated) {
    lr -= 0.5;
    notes.push(`Từ "${repeated[0]}" xuất hiện ${repeated[1]} lần. Đang thiếu paraphrase.`);
  }
  if (slips.length) lr -= 0.5;

  if (complex >= 3 && avgLen >= 12 && avgLen <= 28) gra = 6.5;
  else if (complex >= 1) gra = 6;
  else {
    gra = 5;
    notes.push("Hầu hết là câu đơn. Grammatical range cần mệnh đề phụ (although, which, if, because).");
  }
  if (sents.length >= 6 && slips.length === 0) gra += 0.5;
  gra -= Math.min(2, slips.length * 0.5);
  if (slips.length) notes.push(`Lỗi dạng cố định: ${slips.slice(0, 4).join("; ")}.`);
  if (avgLen > 35) {
    gra -= 0.5;
    notes.push("Câu quá dài, dễ mất kiểm soát mệnh đề.");
  }

  const cap = 8;
  tr = clamp(roundHalf(tr), 1, cap);
  cc = clamp(roundHalf(cc), 1, cap);
  lr = clamp(roundHalf(lr), 1, cap);
  gra = clamp(roundHalf(gra), 1, cap);

  const criteria: CriterionScore[] = [
    {
      key: "tr",
      label: task.minWords === 250 ? "Task Response" : "Task Achievement",
      band: tr,
      note: trNote(tr, task),
    },
    { key: "cc", label: "Coherence & Cohesion", band: cc, note: ccNote(cc) },
    { key: "lr", label: "Lexical Resource", band: lr, note: lrNote(lr) },
    { key: "gra", label: "Grammatical Range & Accuracy", band: gra, note: graNote(gra) },
  ];

  const band = roundHalf((tr + cc + lr + gra) / 4);
  if (band >= 7.5) {
    notes.push("Mức 7.5–8.0 ở đây chỉ là trần của bộ đối chiếu tự động. Band 8.5–9.0 cần người đọc vì máy không chấm được độ tinh của lập luận.");
  }
  notes.push(`${wc} từ · ${paras.length} đoạn · ${sents.length} câu · ${linkerUnique} từ nối khác nhau.`);
  return { criteria, notes, band };
}

function collectNumbers(chart: NonNullable<WritingTask["chart"]>): number[] {
  if (chart.kind === "pie") return chart.slices.map((s) => s.y);
  if (chart.kind === "table") {
    return chart.rows.flatMap((r) =>
      r
        .map((c) => c.trim().replace("%", ""))
        .filter((c) => /^\d+(\.\d+)?$/.test(c))
        .map((c) => Number(c)),
    );
  }
  if (chart.kind === "mixed") return [...chart.bars.points.map((p) => p.y), ...chart.line.points.map((p) => p.y)];
  return chart.series.flatMap((s) => s.points.map((p) => p.y));
}

function trNote(band: number, task: WritingTask): string {
  if (band >= 7.5) return "Đủ phần của đề, có phát triển. Vẫn cần ví dụ cụ thể hơn để được người chấm nhìn ở mức 8.";
  if (band >= 6.5) return "Phần chính của đề đã được trả lời và có vị trí rõ. Một vài ý còn khái quát.";
  if (band >= 5.5) return "Có trả lời nhưng chưa đều: một vế mỏng, hoặc thiếu ví dụ, hoặc thiếu overview / bullet.";
  if (task.minWords === 250) return "Đề bị đáp ứng một phần. Band 5 trên descriptor là khi ý chưa được phát triển hoặc còn lệch.";
  return "Chưa phủ dữ liệu hoặc mục đích bài viết. Hãy bám số liệu / bullet trước khi thêm tính từ.";
}

function ccNote(band: number): string {
  if (band >= 7) return "Có tiến trình và chia đoạn. Giữ tham chiếu (this, these, such) để khỏi lặp từ nối.";
  if (band >= 6) return "Đọc được mạch chính. Từ nối còn lúc đúng lúc sáo.";
  return "Mạch còn phải đoán. Chia đoạn theo một ý và đánh dấu quan hệ bằng từ nối có chủ đích.";
}

function lrNote(band: number): string {
  if (band >= 7) return "Đủ linh hoạt cho phạm vi bài. Coi chừng collocation chưa tự nhiên — đó là chỗ Band 7 bị trừ.";
  if (band >= 6) return "Đủ để rõ nghĩa nhưng biên độ từ còn hẹp, đúng mô tả Band 6.";
  return "Từ còn lặp hoặc quá an toàn. Paraphrase bằng cụm danh từ, đừng chỉ đổi một tính từ.";
}

function graNote(band: number): string {
  if (band >= 7) return "Có câu phức và ít lỗi cản nghĩa. Band 7 vẫn cho phép vài lỗi nhỏ không hệ thống.";
  if (band >= 6) return "Trộn câu đơn và câu phức. Lỗi ở câu phức chưa cản giao tiếp — đúng vùng Band 6.";
  return "Câu đơn chiếm ưu thế hoặc lỗi lặp lại. Một lỗi lặp (mạo từ, hoà hợp) sẽ giữ bạn ở Band 5.";
}

export function writingOutline(task: WritingTask): string[] {
  if (task.type.startsWith("letter")) {
    return [
      "Mở: mục đích lá thư trong 1 câu, đúng giọng (formal / semi / informal).",
      ...(task.bullets ?? []).map((b, i) => `Đoạn ${i + 1}: ${b.text}`),
      "Kết: nhắc lại yêu cầu và một lời kết phù hợp giọng thư. Không thêm chuyện mới.",
    ];
  }
  if (task.minWords === 150) {
    return [
      "Câu mở: paraphrase đề, không chép nguyên câu hỏi.",
      "Overview: xu hướng lớn hoặc bước nổi bật, không nhét số nhỏ.",
      "Hai đoạn thân: nhóm dữ liệu (cao/thấp, trước/sau, khác biệt lớn) và đưa số đã chọn.",
      "Không kết luận kiểu bài luận, không nêu ý kiến.",
      ...task.ideas.map((idea) => `Gợi ý nội dung: ${idea}`),
    ];
  }
  return [
    "Mở bài: paraphrase + một câu trả lời thẳng vào câu hỏi.",
    ...task.ideas.map((idea, i) => `Thân ${i + 1}: ${idea}. Kèm một ví dụ cụ thể, không chỉ nói "many people".`),
    "Kết: nhắc lại vị trí bằng cách diễn đạt khác. Không mở thêm lý do mới.",
  ];
}
