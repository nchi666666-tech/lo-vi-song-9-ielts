const NUMBER_WORDS: Record<string, string> = {
  zero: "0",
  one: "1",
  two: "2",
  three: "3",
  four: "4",
  five: "5",
  six: "6",
  seven: "7",
  eight: "8",
  nine: "9",
  ten: "10",
  eleven: "11",
  twelve: "12",
  thirteen: "13",
  fourteen: "14",
  fifteen: "15",
  sixteen: "16",
  seventeen: "17",
  eighteen: "18",
  nineteen: "19",
  twenty: "20",
  thirty: "30",
  forty: "40",
  fifty: "50",
  sixty: "60",
  seventy: "70",
  eighty: "80",
  ninety: "90",
  hundred: "100",
  thousand: "1000",
  first: "1st",
  second: "2nd",
  third: "3rd",
};

export function wordList(s: string): string[] {
  return s.trim().split(/\s+/).filter(Boolean);
}

export function normalizeAnswer(s: string): string {
  const base = s
    .toLowerCase()
    .replace(/[\u2019']/g, "")
    .replace(/\$/g, "")
    .replace(/,/g, "")
    .replace(/[^a-z0-9\s]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
  return base
    .split(" ")
    .filter((w) => w && !["the", "a", "an", "of", "on"].includes(w))
    .map((w) => NUMBER_WORDS[w] ?? w)
    .join(" ");
}

export function answerOk(
  user: string,
  accept: string[],
  wordLimit?: number,
): { ok: boolean; reason: string } {
  if (!user.trim()) return { ok: false, reason: "Bỏ trống." };
  const count = wordList(user).length;
  if (wordLimit && count > wordLimit) {
    return {
      ok: false,
      reason: `Thừa từ: ${count}/${wordLimit}. Trong IELTS, vượt giới hạn từ là sai dù nội dung đúng.`,
    };
  }
  const u = normalizeAnswer(user);
  const keys = accept.map((a) => normalizeAnswer(a));
  if (keys.includes(u)) return { ok: true, reason: "Khớp đáp án." };
  const sorted = (value: string) => value.split(" ").filter(Boolean).sort().join(" ");
  if (u.includes(" ") && keys.some((k) => sorted(k) === sorted(u))) {
    return { ok: true, reason: "Khớp đáp án (không tính thứ tự)." };
  }
  return { ok: false, reason: "Không khớp đáp án chấp nhận." };
}

export function choiceOk(user: string, accept: string[]): { ok: boolean; reason: string } {
  if (!user.trim()) return { ok: false, reason: "Chưa chọn." };
  const letters = user
    .toUpperCase()
    .split(/[^A-Z]+/)
    .filter((x) => x.length === 1);
  const picked = letters.length ? letters.sort().join(" ") : normalizeAnswer(user);
  const keys = accept.map((a) => {
    const ls = a
      .toUpperCase()
      .split(/[^A-Z]+/)
      .filter((x) => x.length === 1);
    return ls.length ? ls.sort().join(" ") : normalizeAnswer(a);
  });
  if (keys.includes(picked)) return { ok: true, reason: "Đúng phương án." };
  return { ok: false, reason: "Sai phương án." };
}
