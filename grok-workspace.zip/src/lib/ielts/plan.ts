import type { Module, Skill } from "./types";
import { infoOf } from "./catalog";

export type Spec = {
  kind: "drill" | "dictation" | "writing" | "speaking" | "vocab" | "review";
  skill: Skill;
  type: string;
  strict: boolean;
};

export type PlanBlock = {
  title: string;
  detail: string;
  minutes: number;
  spec: Spec;
};

export type PlanDay = {
  index: number;
  week: number;
  label: string;
  light: boolean;
  blocks: PlanBlock[];
};

const LADDER: Record<Skill, Record<Module | "any", string[][]>> = {
  listening: {
    any: [
      ["form", "note", "short", "table", "dictation"],
      ["map", "mcq", "matching", "diagram", "flow", "dictation"],
      ["summary", "sentence", "mcq-multi", "note", "dictation"],
    ],
    academic: [[], [], []],
    general: [[], [], []],
  },
  reading: {
    any: [[], [], []],
    academic: [
      ["tfng", "sentence", "short"],
      ["headings", "ynng", "mcq", "info-match"],
      ["features", "endings", "summary-bank", "mcq-multi"],
    ],
    general: [
      ["matching", "tfng", "sentence"],
      ["tfng", "sentence", "matching", "short"],
      ["tfng", "mcq", "sentence"],
    ],
  },
  writing: {
    any: [[], [], []],
    academic: [
      ["bar", "opinion"],
      ["line", "pie", "discussion", "adv"],
      ["mixed", "process", "map-change", "problem", "twopart"],
    ],
    general: [
      ["letter-formal", "opinion"],
      ["letter-semi", "discussion", "adv"],
      ["letter-informal", "problem", "twopart"],
    ],
  },
  speaking: {
    any: [
      ["part1", "part2"],
      ["part2", "part3"],
      ["part3", "speaking-full"],
    ],
    academic: [[], [], []],
    general: [[], [], []],
  },
};

export function kindFor(skill: Skill, type: string): Spec["kind"] {
  if (type === "dictation") return "dictation";
  if (type === "vocab") return "vocab";
  if (type === "review") return "review";
  if (skill === "writing") return "writing";
  if (skill === "speaking") return "speaking";
  return "drill";
}

function bandToRung(band: number) {
  if (band < 5) return 0;
  if (band < 6.5) return 1;
  return 2;
}

export function ladder(skill: Skill, band: number, module: Module): string[] {
  const table = LADDER[skill];
  const specific = table[module][bandToRung(band)];
  const any = table.any[bandToRung(band)];
  const list = specific.length ? specific : any;
  return list.length ? list : ["opinion"];
}

export function buildPlan(input: {
  current: Record<Skill, number>;
  target: number;
  module: Module;
  horizon: number;
  minutes: number;
}): PlanDay[] {
  const skills: Skill[] = ["listening", "reading", "writing", "speaking"];
  const queue: Skill[] = [];
  for (const skill of skills) {
    const weight = Math.max(1, Math.round((input.target - input.current[skill]) * 2));
    for (let i = 0; i < weight; i++) queue.push(skill);
  }
  if (!queue.length) queue.push(...skills);
  const perDay = input.minutes >= 150 ? 4 : input.minutes >= 90 ? 3 : 2;
  const days: PlanDay[] = [];
  for (let index = 0; index < input.horizon; index++) {
    const light = index % 7 === 6;
    const blocks: PlanBlock[] = [];
    const primary = queue[index % queue.length];
    const types = ladder(primary, input.current[primary], input.module);
    const type = types[index % types.length];
    const meta = infoOf(type, primary);
    if (light) {
      blocks.push({
        title: "Ôn lỗi",
        detail: "Chỉ làm lại câu đã sai. Nếu sổ trống, nghe chép một đoạn ngắn.",
        minutes: 20,
        spec: { kind: "review", skill: primary, type: "review", strict: false },
      });
      blocks.push({
        title: "Cụm từ",
        detail: "Sáu cụm, đọc thành tiếng, nhét một cụm vào câu của bạn.",
        minutes: 15,
        spec: { kind: "vocab", skill: "reading", type: "vocab", strict: false },
      });
    } else {
      blocks.push({
        title: meta?.label ?? type,
        detail: meta?.steps[0] ?? "Làm một đề ngắn đúng dạng.",
        minutes: Math.min(40, Math.round(input.minutes * 0.45)),
        spec: {
          kind: kindFor(primary, type),
          skill: primary,
          type,
          strict: index > input.horizon * 0.7,
        },
      });
      if (perDay > 1) {
        const secondSkill = skills[(skills.indexOf(primary) + 1) % 4];
        const secondList = ladder(secondSkill, input.current[secondSkill], input.module);
        const second = secondList[index % secondList.length];
        const secondMeta = infoOf(second, secondSkill);
        blocks.push({
          title: secondMeta?.label ?? second,
          detail: "Kỹ năng thứ hai trong ngày, ngắn hơn khối đầu.",
          minutes: 25,
          spec: {
            kind: kindFor(secondSkill, second),
            skill: secondSkill,
            type: second,
            strict: false,
          },
        });
      }
      if (perDay > 2) {
        blocks.push({
          title: primary === "reading" ? "Nghe chép" : "Cụm từ",
          detail: primary === "reading" ? "Chép một đoạn của bài nghe gốc trong app." : "Chủ đề xoay theo ngày.",
          minutes: 15,
          spec:
            primary === "reading"
              ? { kind: "dictation", skill: "listening", type: "dictation", strict: false }
              : { kind: "vocab", skill: "reading", type: "vocab", strict: false },
        });
      }
      if (perDay > 3) {
        blocks.push({
          title: "Sổ lỗi",
          detail: "Ghi vì sao sai trước khi làm đề mới.",
          minutes: 15,
          spec: { kind: "review", skill: primary, type: "review", strict: false },
        });
      }
    }
    const week = Math.floor(index / 7) + 1;
    days.push({
      index,
      week,
      light,
      label: light ? `Tuần ${week} · ngày nhẹ` : `Tuần ${week} · ngày ${(index % 7) + 1}`,
      blocks,
    });
  }
  return days;
}

export function dayIndex(planStart: string, horizon: number) {
  if (!planStart) return 0;
  const start = new Date(planStart + "T00:00:00");
  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const diff = Math.floor((today.getTime() - start.getTime()) / 86400000);
  if (diff < 0) return 0;
  if (diff >= horizon) return horizon - 1;
  return diff;
}
