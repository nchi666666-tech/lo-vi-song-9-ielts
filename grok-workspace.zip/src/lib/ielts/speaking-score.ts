import { roundHalf } from "./bands";
import type { CriterionScore } from "./types";
import { wordList } from "./grade";

const DISCOURSE = ["well", "actually", "I mean", "you know", "on the other hand", "for example", "for instance", "another", "because", "so", "then", "after that"];

export function scoreTranscript(text: string, seconds: number): { criteria: CriterionScore[]; notes: string[]; band: number | null } {
  const clean = text.trim();
  const words = wordList(clean);
  const notes: string[] = [];
  if (words.length < 20) {
    notes.push("Transcript quá ngắn để máy đối chiếu Fluency, Lexis và Grammar. Hãy nói dài hơn hoặc dán bản chép.");
    return { criteria: [], notes, band: null };
  }
  const minutes = Math.max(seconds / 60, words.length / 130);
  const wpm = Math.round(words.length / minutes);
  const fillers = (clean.match(/\b(um+|uh+|er+|erm+)\b/gi) ?? []).length;
  const discourse = DISCOURSE.filter((d) => clean.toLowerCase().includes(d.toLowerCase())).length;
  const unique = new Set(clean.toLowerCase().match(/[a-z']+/g) ?? []);
  const ttr = unique.size / Math.max(words.length, 1);
  const complex = (clean.match(/\b(which|who|because|although|while|if|when|after|before)\b/gi) ?? []).length;

  let fc = 5;
  if (wpm >= 90 && wpm <= 170 && fillers <= 6) fc = 6.5;
  else if (wpm >= 70) fc = 6;
  else fc = 5;
  if (discourse >= 3) fc += 0.5;
  if (fillers > 10) {
    fc -= 0.5;
    notes.push(`Nhiều từ đệm (${fillers}). Band 6 bắt đầu mất mạch vì hesitation.`);
  }
  if (wpm < 70) notes.push(`Tốc độ khoảng ${wpm} từ/phút — chậm so với Part 2 (thường cần nói liên tục khoảng 2 phút).`);
  else notes.push(`Ước lượng ${wpm} từ/phút trên transcript.`);

  let lr = ttr >= 0.5 ? 6.5 : ttr >= 0.38 ? 6 : 5;
  if (unique.size < 40) {
    lr -= 0.5;
    notes.push("Vốn từ trên transcript còn hẹp. Kể chi tiết (mùi, lý do, lần cuối) thay vì tính từ chung như good, nice, happy.");
  }

  let gra = complex >= 3 ? 6.5 : complex >= 1 ? 6 : 5;
  if (/\b(he|she|it) go\b/i.test(clean) || /\bthey was\b/i.test(clean)) {
    gra -= 0.5;
    notes.push("Có lỗi hoà hợp chủ ngữ–động từ lặp lại trên transcript.");
  }

  const criteria: CriterionScore[] = [
    { key: "fc", label: "Fluency & Coherence", band: roundHalf(Math.min(8, fc)), note: "Máy chỉ thấy từ và mạch, không nghe được ngắt nghỉ thật." },
    { key: "lr", label: "Lexical Resource", band: roundHalf(Math.min(8, lr)), note: "Dựa trên độ phong phú của transcript, không chấm collocation tinh." },
    { key: "gra", label: "Grammatical Range", band: roundHalf(Math.min(8, gra)), note: "Dựa trên câu phức trong transcript." },
  ];
  const band = roundHalf(criteria.reduce((s, c) => s + c.band, 0) / criteria.length);
  return { criteria, notes, band };
}

export function pronunciationNote(self: number | null): CriterionScore | null {
  if (self == null) return null;
  const band = roundHalf(Math.max(0, Math.min(9, self)));
  const note =
    band >= 8
      ? "Bạn tự nhận là dễ hiểu suốt, trọng âm và ngữ điệu giữ được ở câu dài."
      : band >= 6
        ? "Bạn tự nhận là người nghe hiểu được, nhưng một số âm hoặc nhịp chưa ổn định."
        : band >= 4
          ? "Bạn tự nhận là người nghe phải cố. Hãy khoanh 5 âm hay nuốt và luyện tối thiểu cặp từ."
          : "Mức rất thấp. Hãy nghe lại một câu và chép đúng âm trước khi nói tiếp.";
  return { key: "pron", label: "Pronunciation (tự đối chiếu)", band, note };
}
